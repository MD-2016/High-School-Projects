/*
 * Program: D for V = VT + Di
 * Programmer: Jay
 * Filename: DforDVTDi.java
 * Date: 4/19/010
 * Purpose: Solving D variable in equation D = VT + Di
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DforDVTDi extends JFrame implements ActionListener
{

//items used for solving
public JLabel startupDlabel;
public JLabel Vlabel;
public JLabel Tlabel;
public JLabel Dilabel;
public JTextField Difield;
public JTextField Tfield;
public JTextField Vfield;
public JButton calculate;
public JButton backtoMainForm;
public JButton backtoDVTDi;
public JButton backtoRepresentingMotionEquationsForm;

//Constructor method
public DforDVTDi()
{
	super("D for D = VT + Di");
}

//create the Menu Structure
public JMenuBar createMenuBar()
{
	JMenuBar mnuBar = new JMenuBar();
	setJMenuBar(mnuBar);
	
	JMenu mnuFile = new JMenu("File",true);
	mnuFile.setMnemonic(KeyEvent.VK_F);
	mnuFile.setDisplayedMnemonicIndex(0);
	mnuBar.add(mnuFile);
	
	JMenuItem mnuCalculate = new JMenuItem("Calculate");
	mnuCalculate.setMnemonic(KeyEvent.VK_C);
	mnuCalculate.setDisplayedMnemonicIndex(1);
	mnuCalculate.setActionCommand("Calculate2");
	mnuCalculate.addActionListener(this);
	mnuFile.add(mnuCalculate);
	
	JMenu mnuFileBack = new JMenu("Back",true);
	mnuFileBack.setMnemonic(KeyEvent.VK_B);
	mnuFileBack.setDisplayedMnemonicIndex(0);
	mnuFile.add(mnuFileBack);
	
	JMenuItem mnuFileBackBackToDVTDi = new JMenuItem("Back To D = VT + Di Form");
	mnuFileBackBackToDVTDi.setMnemonic(KeyEvent.VK_D);
	mnuFileBackBackToDVTDi.setDisplayedMnemonicIndex(1);
	mnuFileBackBackToDVTDi.setActionCommand("Back To D = VT + Di Form2");
	mnuFileBackBackToDVTDi.addActionListener(this);
	mnuFileBack.add(mnuFileBackBackToDVTDi);
	
	JMenuItem mnuFileBackBackToRepresentingMotionEquationsForm = new JMenuItem("Back To Representing Motion Equations Form");
	mnuFileBackBackToRepresentingMotionEquationsForm.setMnemonic(KeyEvent.VK_R);
	mnuFileBackBackToRepresentingMotionEquationsForm.setDisplayedMnemonicIndex(1);
	mnuFileBackBackToRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form2");
	mnuFileBackBackToRepresentingMotionEquationsForm.addActionListener(this);
	mnuFileBack.add(mnuFileBackBackToRepresentingMotionEquationsForm);
	
	JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
	mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
	mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(1);
	mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
	mnuFileBackBackToMainForm.addActionListener(this);
	mnuFileBack.add(mnuFileBackBackToMainForm);
	
	JMenu mnuAbout = new JMenu("About",true);
	mnuAbout.setMnemonic(KeyEvent.VK_A);
	mnuAbout.setDisplayedMnemonicIndex(0);
	mnuBar.add(mnuAbout);
	
	JMenuItem mnuInstructions = new JMenuItem("Instructions");
	mnuInstructions.setMnemonic(KeyEvent.VK_I);
	mnuInstructions.setDisplayedMnemonicIndex(1);
	mnuInstructions.setActionCommand("Instructions");
	mnuInstructions.addActionListener(this);
	mnuAbout.add(mnuInstructions);
	
	return mnuBar;
}

//create container to hold items
public Container createContentPane()
{
	JPanel northpanel = new JPanel();
	northpanel.setLayout(new FlowLayout());
	startupDlabel = new JLabel("Please enter in information below to solve for D");
	northpanel.add(startupDlabel);
	
	JPanel centerpanel = new JPanel();
	centerpanel.setLayout(new GridLayout(3,3));
	Vfield = new JTextField(10);
	centerpanel.add(Vfield);
	Vlabel = new JLabel("V");
	centerpanel.add(Vlabel);
	Tfield = new JTextField(10);
	centerpanel.add(Tfield);
	Tlabel = new JLabel("T");
	centerpanel.add(Tlabel);
	Difield = new JTextField(10);
	centerpanel.add(Difield);
	Dilabel = new JLabel("Di");
	centerpanel.add(Dilabel);
	
	JPanel southpanel = new JPanel();
	southpanel.setLayout(new FlowLayout());
	calculate = new JButton("Calculate");
	calculate.setActionCommand("Calculate");
	calculate.addActionListener(this);
	southpanel.add(calculate);
	backtoDVTDi = new JButton("Back To D = VT + Di Form");
	backtoDVTDi.setActionCommand("Back To D = VT + Di Form");
	backtoDVTDi.addActionListener(this);
	southpanel.add(backtoDVTDi);
	backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
	backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
	backtoRepresentingMotionEquationsForm.addActionListener(this);
	southpanel.add(backtoRepresentingMotionEquationsForm);
	backtoMainForm = new JButton("Back To Main Form");
	backtoMainForm.setActionCommand("Back To Main Form");
	backtoMainForm.addActionListener(this);
	southpanel.add(backtoMainForm);
	
	Container w = getContentPane();
	w.setLayout(new BorderLayout());
	w.add(northpanel,BorderLayout.NORTH);
	w.add(centerpanel,BorderLayout.CENTER);
	w.add(southpanel,BorderLayout.SOUTH);
	
	return w;
}

//actions for button and menu clicks
public void actionPerformed(ActionEvent e)
{
	String args = e.getActionCommand();
	
	//go to D = VT + Di Form
	if(args.equals("Back To D = VT + Di Form2"))
	{
		DVTDi Dform = new DVTDi();
		Dform.setJMenuBar(Dform.createMenuBar());
		Dform.setContentPane(Dform.createContentPane());
		Dform.setSize(600,375);
		this.hide();
		Dform.show();
	}
	
	//go to D = VT + Di Form
	if(args.equals("Back To D = VT + Di Form"))
	{
		DVTDi Dform2 = new DVTDi();
		Dform2.setJMenuBar(Dform2.createMenuBar());
		Dform2.setContentPane(Dform2.createContentPane());
		Dform2.setSize(600,375);
		this.hide();
		Dform2.show();
	}
	
	//go to Representing Motion Equations Form
	else if(args.equals("Back To Representing Motion Equations Form2"))
	{
		RepresentingMotionEquationsSelection motion = new RepresentingMotionEquationsSelection();
		motion.setJMenuBar(motion.createMenuBar());
		motion.setContentPane(motion.createContentPane());
		motion.setSize(600,375);
		this.hide();
		motion.show();
	}
	
	//go to Representing Motion Equations Form
	else if(args.equals("Back To Representing Motion Equations Form"))
	{
		RepresentingMotionEquationsSelection motion2 = new RepresentingMotionEquationsSelection();
		motion2.setJMenuBar(motion2.createMenuBar());
		motion2.setContentPane(motion2.createContentPane());
		motion2.setSize(600,375);
		this.hide();
		motion2.show();
	}
	
	//go to Main Form
	else if(args.equals("Back To Main Form2"))
	{
		MainForm main = new MainForm();
		main.setJMenuBar(main.createMenuBar());
		main.setContentPane(main.createContentPane());
		main.setSize(600,375);
		this.hide();
		main.show();
	}
	
	//go to Main Form
	else if(args.equals("Back To Main Form"))
	{
		MainForm main2 = new MainForm();
		main2.setJMenuBar(main2.createMenuBar());
		main2.setContentPane(main2.createContentPane());
		main2.setSize(600,375);
		this.hide();
		main2.show();
	}
	
	//solve for D
	else if(args.equals("Calculate2"))
	{
		//variables used to solve for d
		String vstring;
		String tstring;
		String distring;
		double di = 0;
		double t = 0;
		double v = 0;
		double d = 0;
		
		//method for catching errors
		try
		{
			vstring = Vfield.getText();
			tstring = Tfield.getText();
			distring = Difield.getText();
			v = Double.parseDouble(vstring);
			t = Double.parseDouble(tstring);
			di = Double.parseDouble(distring);
			d = (v * t) + di;
			JOptionPane.showMessageDialog(null,"The answer is " + d);
			if(distring == null || tstring == null || vstring == null)throw new Exception();
		}
		
		catch(Exception w)
		{
			JOptionPane.showMessageDialog(null,"Integers and decimals only please","Error",JOptionPane.INFORMATION_MESSAGE);
			Difield.setText("");
			Tfield.setText("");
			Vfield.setText("");
		}

	}
	
	//solve for D
	else if(args.equals("Calculate"))
	{
		//variables used to solve for d
		String vstring;
		String tstring;
		String distring;
		double di = 0;
		double t = 0;
		double v = 0;
		double d = 0;
		
		//method for catching errors
		try
		{
			vstring = Vfield.getText();
			tstring = Tfield.getText();
			distring = Difield.getText();
			v = Double.parseDouble(vstring);
			t = Double.parseDouble(tstring);
			di = Double.parseDouble(distring);
			d = (v * t) + di;
			JOptionPane.showMessageDialog(null,"The answer is " + d);
			if(distring == null || tstring == null || vstring == null)throw new Exception();
		}
		
		catch(Exception w)
		{
			JOptionPane.showMessageDialog(null,"Integers and decimals only please","Error",JOptionPane.INFORMATION_MESSAGE);
			Difield.setText("");
			Tfield.setText("");
			Vfield.setText("");
		}

	}
	
	//how to use this form
	else if(args.equals("Instructions"))
	{
		JOptionPane.showMessageDialog(null,"Enter in values into text fields below then hit calculate to get your answer. You can use button or menu item in File");
	}
}

//used to create and run jframe
public static void main(String[] args)
{
	 try
	 {
		 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
	 }
	 catch(Exception c)
	 {
		 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
	 }
	 JFrame.setDefaultLookAndFeelDecorated(true);
	 DforDVTDi f = new DforDVTDi();
	 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 f.setJMenuBar(f.createMenuBar());
	 f.setContentPane(f.createContentPane());
	 f.setSize(900,149);
	 f.setVisible(true);
}
}
