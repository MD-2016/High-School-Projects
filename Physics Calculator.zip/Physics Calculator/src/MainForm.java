/*
 * Program: Physics Calculator Demo
 * Programmer: Jay
 * Date: 4/15/2010
 * Filename: MainForm.java
 * Purpose: The start of the final project
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public  class MainForm extends JFrame implements ActionListener{

	//Buttons used for main form for user to click
	 JLabel startupLabel = new JLabel("Please select a equation idea below to go to a form of those equations");
	 JButton RepresentingMotionEquations = new JButton("Representing Motion Equations Form");
	 JButton AcceleratingMotionEquations = new JButton("Accelerating Motion Equations Form");
	 JButton ForcesInOneDimensionEquations = new JButton("Forces In One Dimension Equations Form");
	 JButton ForcesInMultipleDimensionsEquations = new JButton("Forces In Multiple Dimensions Equations Form");
	 JButton exit = new JButton("Exit");
	 JButton about = new JButton("About");
	
	 
	 //Panel to hold button
	 JPanel buttonpanel = new JPanel();
	 
	 //Label Panel
	 JPanel labelpanel = new JPanel();
	 
	 //Constructor Method
	 public MainForm()
	 {
		 super("Physics Calculator");
	 }
	 
	 //used to create menu structure
	 public JMenuBar createMenuBar()
	 {
		 JMenuBar mnuBar = new JMenuBar();
		 setJMenuBar(mnuBar);
		 
		 JMenu mnuFile = new JMenu("File",true);
		 mnuFile.setMnemonic(KeyEvent.VK_F);
		 mnuFile.setDisplayedMnemonicIndex(0);
		 mnuBar.add(mnuFile);
		 
		 JMenuItem mnuFileExit = new JMenuItem("Exit");
		 mnuFileExit.setMnemonic(KeyEvent.VK_X);
		 mnuFileExit.setDisplayedMnemonicIndex(1);
		 mnuFile.add(mnuFileExit);
		 mnuFileExit.setActionCommand("Exit");
		 mnuFileExit.addActionListener(this);
		 
		 JMenu mnuChoose = new JMenu("Choose",true);
		 mnuChoose.setMnemonic(KeyEvent.VK_C);
		 mnuChoose.setDisplayedMnemonicIndex(0);
		 mnuBar.add(mnuChoose);
		 
		 JMenuItem mnuRepresentingMotionEquations = new JMenuItem("Representing Motion Equations Form");
		 mnuRepresentingMotionEquations.setMnemonic(KeyEvent.VK_R);
		 mnuRepresentingMotionEquations.setDisplayedMnemonicIndex(1);
		 mnuChoose.add(mnuRepresentingMotionEquations);
		 mnuRepresentingMotionEquations.setActionCommand("Representing Motion Equations");
		 mnuRepresentingMotionEquations.addActionListener(this);
		 
		 JMenuItem mnuAcceleratingMotionEquations = new JMenuItem("Accelerating Motion Equations Form");
		 mnuAcceleratingMotionEquations.setMnemonic(KeyEvent.VK_A);
		 mnuAcceleratingMotionEquations.setDisplayedMnemonicIndex(1);
		 mnuAcceleratingMotionEquations.setActionCommand("Accelerating Motion Equations");
		 mnuChoose.add(mnuAcceleratingMotionEquations);
		 mnuAcceleratingMotionEquations.addActionListener(this);
		 
		 JMenuItem mnuForcesInOneDimensionEquations = new JMenuItem("Forces In One Dimension Equations Form");
		 mnuForcesInOneDimensionEquations.setMnemonic(KeyEvent.VK_D);
		 mnuForcesInOneDimensionEquations.setDisplayedMnemonicIndex(1);
		 mnuForcesInOneDimensionEquations.setActionCommand("Forces In One Dimension Equations");
		 mnuForcesInOneDimensionEquations.addActionListener(this);
		 mnuChoose.add(mnuForcesInOneDimensionEquations);
		 
		 JMenuItem mnuForcesInMultipleDimensionsEquations = new JMenuItem("Forces In Multiple Dimensions Equations Form");
		 mnuForcesInMultipleDimensionsEquations.setMnemonic(KeyEvent.VK_M);
		 mnuForcesInMultipleDimensionsEquations.setDisplayedMnemonicIndex(1);
		 mnuForcesInMultipleDimensionsEquations.setActionCommand("Forces In Multiple Dimensions Equations");
		 mnuForcesInMultipleDimensionsEquations.addActionListener(this);
		 mnuChoose.add(mnuForcesInMultipleDimensionsEquations);
		 
		 JMenu About = new JMenu("About",true);
		 About.setMnemonic(KeyEvent.VK_B);
		 About.setDisplayedMnemonicIndex(0);
		 mnuBar.add(About);
		 
		 JMenuItem Instructions = new JMenuItem("Instructions");
		 Instructions.setMnemonic(KeyEvent.VK_I);
		 Instructions.setDisplayedMnemonicIndex(1);
		 Instructions.setActionCommand("Instructions");
		 Instructions.addActionListener(this);
		 About.add(Instructions);
		 
		 return mnuBar;
	 }
	 
	 //Container to hold fields, buttons, labels
	 public Container createContentPane()
	 {
		 labelpanel.setLayout(new FlowLayout());
		 labelpanel.add(startupLabel);
		 
		 buttonpanel.setLayout(new GridLayout(0,1));
		 buttonpanel.add(RepresentingMotionEquations);
		 RepresentingMotionEquations.setActionCommand("Representing Motion Equations Form");
		 RepresentingMotionEquations.addActionListener(this);
		 buttonpanel.add(AcceleratingMotionEquations);
		 AcceleratingMotionEquations.setActionCommand("Accelerating Motion Equations Form");
		 AcceleratingMotionEquations.addActionListener(this);
		 buttonpanel.add(ForcesInOneDimensionEquations);
		 ForcesInOneDimensionEquations.setActionCommand("Forces In One Dimension Equations Form");
		 ForcesInOneDimensionEquations.addActionListener(this);
		 buttonpanel.add(ForcesInMultipleDimensionsEquations);
		 ForcesInMultipleDimensionsEquations.setActionCommand("Forces In Multiple Dimensions Equations Form");
		 ForcesInMultipleDimensionsEquations.addActionListener(this);
		 buttonpanel.add(exit);
		 exit.addActionListener(this);
		 exit.setActionCommand("exit");
		 buttonpanel.add(about);
		 about.addActionListener(this);
		 about.setActionCommand("about");
		 
		 
		 Container c = getContentPane();
		 c.setLayout(new BorderLayout());
		 c.add(labelpanel, BorderLayout.NORTH);
		 c.add(buttonpanel,BorderLayout.CENTER);
		 
		 return c;
	 }
	 
	 //Button and Menu clicks are made here for handling those events
	 public void actionPerformed(ActionEvent e)
	 {
		 String args = e.getActionCommand();
		 
		 if(args == "exit")
		 {
			System.exit(0);
		 }
		 else if(args == "Exit")
		 {
			 System.exit(0);
		 }
		 else if(args == "about")
		 {
			 JOptionPane.showMessageDialog(null,"This software was created by Jay for the intent for the user to use it to solve for physics equations. Please use this software wisely.","About This Program",JOptionPane.INFORMATION_MESSAGE);
		 }
		 
		 else if(args == "Instructions")
		 {
			 JOptionPane.showMessageDialog(null,"This software was created by Jay for the intent for the user to use it to solve for physics equations. Please use this software wisely.","About This Program",JOptionPane.INFORMATION_MESSAGE);
		 }
		 
		 //Representing Motion Class is called
		 else if(args == "Representing Motion Equations")
		 {
			 RepresentingMotionEquationsSelection d = new RepresentingMotionEquationsSelection();
			 d.show();
			 this.hide();
			 d.setJMenuBar(d.createMenuBar());
			 d.setContentPane(d.createContentPane());
			 d.setSize(600,375);
			 
		 }
		 else if(args == "Representing Motion Equations Form")
		 {
			 RepresentingMotionEquationsSelection w = new RepresentingMotionEquationsSelection();
			 w.setJMenuBar(w.createMenuBar());
			 w.setContentPane(w.createContentPane());
			 w.setSize(600,375);
			 this.hide();
			 w.show();
		 }
		 else if(args == "Accelerating Motion Equations")
		 {
			 AcceleratingMotionEquationSelection w = new AcceleratingMotionEquationSelection();
			 w.setJMenuBar(w.createMenuBar());
			 w.setContentPane(w.createContentPane());
			 w.setSize(600,375);
			 this.hide();
			 w.show();
		 }
		 
		 else if(args == "Accelerating Motion Equations Form")
		 {
			 AcceleratingMotionEquationSelection w2 = new AcceleratingMotionEquationSelection();
			 w2.setJMenuBar(w2.createMenuBar());
			 w2.setContentPane(w2.createContentPane());
			 w2.setSize(600,375);
			 this.hide();
			 w2.show();
		 }
		 else if(args == "Forces In One Dimension Equations Form")
		 {
			 ForcesInOneDimensionEquations force = new ForcesInOneDimensionEquations();
			 force.setJMenuBar(force.createMenuBar());
			 force.setContentPane(force.createContentPane());
			 force.setSize(600,375);
			 this.hide();
			 force.show();
		 }
		 
		 else if(args == "Forces In One Dimension Equations")
		 {
			 ForcesInOneDimensionEquations force2 = new ForcesInOneDimensionEquations();
			 force2.setJMenuBar(force2.createMenuBar());
			 force2.setContentPane(force2.createContentPane());
			 force2.setSize(600,375);
			 this.hide();
			 force2.show();
		 }
		 
		 else if(args == "Forces In Multiple Dimensions Equations Form")
		 {
			 ForcesInMultipleDimensions forces = new ForcesInMultipleDimensions();
			 forces.setJMenuBar(forces.createMenuBar());
			 forces.setContentPane(forces.createContentPane());
			 forces.setSize(600,375);
			 this.hide();
			 forces.show();
		 }
		 
		 else if(args == "Forces In Multiple Dimensions Equations")
		 {
			 ForcesInMultipleDimensions forces2 = new ForcesInMultipleDimensions();
			 forces2.setJMenuBar(forces2.createMenuBar());
			 forces2.setContentPane(forces2.createContentPane());
			 forces2.setSize(600,375);
			 this.hide();
			 forces2.show();
		 }
	 }
	 
	 public static void main(String[] args)
	 {
		 try
		 {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		 }
		 catch(Exception c)
		 {
			 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
		 }
		 JFrame.setDefaultLookAndFeelDecorated(true);
		 MainForm f = new MainForm();
		 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 f.setJMenuBar(f.createMenuBar());
		 f.setContentPane(f.createContentPane());
		 f.setSize(600,375);
		 f.setVisible(true);
	 }
}
