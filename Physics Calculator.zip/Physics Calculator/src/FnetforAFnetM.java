/*
 * Program: Fnet for A = Fnet / M
 * Programmer: Jay
 * Date: 4/29/010
 * Filename: FnetforAFnetM.java
 * Purpose: to solve for Fnet
 */
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class FnetforAFnetM extends JFrame  implements ActionListener{

	//items used in frame
	public JLabel startupFnetlabel;
	public JTextField Afield;
	public JLabel Alabel;
	public JTextField Mfield;
	public JLabel Mlabel;
	public JButton calculate;
	public JButton backtoAFnetM;
	public JButton backtoForcesInOneDimensionEquations;
	public JButton backtoMainForm;
	
	//constructor method for calling class
	public FnetforAFnetM()
	{
		super("Fnet for A = Fnet / M ");
	}
	
	
	//creates menu for calculating and going back places
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToAFnetM = new JMenuItem("Back To A = Fnet / M");
		mnuFileBackBackToAFnetM.setMnemonic(KeyEvent.VK_N);
		mnuFileBackBackToAFnetM.setDisplayedMnemonicIndex(13);
		mnuFileBackBackToAFnetM.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAFnetM);
		
		JMenuItem mnuFileBackBackToForcesInOneDimensionEquations = new JMenuItem("Back To Forces In One Dimension Equations");
		mnuFileBackBackToForcesInOneDimensionEquations.setMnemonic(KeyEvent.VK_D);
		mnuFileBackBackToForcesInOneDimensionEquations.setDisplayedMnemonicIndex(22);
		mnuFileBackBackToForcesInOneDimensionEquations.setActionCommand("Back To Forces In One Dimension Equations2");
		mnuFileBackBackToForcesInOneDimensionEquations.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToForcesInOneDimensionEquations);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(8);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//holds frame items
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupFnetlabel = new JLabel("Please enter in information below to solve for Fnet.");
		northpanel.add(startupFnetlabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(2,2));
		Afield = new JTextField(10);
		Alabel = new JLabel("A");
		Mfield = new JTextField(10);
		Mlabel = new JLabel("M");
		centerpanel.add(Afield);
		centerpanel.add(Alabel);
		centerpanel.add(Mfield);
		centerpanel.add(Mlabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		backtoAFnetM = new JButton("Back To A = Fnet / M");
		backtoAFnetM.setActionCommand("Back To A = Fnet / M");
		backtoAFnetM.addActionListener(this);
		backtoForcesInOneDimensionEquations = new JButton("Back To Forces In One Dimension Equations");
		backtoForcesInOneDimensionEquations.setActionCommand("Back To Forces Dimension Equations");
		backtoForcesInOneDimensionEquations.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(calculate);
		southpanel.add(backtoForcesInOneDimensionEquations);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel,BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel,BorderLayout.SOUTH);
		
		return c;
	}
	
	//method called the makes button and menu clicks happen
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To A = Fnet / M2"))
		{
			AFnetM a = new AFnetM();
			a.setJMenuBar(a.createMenuBar());
			a.setContentPane(a.createContentPane());
			a.setSize(600,375);
			this.hide();
			a.show();
		}
		
		else if(arg.equals("Back To A = Fnet / M"))
		{
			AFnetM a2 = new AFnetM();
			a2.setJMenuBar(a2.createMenuBar());
			a2.setContentPane(a2.createContentPane());
			a2.setSize(600,375);
			this.hide();
			a2.show();
		}
		
		else if(arg.equals("Back To Forces In One Dimension Equations2"))
		{
			ForcesInOneDimensionEquations force = new ForcesInOneDimensionEquations();
			force.setJMenuBar(force.createMenuBar());
			force.setContentPane(force.createContentPane());
			force.setSize(600,375);
			this.hide();
			force.show();
		}
		
		else if(arg.equals("Back To Forces Dimension Equations"))
		{
			ForcesInOneDimensionEquations force2 = new ForcesInOneDimensionEquations();
			force2.setJMenuBar(force2.createMenuBar());
			force2.setContentPane(force2.createContentPane());
			force2.setSize(600,375);
			this.hide();
			force2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String astring;
			String mstring;
			double a = 0;
			double m = 0;
			double fnet = 0;
			
			astring = Afield.getText();
			mstring = Mfield.getText();
			
			try
			{
				a = Double.parseDouble(astring);
				m = Double.parseDouble(mstring);
				fnet = a * m;
				JOptionPane.showMessageDialog(null,"The answer is " + fnet,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Mfield.setText("");
				if(astring == null || mstring == null)throw new Exception();			
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null,"You can only enter numbers or decimals","Error",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Mfield.setText("");
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String astring;
			String mstring;
			double a = 0;
			double m = 0;
			double fnet = 0;
			
			astring = Afield.getText();
			mstring = Mfield.getText();
			
			try
			{
				a = Double.parseDouble(astring);
				m = Double.parseDouble(mstring);
				fnet = a * m;
				JOptionPane.showMessageDialog(null,"The answer is " + fnet,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Mfield.setText("");
				if(astring == null || mstring == null)throw new Exception();			
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null,"You can only enter numbers or decimals","Error",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Mfield.setText("");
			}
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Enter in information in the textboxes and then click calculate to get the answer","How To",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	//creates class and makes frame appear
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		FnetforAFnetM fnet = new FnetforAFnetM();
		fnet.setJMenuBar(fnet.createMenuBar());
		fnet.setContentPane(fnet.createContentPane());
		fnet.setSize(600,375);
		fnet.setVisible(true);
	}
}
