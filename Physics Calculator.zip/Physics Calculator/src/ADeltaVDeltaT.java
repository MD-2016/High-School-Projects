/*
 * Program: A = Delta V / Delta T  selection Form
 * Programmer: Jay
 * Date: 4/22/2010
 * Filename: ADeltaVDeltaT.java
 * Purpose: To choose a variable to go solve for in A = Delta V / Delta T
 */
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class ADeltaVDeltaT extends JFrame implements ActionListener{

	public JLabel startuplabel;
	public JButton A;
	public JButton DeltaV;
	public JButton DeltaT;
	public JButton backtoAcceleratingMotionEquationForm;
	public JButton backtoMainForm;
	
	public ADeltaVDeltaT()
	{
		super("A = Delta V / Delta T Form");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackToMainForm.setDisplayedMnemonicIndex(0);
		mnuFileBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackToMainForm.addActionListener(this);
		mnuFile.add(mnuFileBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseA = new JMenuItem("A");
		mnuChooseA.setMnemonic(KeyEvent.VK_A);
		mnuChooseA.setDisplayedMnemonicIndex(0);
		mnuChooseA.setActionCommand("A2");
		mnuChooseA.addActionListener(this);
		mnuChoose.add(mnuChooseA);
		
		JMenuItem mnuChooseDeltaV = new JMenuItem("Delta V");
		mnuChooseDeltaV.setMnemonic(KeyEvent.VK_V);
		mnuChooseDeltaV.setDisplayedMnemonicIndex(0);
		mnuChooseDeltaV.setActionCommand("Delta V2");
		mnuChooseDeltaV.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaV);
		
		JMenuItem mnuChooseDeltaT = new JMenuItem("Delta T");
		mnuChooseDeltaT.setMnemonic(KeyEvent.VK_T);
		mnuChooseDeltaT.setDisplayedMnemonicIndex(6);
		mnuChooseDeltaT.setActionCommand("Delta T2");
		mnuChooseDeltaT.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaT);
		
		JMenuItem mnuBackToAcceleratingMotionEquationsForm = new JMenuItem("Back To Accelerating Motion Equations Form");
		mnuBackToAcceleratingMotionEquationsForm.setMnemonic(KeyEvent.VK_E);
		mnuBackToAcceleratingMotionEquationsForm.setDisplayedMnemonicIndex(4);
		mnuBackToAcceleratingMotionEquationsForm.setActionCommand("Back To Accelerating Motion Equations Form2");
		mnuBackToAcceleratingMotionEquationsForm.addActionListener(this);
		mnuFileBack.add(mnuBackToAcceleratingMotionEquationsForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuChoose.setMnemonic(KeyEvent.VK_O);
		mnuChoose.setDisplayedMnemonicIndex(3);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a variable below to solve for A = Delta V / Delta T");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		A = new JButton("A");
		A.setActionCommand("A");
		A.addActionListener(this);
		buttonpanel.add(A);
		DeltaV = new JButton("Delta V");
		DeltaV.setActionCommand("Delta V");
		DeltaV.addActionListener(this);
		buttonpanel.add(DeltaV);
		DeltaT = new JButton("Delta T");
		DeltaT.setActionCommand("Delta T");
		DeltaT.addActionListener(this);
		buttonpanel.add(DeltaT);
		backtoAcceleratingMotionEquationForm = new JButton("Back To Accelerating Motion Equations Form");
		backtoAcceleratingMotionEquationForm.setActionCommand("Back To Accelerating Motion Equations Form");
		backtoAcceleratingMotionEquationForm.addActionListener(this);
		buttonpanel.add(backtoAcceleratingMotionEquationForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel, BorderLayout.NORTH);
		c.add(buttonpanel,BorderLayout.CENTER);
		
		return c;
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Main Form2"))
		{
			MainForm l = new MainForm();
			l.setJMenuBar(l.createMenuBar());
			l.setContentPane(l.createContentPane());
			l.setSize(600,375);
			this.hide();
			l.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm l2 = new MainForm();
			l2.setJMenuBar(l2.createMenuBar());
			l2.setContentPane(l2.createContentPane());
			l2.setSize(600,375);
			this.hide();
			l2.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Equations Form2"))
		{
			AcceleratingMotionEquationSelection accelerate = new AcceleratingMotionEquationSelection();
			accelerate.setJMenuBar(accelerate.createMenuBar());
			accelerate.setContentPane(accelerate.createContentPane());
			accelerate.setSize(600,375);
			accelerate.show();
			this.hide();
		}
		
		else if(arg.equals("Back To Accelerating Motion Equations Form"))
		{
			AcceleratingMotionEquationSelection accelerate2 = new AcceleratingMotionEquationSelection();
			accelerate2.setJMenuBar(accelerate2.createMenuBar());
			accelerate2.setContentPane(accelerate2.createContentPane());
			accelerate2.setSize(600,375);
			accelerate2.show();
			this.hide();
		}
		
		else if (arg.equals("A2"))
		{
			AforADeltaVDeltaT A = new AforADeltaVDeltaT();
			A.setJMenuBar(A.createMenuBar());
			A.setContentPane(A.createContentPane());
			A.setSize(600,375);
			this.hide();
			A.show();
		}
		
		else if (arg.equals("A"))
		{
			AforADeltaVDeltaT A2 = new AforADeltaVDeltaT();
			A2.setJMenuBar(A2.createMenuBar());
			A2.setContentPane(A2.createContentPane());
			A2.setSize(600,375);
			this.hide();
			A2.show();
		}
		
		else if (arg.equals("Delta V2"))
		{
			DeltaVforADeltaVDeltaT v = new DeltaVforADeltaVDeltaT();
			v.setJMenuBar(v.createMenuBar());
			v.setContentPane(v.createContentPane());
			v.setSize(600,375);
			this.hide();
			v.show();
		}
		
		else if (arg.equals("Delta V"))
		{
			DeltaVforADeltaVDeltaT v2 = new DeltaVforADeltaVDeltaT();
			v2.setJMenuBar(v2.createMenuBar());
			v2.setContentPane(v2.createContentPane());
			v2.setSize(600,375);
			this.hide();
			v2.show();
		}
		
		else if (arg.equals("Delta T2"))
		{
			DeltaTforADeltaVDeltaT t = new DeltaTforADeltaVDeltaT();
			t.setJMenuBar(t.createMenuBar());
			t.setContentPane(t.createContentPane());
			t.setSize(600,375);
			this.hide();
			t.show();
		}
		
		else if (arg.equals("Delta T"))
		{
			DeltaTforADeltaVDeltaT t2 = new DeltaTforADeltaVDeltaT();
			t2.setJMenuBar(t2.createMenuBar());
			t2.setContentPane(t2.createContentPane());
			t2.setSize(600,375);
			this.hide();
			t2.show();
		}
		
		else if (arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Select a variable to solve for in A = Delta V / Delta T and then be taken to chosen variable form to solve for it","Help",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		ADeltaVDeltaT A = new ADeltaVDeltaT();
		A.setJMenuBar(A.createMenuBar());
		A.setContentPane(A.createContentPane());
		A.setSize(600,375);
		A.setVisible(true);
		A.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
}
