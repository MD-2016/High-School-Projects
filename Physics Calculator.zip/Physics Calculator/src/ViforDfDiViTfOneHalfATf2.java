/*
 * Program: Vi for Df = Di + ViTf + 1/2 ATf^2
 * Programmer: Jay
 * Date: 4/23/010
 * Filename: ViforDfDiViTfOneHalfATf2.java
 * Purpose: to solve for Vi
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ViforDfDiViTfOneHalfATf2 extends JFrame implements ActionListener{

	//comptents used in frame.
	public JLabel startupVilabel;
	public JLabel Dflabel;
	public JLabel Alabel;
	public JLabel Tflabel;
	public JLabel Dilabel;
	public JTextField Dffield;
	public JTextField Difield;
	public JTextField Afield;
	public JTextField Tffield;
	public JButton calculate;
	public JButton backtoDfDiViTfOneHalfATf2Form;
	public JButton backtoAcceleratingMotionForm;
	public JButton backtoMainForm;
	
	public ViforDfDiViTfOneHalfATf2()
	{
		super("Vi for Df = Di + ViTf + 1/2 ATf^2 Form");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToDfDiViTfOneHalfATf2Form = new JMenuItem("Back To Df = Di + ViTf + 1/2 ATf^2 Form");
		mnuFileBackBackToDfDiViTfOneHalfATf2Form.setMnemonic(KeyEvent.VK_D);
		mnuFileBackBackToDfDiViTfOneHalfATf2Form.setDisplayedMnemonicIndex(0);
		mnuFileBackBackToDfDiViTfOneHalfATf2Form.addActionListener(this);
		mnuFileBackBackToDfDiViTfOneHalfATf2Form.setActionCommand("Back To Df = Di + ViTf + 1/2 ATf^2 Form2");
		mnuFileBack.add(mnuFileBackBackToDfDiViTfOneHalfATf2Form);
		
		JMenuItem mnuFileBackBackToAcceleratingMotionForm = new JMenuItem("Back To Accelerating Motion Form");
		mnuFileBackBackToAcceleratingMotionForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToAcceleratingMotionForm.setDisplayedMnemonicIndex(23);
		mnuFileBackBackToAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form2");
		mnuFileBackBackToAcceleratingMotionForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcceleratingMotionForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_K);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(5);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupVilabel = new JLabel("Enter in information to solve for vi");
		northpanel.add(startupVilabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(4,4));
		Difield = new JTextField(10);
		Dilabel = new JLabel("Di");
		Dffield = new JTextField(10);
		Dflabel = new JLabel("Df");
		Afield = new JTextField(10);
		Alabel = new JLabel("A");
		Tffield = new JTextField(10);
		Tflabel = new JLabel("Tf");
		centerpanel.add(Difield);
		centerpanel.add(Dilabel);
		centerpanel.add(Dffield);
		centerpanel.add(Dflabel);
		centerpanel.add(Afield);
		centerpanel.add(Alabel);
		centerpanel.add(Tffield);
		centerpanel.add(Tflabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		backtoDfDiViTfOneHalfATf2Form = new JButton("Back To Df = Di + ViTf + 1/2 ATf^2 Form");
		backtoDfDiViTfOneHalfATf2Form.setActionCommand("Back To Df = Di + ViTf + 1/2 ATf^2 Form");
		backtoDfDiViTfOneHalfATf2Form.addActionListener(this);
		backtoAcceleratingMotionForm = new JButton("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(calculate);
		southpanel.add(backtoDfDiViTfOneHalfATf2Form);
		southpanel.add(backtoAcceleratingMotionForm);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel, BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel, BorderLayout.SOUTH);
		
		return c;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Df = Di + ViTf + 1/2 ATf^2 Form2"))
		{
			DfDiViTfOneHalfATf2  dfdiviatfonehalfatf2  = new DfDiViTfOneHalfATf2();
			dfdiviatfonehalfatf2.setJMenuBar(dfdiviatfonehalfatf2.createMenuBar());
			dfdiviatfonehalfatf2.setContentPane(dfdiviatfonehalfatf2.createContentPane());
			dfdiviatfonehalfatf2.setSize(600,375);
			this.hide();
			dfdiviatfonehalfatf2.show();
		}
		
		if(arg.equals("Back To Df = Di + ViTf + 1/2 ATf^2 Form"))
		{
			DfDiViTfOneHalfATf2  dfdiviatfonehalfatf22  = new DfDiViTfOneHalfATf2();
			dfdiviatfonehalfatf22.setJMenuBar(dfdiviatfonehalfatf22.createMenuBar());
			dfdiviatfonehalfatf22.setContentPane(dfdiviatfonehalfatf22.createContentPane());
			dfdiviatfonehalfatf22.setSize(600,375);
			this.hide();
			dfdiviatfonehalfatf22.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form2"))
		{
			AcceleratingMotionEquationSelection motion = new AcceleratingMotionEquationSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form"))
		{
			AcceleratingMotionEquationSelection motion2 = new AcceleratingMotionEquationSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String distring;
			String astring;
			String tfstring;
			String dfstring;
			double a = 0;
			double di = 0;
			double vi = 0;
			double tf = 0;
			double df = 0;
			double previ = 0;
			double previ2 = 0;
			
			astring = Afield.getText();
			dfstring = Dffield.getText();
			distring = Difield.getText();
			tfstring = Tffield.getText();
			
			try
			{
				a = Double.parseDouble(astring);
				df = Double.parseDouble(dfstring);
				di = Double.parseDouble(distring);
				tf = Double.parseDouble(tfstring);
				previ = df - di;
				previ2 = 0.5 * a * Math.pow(tf,2);
				vi = previ - previ2;
				JOptionPane.showMessageDialog(null,"Answer is " + vi,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Difield.setText("");
				Dffield.setText("");
				Tffield.setText("");
				if(astring == null || dfstring == null || distring == null || tfstring == null || tf == 0)throw new Exception();
			}
			catch(Exception t)
			{
				JOptionPane.showMessageDialog(null,"Please enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Difield.setText("");
				Dffield.setText("");
				Tffield.setText("");
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String distring;
			String astring;
			String tfstring;
			String dfstring;
			double a = 0;
			double di = 0;
			double vi = 0;
			double tf = 0;
			double df = 0;
			double previ = 0;
			double previ2 = 0;
			
			astring = Afield.getText();
			dfstring = Dffield.getText();
			distring = Difield.getText();
			tfstring = Tffield.getText();
			
			try
			{
				a = Double.parseDouble(astring);
				df = Double.parseDouble(dfstring);
				di = Double.parseDouble(distring);
				tf = Double.parseDouble(tfstring);
				previ = df - di;
				previ2 = 0.5 * a * Math.pow(tf,2);
				vi = previ - previ2;
				JOptionPane.showMessageDialog(null,"Answer is " + vi,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Difield.setText("");
				Dffield.setText("");
				Tffield.setText("");
				if(astring == null || dfstring == null || distring == null || tfstring == null || tf == 0)throw new Exception();
			}
			catch(Exception t)
			{
				JOptionPane.showMessageDialog(null,"Please enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Difield.setText("");
				Dffield.setText("");
				Tffield.setText("");
			}
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Enter in numbers into the textboxes and then click the calculate button to get the answer.\nYou can leave at any time to other forms","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		ViforDfDiViTfOneHalfATf2 vi = new ViforDfDiViTfOneHalfATf2();
		vi.setJMenuBar(vi.createMenuBar());
		vi.setContentPane(vi.createContentPane());
		vi.setSize(999,300);
		vi.setVisible(true);
	}
	
	
}
