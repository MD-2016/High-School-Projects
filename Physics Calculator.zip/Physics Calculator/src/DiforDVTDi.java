/*
 * Program: Di for D = VT + Di Form
 * Programmer: Jay
 * Date: 4/22/2010
 * Filename: DiforDVTDi.java
 * Purpose: solve for Di in D = VT + Di 
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DiforDVTDi extends JFrame implements ActionListener {
	
	//items used for calculations
	JLabel startupDilabel = new JLabel("Please enter in information below to solve for Di");
	JLabel Dlabel = new JLabel("D");
	JTextField Dfield = new JTextField(10);
	JLabel Vlabel = new JLabel("V");
	JTextField Vfield = new JTextField(10);
	JLabel Tlabel = new JLabel("T");
	JTextField Tfield = new JTextField(10);
	JButton calculate = new JButton("Calculate");
	JButton backtoMainForm = new JButton("Back To Main Form");
	JButton backtoDVTDiForm = new JButton("Back To D = VT + Di");
	JButton backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
	
	//Constructor Method
	public DiforDVTDi()
	{
		super("Di for D = VT + Di Form");
	}
	
	//creates the menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(1);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuBackToMainForm = new JMenuItem("Back To Main Form");
		mnuBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuBackToMainForm.setDisplayedMnemonicIndex(1);
		mnuBackToMainForm.setActionCommand("Back To Main Form2");
		mnuBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuBackToMainForm);
		
		JMenuItem mnuBackToDVTDiForm = new JMenuItem("Back To Di for D = VT + Di Form");
		mnuBackToDVTDiForm.setMnemonic(KeyEvent.VK_D);
		mnuBackToDVTDiForm.setDisplayedMnemonicIndex(1);
		mnuBackToDVTDiForm.setActionCommand("Back To D = VT + Di Form2");
		mnuBackToDVTDiForm.addActionListener(this);
		mnuFileBack.add(mnuBackToDVTDiForm);
		
		JMenuItem mnuBackToRepresentingMotionEquationsSelection = new JMenuItem("Back To Representing Motion Equations Form");
		mnuBackToRepresentingMotionEquationsSelection.setMnemonic(KeyEvent.VK_E);
		mnuBackToRepresentingMotionEquationsSelection.setDisplayedMnemonicIndex(1);
		mnuBackToRepresentingMotionEquationsSelection.setActionCommand("Back To Representing Motion Equation Form2");
		mnuBackToRepresentingMotionEquationsSelection.addActionListener(this);
		mnuFileBack.add(mnuBackToRepresentingMotionEquationsSelection);
		
		JMenu mnuAbout = new JMenu("About");
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
		mnuAboutInstructions.setMnemonic(KeyEvent.VK_I);
		mnuAboutInstructions.setDisplayedMnemonicIndex(1);
		mnuAboutInstructions.setActionCommand("Instructions");
		mnuAboutInstructions.addActionListener(this);
		mnuAbout.add(mnuAboutInstructions);
		
		return mnuBar;
		
	}
	
	
	//creates the container to hold items 
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		northpanel.add(startupDilabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(3,3));
		centerpanel.add(Dfield);
		centerpanel.add(Dlabel);
		centerpanel.add(Vfield);
		centerpanel.add(Vlabel);
		centerpanel.add(Tfield);
		centerpanel.add(Tlabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		southpanel.add(calculate);
		calculate.addActionListener(this);
		calculate.setActionCommand("Calculate");
		backtoDVTDiForm.setActionCommand("Back To D = VT + Di Form");
		backtoDVTDiForm.addActionListener(this);
		southpanel.add(	backtoDVTDiForm);
		southpanel.add(backtoRepresentingMotionEquationsForm);
		backtoRepresentingMotionEquationsForm.addActionListener(this);
		backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
		southpanel.add(backtoMainForm);
		backtoMainForm.addActionListener(this);
		backtoMainForm.setActionCommand("Back To Main Form");
		
		Container f = getContentPane();
		f.setLayout(new BorderLayout());
		f.add(northpanel, BorderLayout.NORTH);
		f.add(centerpanel, BorderLayout.CENTER);
		f.add(southpanel, BorderLayout.SOUTH);
		
		return f;
	}
	
	//used to implement button and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String args = e.getActionCommand();
		
		//go main menu
		if(args == "Back To Main Form2")
		{
			MainForm m = new MainForm();
			m.setJMenuBar(m.createMenuBar());
			m.setContentPane(m.createContentPane());
			m.setSize(600,375);
			m.show();
			this.hide();
		}
		
		//go to main menu
		if(args == "Back To Main Form")
		{
			MainForm m2 = new MainForm();
			m2.setJMenuBar(m2.createMenuBar());
			m2.setContentPane(m2.createContentPane());
			m2.setSize(600,375);
			m2.show();
			this.hide();
		}
		
		//go to Representing Motion Equations Form 
		if(args == "Back To Representing Motion Equation Form2")
		{
			RepresentingMotionEquationsSelection w = new RepresentingMotionEquationsSelection();
			w.setJMenuBar(w.createMenuBar());
			w.setContentPane(w.createContentPane());
			w.setSize(600,375);
			w.show();
			this.hide();
		}
		
		//go to D = VT + Di Form
		if(args == "Back To D = VT + Di Form2")
		{
			DVTDi t = new DVTDi();
			t.setJMenuBar(t.createMenuBar());
			t.setContentPane(t.createContentPane());
			t.setSize(600,375);
			t.show();
			this.hide();
		}
		
		//go to D = VT + Di Form
		if(args == "Back To D = VT + Di Form")
		{
			DVTDi t2 = new DVTDi();
			t2.setJMenuBar(t2.createMenuBar());
			t2.setContentPane(t2.createContentPane());
			t2.setSize(600,375);
			t2.show();
			this.hide();
		}
		
		//go to Representing Motion Equations Form
		if(args == "Back To Representing Motion Equations Form")
		{
			RepresentingMotionEquationsSelection q = new RepresentingMotionEquationsSelection();
			q.setJMenuBar(q.createMenuBar());
			q.setContentPane(q.createContentPane());
			q.setSize(600,375);
			q.show();
			this.hide();
		}
		
		
		
		//solve for Di
		if(args == "Calculate2")
		{
			//variables used to solve for Di
			double d = 0;
			double v = 0;
			double t = 0;
			double di = 0;
			String dstring;
			String vstring;
			String tstring;
			
			
			dstring = Dfield.getText();
			vstring = Vfield.getText();
			tstring = Tfield.getText();
			
			//used for error handling of wrong input
			try
			{
			d = Double.parseDouble(dstring);
			v = Double.parseDouble(vstring);
			t = Double.parseDouble(tstring);
			di = d - (v * t);
			JOptionPane.showMessageDialog(null,"The answer for Di is " + di);
			Dfield.setText("");
			Vfield.setText("");
			Tfield.setText("");
			if(dstring == null || vstring == null || tstring == null)throw new Exception();
			}
			catch(Exception o)
			{
				JOptionPane.showMessageDialog(null,"You must enter integers and decimals only into the fields.","Input Error",JOptionPane.INFORMATION_MESSAGE);
				Dfield.setText("");
				Vfield.setText("");
				Tfield.setText("");
			}
			
		}
		
		//solve for Delta D
		if(args == "Calculate")
		{
			//variables used to solve for Di
			double d = 0;
			double v = 0;
			double t = 0;
			double di = 0;
			String dstring;
			String vstring;
			String tstring;
			
			
			dstring = Dfield.getText();
			vstring = Vfield.getText();
			tstring = Tfield.getText();
			
			//used for error handling of wrong input
			try
			{
			d = Double.parseDouble(dstring);
			v = Double.parseDouble(vstring);
			t = Double.parseDouble(tstring);
			di = d - (v * t);
			JOptionPane.showMessageDialog(null,"The answer for Di is " + di);
			Dfield.setText("");
			Vfield.setText("");
			Tfield.setText("");
			if(dstring == null || vstring == null || tstring == null)throw new Exception();
			}
			catch(Exception o)
			{
				JOptionPane.showMessageDialog(null,"You must enter integers and decimals only into the fields.","Input Error",JOptionPane.INFORMATION_MESSAGE);
				Dfield.setText("");
				Vfield.setText("");
				Tfield.setText("");
			}
			
		}
	}
	//creates the jframe
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		DiforDVTDi g = new DiforDVTDi();
		g.setJMenuBar(g.createMenuBar());
		g.setContentPane(g.createContentPane());
		g.setSize(600,375);
		g.setVisible(true);
	}
}

