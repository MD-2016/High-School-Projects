/*
 * Program: R for Ac = V2 / R
 * Programmer: Jay
 * Date: 4/29/010
 * Filename: RforAcV2R.java
 * Purpose: To solve for R
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class RforAcV2R extends JFrame implements ActionListener {

	//items used in frame
	public JLabel startupVlabel;
	public JTextField Acfield;
	public JLabel Aclabel;
	public JTextField Vfield;
	public JLabel Vlabel;
	public JButton calculate;
	public JButton backtoAcV2R;
	public JButton backtoForcesInMultipleDimensionsEquations;
	public JButton backtoMainForm;
	
	public RforAcV2R()
	{
		super("R for Ac = V2 / R");
	}
	
	//used to create menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToAcV2R = new JMenuItem("Back To Ac = V2 / R");
		mnuFileBackBackToAcV2R.setMnemonic(KeyEvent.VK_A);
		mnuFileBackBackToAcV2R.setDisplayedMnemonicIndex(1);
		mnuFileBackBackToAcV2R.setActionCommand("Back To Ac = V2 / R2");
		mnuFileBackBackToAcV2R.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcV2R);
		
		JMenuItem mnuFileBackBackToForcesInMultipleDimensionsEquations = new JMenuItem("Back To Forces In Multiple Dimensions Equations");
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setDisplayedMnemonicIndex(18);
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setActionCommand("Back To Forces In Multiple Dimensions Equations2");
		mnuFileBackBackToForcesInMultipleDimensionsEquations.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToForcesInMultipleDimensionsEquations);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(8);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//used to hold items in frame
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupVlabel = new JLabel("Please enter in information below to solve for V.");
		northpanel.add(startupVlabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(2,2));
		Acfield = new JTextField(10);
		Aclabel = new JLabel("Ac");
		Vfield = new JTextField(10);
		Vlabel = new JLabel("V");
		centerpanel.add(Acfield);
		centerpanel.add(Aclabel);
		centerpanel.add(Vfield);
		centerpanel.add(Vlabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		backtoAcV2R = new JButton("Back To Ac = V2 / R");
		backtoAcV2R.setActionCommand("Back To Ac = V2 / R");
		backtoAcV2R.addActionListener(this);
		backtoForcesInMultipleDimensionsEquations = new JButton("Back To Forces In Multiple Dimensions Equations");
		backtoForcesInMultipleDimensionsEquations.setActionCommand("Back To Forces In Multiple Dimensions Equations");
		backtoForcesInMultipleDimensionsEquations.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(calculate);
		southpanel.add(backtoAcV2R);
		southpanel.add(backtoForcesInMultipleDimensionsEquations);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel,BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel,BorderLayout.SOUTH);
		
		return c;
	}
	
	//used to implement actions of button clicks and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Ac = V2 / R2"))
		{
			AcV2R acv2r = new AcV2R();
			acv2r.setJMenuBar(acv2r.createMenuBar());
			acv2r.setContentPane(acv2r.createContentPane());
			acv2r.setSize(600,375);
			this.hide();
			acv2r.show();
		}
		
		if(arg.equals("Back To Ac = V2 / R"))
		{
			AcV2R acv2r = new AcV2R();
			acv2r.setJMenuBar(acv2r.createMenuBar());
			acv2r.setContentPane(acv2r.createContentPane());
			acv2r.setSize(600,375);
			this.hide();
			acv2r.show();
		}
		else if(arg.equals("Back To Forces In Multiple Dimensions Equations2"))
		{
			ForcesInMultipleDimensions force = new ForcesInMultipleDimensions();
			force.setJMenuBar(force.createMenuBar());
			force.setContentPane(force.createContentPane());
			force.setSize(600,375);
			this.hide();
			force.show();
		}
		
		else if(arg.equals("Back To Forces In Multiple Dimensions Equations"))
		{
			ForcesInMultipleDimensions force2 = new ForcesInMultipleDimensions();
			force2.setJMenuBar(force2.createMenuBar());
			force2.setContentPane(force2.createContentPane());
			force2.setSize(600,375);
			this.hide();
			force2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String acstring;
			String vstring;
			double v = 0;
			double r = 0;
			double ac = 0;
			
			acstring = Acfield.getText();
			vstring = Vfield.getText();
			
			try
			{
				ac = Double.parseDouble(acstring);
				v = Double.parseDouble(vstring);
				r = (Math.pow(v,2)) / ac;
				JOptionPane.showMessageDialog(null,"The Answer is " + r,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Acfield.setText("");
				Vfield.setText("");
				if(acstring == null || vstring == null || ac == 0)throw new Exception();
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				Acfield.setText("");
				Vfield.setText("");
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String acstring;
			String vstring;
			double v = 0;
			double r = 0;
			double ac = 0;
			
			acstring = Acfield.getText();
			vstring = Vfield.getText();
			
			try
			{
				ac = Double.parseDouble(acstring);
				v = Double.parseDouble(vstring);
				r = (Math.pow(v,2)) / ac;
				JOptionPane.showMessageDialog(null,"The Answer is " + r,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Acfield.setText("");
				Vfield.setText("");
				if(acstring == null || vstring == null || ac == 0)throw new Exception();
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				Acfield.setText("");
				Vfield.setText("");
			}
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Enter in information then hit calculate to get the answer for the variable","How To",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	public static void main(String[] args)
	{
		try
		 {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		 }
		 catch(Exception c)
		 {
			 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
		 }
		RforAcV2R r = new RforAcV2R();
		r.setJMenuBar(r.createMenuBar());
		r.setContentPane(r.createContentPane());
		r.setSize(600,375);
		r.setVisible(true);
	}
}