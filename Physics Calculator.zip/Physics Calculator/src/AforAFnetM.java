/*
 * Program: A for A = Fnet / M
 * Programmer: Jay
 * Date: 4/29/010
 * Filename: AFnetM.java
 * Purpose: To solve for A
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AforAFnetM extends JFrame implements ActionListener {

	//items used in frame
	public JLabel startupAlabel;
	public JTextField Mfield;
	public JLabel Mlabel;
	public JLabel Fnetlabel;
	public static JButton calculate;
	public JButton GetFnetNum;
	public JButton backtoAFnetM;
	public JButton backtoForcesInOneDimensionEquations;
	public JButton backtoMainForm;
	public double finalfnet = 0;
	public double total = 0;
	
	public AforAFnetM()
	{
		super("A for A = Fnet * M");
	}
	
	//used to create menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToAFnetM = new JMenuItem("Back To A = Fnet / M");
		mnuFileBackBackToAFnetM.setMnemonic(KeyEvent.VK_N);
		mnuFileBackBackToAFnetM.setDisplayedMnemonicIndex(13);
		mnuFileBackBackToAFnetM.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAFnetM);
		
		JMenuItem mnuFileBackBackToForcesInOneDimensionEquations = new JMenuItem("Back To Forces In One Dimension Equations");
		mnuFileBackBackToForcesInOneDimensionEquations.setMnemonic(KeyEvent.VK_D);
		mnuFileBackBackToForcesInOneDimensionEquations.setDisplayedMnemonicIndex(22);
		mnuFileBackBackToForcesInOneDimensionEquations.setActionCommand("Back To Forces In One Dimension Equations2");
		mnuFileBackBackToForcesInOneDimensionEquations.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToForcesInOneDimensionEquations);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(8);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//used to hold items in frame
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupAlabel = new JLabel("Please enter in information below to solve for A.");
		northpanel.add(startupAlabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new FlowLayout());
		Fnetlabel = new JLabel("Please click Fnet Values button below to enter the values for the forces before you click calculate");
		centerpanel.add(Fnetlabel);
		Mfield = new JTextField(10);
		Mlabel = new JLabel("M");
		centerpanel.add(Fnetlabel);
		centerpanel.add(Mfield);
		centerpanel.add(Mlabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		GetFnetNum = new JButton("Enter Fnet Values");
		GetFnetNum.setActionCommand("Enter Fnet Values");
		GetFnetNum.addActionListener(this);
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		calculate.enable(false);
		backtoAFnetM = new JButton("Back To A = Fnet / M");
		backtoAFnetM.setActionCommand("Back To A = Fnet / M");
		backtoAFnetM.addActionListener(this);
		backtoForcesInOneDimensionEquations = new JButton("Back To Forces In One Dimension Equations");
		backtoForcesInOneDimensionEquations.setActionCommand("Back To Forces In One Dimension Equations");
		backtoForcesInOneDimensionEquations.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(GetFnetNum);
		southpanel.add(calculate);
		southpanel.add(backtoForcesInOneDimensionEquations);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel,BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel,BorderLayout.SOUTH);
		
		return c;
	}
	
	//used to implement actions of button clicks and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To A = Fnet / M2"))
		{
			AFnetM a = new AFnetM();
			a.setJMenuBar(a.createMenuBar());
			a.setContentPane(a.createContentPane());
			a.setSize(600,375);
			this.hide();
			a.show();
		}
		
		else if(arg.equals("Back To A = Fnet / M"))
		{
			AFnetM a2 = new AFnetM();
			a2.setJMenuBar(a2.createMenuBar());
			a2.setContentPane(a2.createContentPane());
			a2.setSize(600,375);
			this.hide();
			a2.show();
		}
		
		else if(arg.equals("Back To Forces In One Dimension Equations2"))
		{
			ForcesInOneDimensionEquations force = new ForcesInOneDimensionEquations();
			force.setJMenuBar(force.createMenuBar());
			force.setContentPane(force.createContentPane());
			force.setSize(600,375);
			this.hide();
			force.show();
		}
		
		else if(arg.equals("Back To Forces In One Dimension Equations"))
		{
			ForcesInOneDimensionEquations force2 = new ForcesInOneDimensionEquations();
			force2.setJMenuBar(force2.createMenuBar());
			force2.setContentPane(force2.createContentPane());
			force2.setSize(600,375);
			this.hide();
			force2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Enter Fnet Values"))
		{
			
			String fnetstr;
			int fnet = 0;
			double forcevalue = 0;
			String fnetforcestring;
			
			fnetstr = JOptionPane.showInputDialog(null,"How Many Forces Are Acting On The Object");
			
			try
			{
				fnet = Integer.parseInt(fnetstr);
				if(fnet < 0 || fnetstr == null)throw new Exception();
			}
			catch(Exception c)
			{
				JOptionPane.showMessageDialog(null,"You must enter integers only no decimals or words and reclick Enter Fnet Values Button and Try Again","Error",JOptionPane.INFORMATION_MESSAGE);
				calculate.enable(false);
				
			}
			
			int fnetforce[] = new int[fnet];
			
			for(int i = 0; i < fnetforce.length; i++)
			{
				try
				{
						
					fnetforcestring = JOptionPane.showInputDialog(null,"What is value of Force " + i);
					forcevalue = Double.parseDouble(fnetforcestring);
					finalfnet += forcevalue;
					total = finalfnet;
					if(fnetforcestring == null)throw new Exception();
				}
			    
				catch(Exception d)
				{
					JOptionPane.showMessageDialog(null,"You can only enter numbers into these boxes","Error",JOptionPane.INFORMATION_MESSAGE);
					calculate.enable(false);
				}
			}
			
			calculate.enable(true);
			
		}
		
		else if(arg.equals("Calculate2"))
		{
			String mstring;
			double m = 0;
			double a = 0;
			
			mstring = Mfield.getText();
			
			try
			{
				m = Double.parseDouble(mstring);
				a = total / m;
				JOptionPane.showMessageDialog(null,"The Answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Mfield.setText("");
				if(mstring == null || m == 0)throw new Exception();
				total = 0;
			}
			catch(Exception f)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals.","Error",JOptionPane.INFORMATION_MESSAGE);
				Mfield.setText("");
				total = 0;
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String mstring;
			double m = 0;
			double a = 0;
			
			mstring = Mfield.getText();
			
			try
			{
				m = Double.parseDouble(mstring);
				a = total / m;
				JOptionPane.showMessageDialog(null,"The Answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Mfield.setText("");
				if(mstring == null || m == 0)throw new Exception();
				total = 0;
			}
			catch(Exception f)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals.","Error",JOptionPane.INFORMATION_MESSAGE);
				Mfield.setText("");
				total = 0;
			}
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please click the get Fnet values button to enter in fnet values and then click calculate after you alo enter m values","Help",JOptionPane.INFORMATION_MESSAGE);
		}
		
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		AforAFnetM a = new AforAFnetM();
		a.setJMenuBar(a.createMenuBar());
		a.setContentPane(a.createContentPane());
		a.setSize(600,375);
		a.setVisible(true);
	}
}
