/*
 * Program: Forces In Multiple Dimensions Form
 * Programmer: Jay
 * Date: 4/30/2010
 * Filename: ForcesInMultipleDimensions.java
 * Purpose: to select equations to solve for
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ForcesInMultipleDimensions extends JFrame implements ActionListener{

	//items used to select equation
	public JLabel startuplabel;
	public JButton R2A2B2;
	public JButton R2A2B22ABCos;
	public JButton AcV2DividedByR;
	public JButton backtoMainForm;
	
	
	public ForcesInMultipleDimensions()
	{
		super("Forces In Multiple Dimensions Form");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileBack = new JMenuItem("Back To Main Form");
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFileBack.setActionCommand("Back To Main Form2");
		mnuFileBack.addActionListener(this);
		mnuFile.add(mnuFileBack);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseR2A2B2 = new JMenuItem("R^2 = A^2 + B^2");
		mnuChooseR2A2B2.setMnemonic(KeyEvent.VK_R);
		mnuChooseR2A2B2.setDisplayedMnemonicIndex(0);
		mnuChooseR2A2B2.setActionCommand("R^2 = A^2 + B^22");
		mnuChooseR2A2B2.addActionListener(this);
		mnuChoose.add(mnuChooseR2A2B2);
		
		JMenuItem mnuChooseR2A2B22ABCos = new JMenuItem("R^2 = A^2 + B^2-2ABCos(Angle)");
		mnuChooseR2A2B22ABCos.setMnemonic(KeyEvent.VK_O);
		mnuChooseR2A2B22ABCos.setDisplayedMnemonicIndex(21);
		mnuChooseR2A2B22ABCos.setActionCommand("R^2 = A^2 + B^2-2ABCos(Angle)2");
		mnuChooseR2A2B22ABCos.addActionListener(this);
		mnuChoose.add(mnuChooseR2A2B22ABCos);
		
		JMenuItem mnuChooseAcV2DividedByR = new JMenuItem("Ac = V^2 / R ");
		mnuChooseAcV2DividedByR.setMnemonic(KeyEvent.VK_V);
		mnuChooseAcV2DividedByR.setDisplayedMnemonicIndex(5);
		mnuChooseAcV2DividedByR.setActionCommand("Ac = V^2 / R2");
		mnuChooseAcV2DividedByR.addActionListener(this);
		mnuChoose.add(mnuChooseAcV2DividedByR);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuChoose.setMnemonic(KeyEvent.VK_O);
		mnuChoose.setDisplayedMnemonicIndex(3);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a equation below to solve for it");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		R2A2B2 = new JButton("R^2 = A^2 + B^2");
		R2A2B2.setActionCommand("R^2 = A^2 + B^2");
		R2A2B2.addActionListener(this);
		buttonpanel.add(R2A2B2);
		R2A2B22ABCos= new JButton("R^2 = A^2 + B^2-2ABCos(Angle)");
		R2A2B22ABCos.setActionCommand("R^2 = A^2 + B^2-2ABCos(Angle)");
		R2A2B22ABCos.addActionListener(this);
		buttonpanel.add(R2A2B22ABCos);
		AcV2DividedByR = new JButton("Ac = V^2 / R");
		AcV2DividedByR.setActionCommand("Ac = V^2 / R");
		AcV2DividedByR.addActionListener(this);
		buttonpanel.add(AcV2DividedByR);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoMainForm);
		
		Container q = getContentPane();
		q.setLayout(new BorderLayout());
		q.add(labelpanel,BorderLayout.NORTH);
		q.add(buttonpanel,BorderLayout.CENTER);
		
		return q;
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("R^2 = A^2 + B^22"))
		{
			R2A2B2 r = new R2A2B2();
			r.setJMenuBar(r.createMenuBar());
			r.setContentPane(r.createContentPane());
			r.setSize(600,375);
			this.hide();
			r.show();
		}
		
		else if(arg.equals("R^2 = A^2 + B^2"))
		{
			R2A2B2 r2 = new R2A2B2();
			r2.setJMenuBar(r2.createMenuBar());
			r2.setContentPane(r2.createContentPane());
			r2.setSize(600,375);
			this.hide();
			r2.show();
		}
		
		else if(arg.equals("R^2 = A^2 + B^2-2ABCos(Angle)2"))
		{
			R2A2B22ABCos rabcos = new R2A2B22ABCos();
			rabcos.setJMenuBar(rabcos.createMenuBar());
			rabcos.setContentPane(rabcos.createContentPane());
			rabcos.setSize(600,375);
			this.hide();
			rabcos.show();
		}
		
		else if(arg.equals("R^2 = A^2 + B^2-2ABCos(Angle)"))
		{
			R2A2B22ABCos rabcos2 = new R2A2B22ABCos();
			rabcos2.setJMenuBar(rabcos2.createMenuBar());
			rabcos2.setContentPane(rabcos2.createContentPane());
			rabcos2.setSize(600,375);
			this.hide();
			rabcos2.show();
		}
		
		else if(arg.equals("Ac = V^2 / R2"))
		{
			AcV2R ac = new AcV2R();
			ac.setJMenuBar(ac.createMenuBar());
			ac.setContentPane(ac.createContentPane());
			ac.setSize(600,375);
			this.hide();
			ac.show();
		}
		
		else if(arg.equals("Ac = V^2 / R"))
		{
			AcV2R ac2 = new AcV2R();
			ac2.setJMenuBar(ac2.createMenuBar());
			ac2.setContentPane(ac2.createContentPane());
			ac2.setSize(600,375);
			this.hide();
			ac2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please select a button of a equation. You will then be taken to that equations form to choose a variable to solve for and then to a form to solve for that variable. This can be done by menu or button.","Help",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		ForcesInMultipleDimensions forces = new ForcesInMultipleDimensions();
		forces.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		forces.setJMenuBar(forces.createMenuBar());
		forces.setContentPane(forces.createContentPane());
		forces.setSize(600,375);
		forces.setVisible(true);
	}
	
}
