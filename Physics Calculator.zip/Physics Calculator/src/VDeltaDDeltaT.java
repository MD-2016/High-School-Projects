import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class VDeltaDDeltaT extends JFrame implements ActionListener {

	public JLabel VDeltaDDeltaTlabel;
	public JButton V;
	public JButton DeltaD;
	public JButton DeltaT;
	public JButton backtoRepresentingMotionEquationsForm;
	public JButton backtoMainForm;
	
	public VDeltaDDeltaT()
	{
		super("V = Delta D / Delta T Form");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuBack = new JMenu("Back",true);
		mnuBack.setMnemonic(KeyEvent.VK_B);
		mnuBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuBack);
		
		JMenuItem mnuFileBackToRepresentingMotionEquationsForm = new JMenuItem("Back To Representing Motion Equations Form");
		mnuFileBackToRepresentingMotionEquationsForm.setMnemonic(KeyEvent.VK_R);
		mnuFileBackToRepresentingMotionEquationsForm.setDisplayedMnemonicIndex(1);
		mnuFileBackToRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form2");
		mnuFileBackToRepresentingMotionEquationsForm.addActionListener(this);
		mnuBack.add(mnuFileBackToRepresentingMotionEquationsForm);
		
		JMenuItem mnuFileBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackToMainForm.addActionListener(this);
		mnuFileBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackToMainForm.setDisplayedMnemonicIndex(1);
		mnuBack.add(mnuFileBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseV = new JMenuItem("V");
		mnuChooseV.setMnemonic(KeyEvent.VK_V);
		mnuChooseV.setDisplayedMnemonicIndex(0);
		mnuChooseV.setActionCommand("V2");
		mnuChooseV.addActionListener(this);
		mnuChoose.add(mnuChooseV);
		
		JMenuItem mnuChooseDeltaD = new JMenuItem("Delta D");
		mnuChooseDeltaD.setMnemonic(KeyEvent.VK_D);
		mnuChooseDeltaD.setDisplayedMnemonicIndex(1);
		mnuChooseDeltaD.setActionCommand("Delta D2");
		mnuChooseDeltaD.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaD);
		
		JMenuItem mnuChooseDeltaT = new JMenuItem("Delta T");
		mnuChooseDeltaT.setMnemonic(KeyEvent.VK_T);
		mnuChooseDeltaT.setDisplayedMnemonicIndex(1);
		mnuChooseDeltaT.setActionCommand("Delta T2");
		mnuChooseDeltaT.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaT);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
		mnuAboutInstructions.setMnemonic(KeyEvent.VK_R);
		mnuAboutInstructions.setDisplayedMnemonicIndex(1);
		mnuAboutInstructions.setActionCommand("Instructions");
		mnuAboutInstructions.addActionListener(this);
		mnuAbout.add(mnuAboutInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		VDeltaDDeltaTlabel = new JLabel("Please choose a variable below to solve for V = Delta D / Delta T");
		labelpanel.add(VDeltaDDeltaTlabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		V = new JButton("V");
		V.setActionCommand("V");
		V.addActionListener(this);
		buttonpanel.add(V);
		DeltaD = new JButton("Delta D");
		DeltaD.setActionCommand("Delta D");
		DeltaD.addActionListener(this);
		buttonpanel.add(DeltaD);
		DeltaT = new JButton("Delta T");
		DeltaT.setActionCommand("Delta T");
		DeltaT.addActionListener(this);
		buttonpanel.add(DeltaT);
		backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoRepresentingMotionEquationsForm);
		buttonpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel, BorderLayout.NORTH);
		c.add(buttonpanel, BorderLayout.CENTER);
		
		return c;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Main Form"))
		{
			MainForm s = new MainForm();
			this.hide();
			s.show();
			s.setSize(600,375);
			s.setJMenuBar(s.createMenuBar());
			s.setContentPane(s.createContentPane());
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm w = new MainForm();
			this.hide();
			w.show();
			w.setSize(600,375);
			w.setJMenuBar(w.createMenuBar());
			w.setContentPane(w.createContentPane());
		}
		
		else if(arg.equals("V2"))
		{
			VforVDeltaDDeltaT v = new VforVDeltaDDeltaT();
			v.setJMenuBar(v.createMenuBar());
			v.setContentPane(v.createContentPane());
			v.setSize(900,149);
			this.hide();
			v.show();
		}
		
		else if(arg.equals("V"))
		{
			VforVDeltaDDeltaT v2 = new VforVDeltaDDeltaT();
			v2.setJMenuBar(v2.createMenuBar());
			v2.setContentPane(v2.createContentPane());
			v2.setSize(900,149);
			this.hide();
			v2.show();
		}
		
		else if(arg.equals("Delta D2"))
		{
			DeltaDforVDeltaDDeltaT deltad = new DeltaDforVDeltaDDeltaT();
			deltad.setJMenuBar(deltad.createMenuBar());
			deltad.setContentPane(deltad.createContentPane());
			deltad.setSize(900,149);
			this.hide();
			deltad.show();
		}
		
		else if(arg.equals("Delta D"))
		{

			DeltaDforVDeltaDDeltaT deltad2 = new DeltaDforVDeltaDDeltaT();
			deltad2.setJMenuBar(deltad2.createMenuBar());
			deltad2.setContentPane(deltad2.createContentPane());
			deltad2.setSize(900,149);
			this.hide();
			deltad2.show();
		}
		
		else if(arg.equals("Delta T2"))
		{

			DeltaTforVDeltaDDeltaT deltat = new DeltaTforVDeltaDDeltaT();
			deltat.setJMenuBar(deltat.createMenuBar());
			deltat.setContentPane(deltat.createContentPane());
			deltat.setSize(900,149);
			this.hide();
			deltat.show();
		}
		
		else if(arg.equals("Delta T"))
		{
			DeltaTforVDeltaDDeltaT deltat2 = new DeltaTforVDeltaDDeltaT();
			deltat2.setJMenuBar(deltat2.createMenuBar());
			deltat2.setContentPane(deltat2.createContentPane());
			deltat2.setSize(900,149);
			this.hide();
			deltat2.show();
		}
		
		else if(arg == "Back To Representing Motion Equations Form2")
		{
			RepresentingMotionEquationsSelection motion = new RepresentingMotionEquationsSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		else if(arg == "Back To Representing Motion Equations Form")
		{
			RepresentingMotionEquationsSelection motion2 = new RepresentingMotionEquationsSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		else if(arg == "Instructions")
		{
			JOptionPane.showMessageDialog(null,"Please select a variable below to be taken to solve for that variable for V = Delta D / Delta T","Help",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	public static void main(String[] args)
	{
		 try
		 {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		 }
		 catch(Exception c)
		 {
			 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
		 }
		VDeltaDDeltaT d = new VDeltaDDeltaT ();
		 d.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 d.setJMenuBar(d.createMenuBar());
		 d.setContentPane(d.createContentPane());
		 d.setSize(600,375);
		 d.setVisible(true);
	}
}

