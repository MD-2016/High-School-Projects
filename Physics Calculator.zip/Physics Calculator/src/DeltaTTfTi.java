/*
 * Program: Physics Calculator Program
 * Programmer: Jay
 * Date: 4/22/2010
 * Filename: DeltaTTfTi.java
 * Purpose: choose a variable to solve for in Delta T = tf - ti.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DeltaTTfTi extends JFrame implements ActionListener{

	//JPanels used to hold items
	JPanel labelpanel = new JPanel();
	JPanel buttonpanel = new JPanel();
	
	//Buttons and Labels used for Delta T = Tf - Ti Frame
	JLabel selectvariableDeltaTTfTi = new JLabel("Please select a variable below to solve for Delta T = Tf - Ti. Then you will be taken to a form for variable chosen");
	JButton DeltaT = new JButton("Delta T");
	JButton Tf = new JButton("Tf");
	JButton Ti = new JButton("Ti");
	JButton BackToRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
	JButton BackToMainForm = new JButton("Back To Main Form");
	
	//Constructor method is called
	public DeltaTTfTi()
	{
		super("Delta T = Tf - Ti Form");
	}
	
	//method for making Menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuBack = new JMenu("Back",true);
		mnuBack.setMnemonic(KeyEvent.VK_B);
		mnuBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuBack);
		
		JMenuItem mnuFileBackToRepresentingMotionEquationsForm = new JMenuItem("Back To Representing Motion Equations Form");
		mnuFileBackToRepresentingMotionEquationsForm.setMnemonic(KeyEvent.VK_R);
		mnuFileBackToRepresentingMotionEquationsForm.setDisplayedMnemonicIndex(1);
		mnuFileBackToRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form2");
		mnuFileBackToRepresentingMotionEquationsForm.addActionListener(this);
		mnuBack.add(mnuFileBackToRepresentingMotionEquationsForm);
		
		JMenuItem mnuFileBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackToMainForm.addActionListener(this);
		mnuFileBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackToMainForm.setDisplayedMnemonicIndex(1);
		mnuBack.add(mnuFileBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseDeltaT = new JMenuItem("Delta T");
		mnuChooseDeltaT.setMnemonic(KeyEvent.VK_D);
		mnuChooseDeltaT.setDisplayedMnemonicIndex(1);
		mnuChooseDeltaT.setActionCommand("Delta T2");
		mnuChooseDeltaT.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaT);
		
		JMenuItem mnuChooseTf = new JMenuItem("Tf");
		mnuChooseTf.setMnemonic(KeyEvent.VK_T);
		mnuChooseTf.setDisplayedMnemonicIndex(1);
		mnuChooseTf.setActionCommand("Tf2");
		mnuChooseTf.addActionListener(this);
		mnuChoose.add(mnuChooseTf);
		
		JMenuItem mnuChooseTi = new JMenuItem("Ti");
		mnuChooseTi.setMnemonic(KeyEvent.VK_I);
		mnuChooseTi.setDisplayedMnemonicIndex(1);
		mnuChooseTi.setActionCommand("Ti2");
		mnuChooseTi.addActionListener(this);
		mnuChoose.add(mnuChooseTi);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
		mnuAboutInstructions.setMnemonic(KeyEvent.VK_R);
		mnuAboutInstructions.setDisplayedMnemonicIndex(1);
		mnuAboutInstructions.setActionCommand("Instructions");
		mnuAboutInstructions.addActionListener(this);
		mnuAbout.add(mnuAboutInstructions);
		
		return mnuBar;
	}
	
	//used for creating the Container
	public Container createContentPane()
	{
		labelpanel.setLayout(new FlowLayout());
		labelpanel.add(selectvariableDeltaTTfTi);
		
		buttonpanel.setLayout(new GridLayout(0,1));
		buttonpanel.add(DeltaT);
		DeltaT.addActionListener(this);
		DeltaT.setActionCommand("Delta T");
		buttonpanel.add(Tf);
		Tf.addActionListener(this);
		Tf.setActionCommand("Tf");
		buttonpanel.add(Ti);
		Ti.addActionListener(this);
		Ti.setActionCommand("Ti");
		buttonpanel.add(BackToRepresentingMotionEquationsForm);
		BackToRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
		BackToRepresentingMotionEquationsForm.addActionListener(this);
		buttonpanel.add(BackToMainForm);
		BackToMainForm.setActionCommand("Back To Main Form");
		BackToMainForm.addActionListener(this);
		Container g = getContentPane();
		g.setLayout(new BorderLayout());
		g.add(labelpanel, BorderLayout.NORTH);
		g.add(buttonpanel, BorderLayout.CENTER);
		
		return g;
	}
	
	//used to implement button and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		//go to main form
		if(arg == "Back To Main Form")
		{
			MainForm s = new MainForm();
			this.hide();
			s.show();
			s.setSize(600,375);
			s.setJMenuBar(s.createMenuBar());
			s.setContentPane(s.createContentPane());
		}
		
		//go to main form
		else if(arg == "Back To Main Form2")
		{
			MainForm w = new MainForm();
			this.hide();
			w.show();
			w.setSize(600,375);
			w.setJMenuBar(w.createMenuBar());
			w.setContentPane(w.createContentPane());
		}
		
		//go to solve for tf
		else if(arg == "Tf2")
		{
		  TfforDeltaTTfTi tf = new TfforDeltaTTfTi();
		  tf.setJMenuBar(tf.createMenuBar());
		  tf.setContentPane(tf.createContentPane());
		  tf.setSize(900,149);
		  this.hide();
		  tf.show();
		}
		
		//go to solve for tf
		else if(arg == "Tf")
		{
			  TfforDeltaTTfTi tf2 = new TfforDeltaTTfTi();
			  tf2.setJMenuBar(tf2.createMenuBar());
			  tf2.setContentPane(tf2.createContentPane());
			  tf2.setSize(900,149);
			  this.hide();
			  tf2.show();
		}
		
		//go to solve for ti
		else if(arg == "Ti2")
		{
			  TiforDeltaTTfTi ti = new TiforDeltaTTfTi();
			  ti.setJMenuBar(ti.createMenuBar());
			  ti.setContentPane(ti.createContentPane());
			  ti.setSize(900,149);
			  this.hide();
			  ti.show();
		}
		
		//go to solve for ti
		else if(arg == "Ti")
		{
			  TiforDeltaTTfTi ti2 = new TiforDeltaTTfTi();
			  ti2.setJMenuBar(ti2.createMenuBar());
			  ti2.setContentPane(ti2.createContentPane());
			  ti2.setSize(900,149);
			  this.hide();
			  ti2.show();
		}
		
		//go to solve for delta t
		else if(arg == "Delta T2")
		{
			DeltaTforDeltaTTfTi deltat = new DeltaTforDeltaTTfTi();
			deltat.setJMenuBar(deltat.createMenuBar());
			deltat.setContentPane(deltat.createContentPane());
			deltat.setSize(600,375);
			this.hide();
			deltat.show();
		}
		
		//go to solve for delta t
		else if(arg == "Delta T")
		{
			DeltaTforDeltaTTfTi deltat2 = new DeltaTforDeltaTTfTi();
			deltat2.setJMenuBar(deltat2.createMenuBar());
			deltat2.setContentPane(deltat2.createContentPane());
			deltat2.setSize(600,375);
			this.hide();
			deltat2.show();
		}
		
		//go to representing motion equations form
		else if(arg == "Back To Representing Motion Equations Form2")
		{
			RepresentingMotionEquationsSelection motion = new RepresentingMotionEquationsSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		//go to representing motion equations form
		else if(arg == "Back To Representing Motion Equations Form")
		{
			RepresentingMotionEquationsSelection motion2 = new RepresentingMotionEquationsSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		//how to use the form
		else if(arg == "Instructions")
		{
			JOptionPane.showMessageDialog(null,"Please select a variable below to be taken to solve for that variable for Delta T = Tf - Ti","Help",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	//creates and makes the jframe come alive
	public static void main(String[] args)
	{
		 try
		 {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		 }
		 catch(Exception c)
		 {
			 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
		 }
		DeltaTTfTi d = new DeltaTTfTi();
		 d.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 d.setJMenuBar(d.createMenuBar());
		 d.setContentPane(d.createContentPane());
		 d.setSize(600,375);
		 d.setVisible(true);
	}
	
}
