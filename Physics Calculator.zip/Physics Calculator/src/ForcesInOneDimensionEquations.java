/*
 * Program: Forces In One Dimension Equations Form
 * Programmer: Jay
 * Date: 4/28/010
 * Filename: ForcesInOneDimensionEquations.java
 * Purpose: To choose a equation to solve to go into solving for
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ForcesInOneDimensionEquations extends JFrame implements ActionListener{

	//items used for this form
	public JLabel startuplabel;
	public JButton AFnetM;
	public JButton FgMG;
	public JButton backtoMainForm;
	
	//constructor method
	public ForcesInOneDimensionEquations()
	{
		super("Forces In One Dimension Equations Form");
	}
	
	//creates menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackToMainForm.setMnemonic(KeyEvent.VK_B);
		mnuFileBackToMainForm.setDisplayedMnemonicIndex(0);
		mnuFileBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackToMainForm.addActionListener(this);
		mnuFile.add(mnuFileBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseAFnetM = new JMenuItem("A = Fnet / M");
		mnuChooseAFnetM.setMnemonic(KeyEvent.VK_M);
		mnuChooseAFnetM.setDisplayedMnemonicIndex(11);
		mnuChooseAFnetM.setActionCommand("A = Fnet / M2");
		mnuChooseAFnetM.addActionListener(this);
		mnuChoose.add(mnuChooseAFnetM);
		
		JMenuItem mnuChooseFgMG = new JMenuItem("Fg = MG");
		mnuChooseFgMG.setMnemonic(KeyEvent.VK_G);
		mnuChooseFgMG.setDisplayedMnemonicIndex(6);
		mnuChooseFgMG.setActionCommand("Fg = MG2");
		mnuChooseFgMG.addActionListener(this);
		mnuChoose.add(mnuChooseFgMG);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//container method to hold items
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a equation to solve for below.");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		AFnetM = new JButton("A = Fnet / M");
		AFnetM.setActionCommand("A = Fnet / M");
		AFnetM.addActionListener(this);
		buttonpanel.add(AFnetM);
		FgMG = new JButton("Fg = MG");
		FgMG.setActionCommand("Fg = MG");
		FgMG.addActionListener(this);
		buttonpanel.add(FgMG);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoMainForm);
		
		Container f = getContentPane();
		f.setLayout(new BorderLayout());
		f.add(labelpanel,BorderLayout.NORTH);
		f.add(buttonpanel,BorderLayout.CENTER);
		
		return f;
	}
	
	//used to run button and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("A = Fnet / M2"))
		{
			AFnetM afnetm = new AFnetM();
			afnetm.setJMenuBar(afnetm.createMenuBar());
			afnetm.setContentPane(afnetm.createContentPane());
			afnetm.setSize(600,375);
			this.hide();
			afnetm.show();
		}
		
		else if(arg.equals("A = Fnet / M"))
		{
			AFnetM afnetm2 = new AFnetM();
			afnetm2.setJMenuBar(afnetm2.createMenuBar());
			afnetm2.setContentPane(afnetm2.createContentPane());
			afnetm2.setSize(600,375);
			this.hide();
			afnetm2.show();
		}
		
		else if(arg.equals("Fg = MG2"))
		{
			FgMG fg = new FgMG();
			fg.setJMenuBar(fg.createMenuBar());
			fg.setContentPane(fg.createContentPane());
			fg.setSize(600,375);
			this.hide();
			fg.show();
		}
		
		else if(arg.equals("Fg = MG"))
		{
			FgMG fg2 = new FgMG();
			fg2.setJMenuBar(fg2.createMenuBar());
			fg2.setContentPane(fg2.createContentPane());
			fg2.setSize(600,375);
			this.hide();
			fg2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please select a equation to go to that equation to solve for that equations variable","How To",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	//creates and opens frame
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		ForcesInOneDimensionEquations force = new ForcesInOneDimensionEquations();
		force.setJMenuBar(force.createMenuBar());
		force.setContentPane(force.createContentPane());
		force.setSize(600,375);
		force.setVisible(true);
	}
}
