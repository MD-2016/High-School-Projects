/*
 * Program: A for A = Delta V / Delta T  Form
 * Programmer: Jay
 * Date: 4/22/2010
 * Filename: AforADeltaVDeltaT.java
 * Purpose: solve A for A = Delta V / Delta T
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AforADeltaVDeltaT extends JFrame implements ActionListener{

	//items used for solving 
	public JLabel startupAlabel;
	public JButton calculate;
	public JLabel DeltaVlabel;
	public JLabel DeltaTlabel;
	public JTextField DeltaVfield;
	public JTextField DeltaTfield;
	public JButton backtoADeltaVDeltaT; 
	public JButton backtoAcceleratingMotionEquationForm;
	public JButton backtoMainForm;
	
	//Constructor method for calling class
	public AforADeltaVDeltaT()
	{
		super("A for A = Delta V / Delta T Form");
	}
	
	//used to create the menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.addActionListener(this);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFile.add(mnuFileCalculate);
		
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackToADeltaVDeltaT = new JMenuItem("Back To A = Delta V / Delta T Form");
		mnuFileBackToADeltaVDeltaT.setMnemonic(KeyEvent.VK_V);
		mnuFileBackToADeltaVDeltaT.setDisplayedMnemonicIndex(18);
		mnuFileBackToADeltaVDeltaT.setActionCommand("Back To A = Delta V / Delta T2");
		mnuFileBackToADeltaVDeltaT.addActionListener(this);
		mnuFileBack.add(mnuFileBackToADeltaVDeltaT);
		
		JMenuItem mnuFileBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackToMainForm.setDisplayedMnemonicIndex(0);
		mnuFileBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackToMainForm.addActionListener(this);
		mnuFile.add(mnuFileBackToMainForm);
		
		
		JMenuItem mnuBackToAcceleratingMotionEquationsForm = new JMenuItem("Back To Accelerating Motion Equations Form");
		mnuBackToAcceleratingMotionEquationsForm.setMnemonic(KeyEvent.VK_E);
		mnuBackToAcceleratingMotionEquationsForm.setDisplayedMnemonicIndex(4);
		mnuBackToAcceleratingMotionEquationsForm.setActionCommand("Back To Accelerating Motion Equations Form2");
		mnuBackToAcceleratingMotionEquationsForm.addActionListener(this);
		mnuFileBack.add(mnuBackToAcceleratingMotionEquationsForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_O);
		mnuAbout.setDisplayedMnemonicIndex(3);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//used to for adding items to frame
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupAlabel = new JLabel("Please enter in information to solve for A below.");
		northpanel.add(startupAlabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(2,2));
		DeltaVlabel = new JLabel("Delta V");
		DeltaVfield = new JTextField(10);
		centerpanel.add(DeltaVfield);
		centerpanel.add(DeltaVlabel);
		DeltaTfield = new JTextField(10);
		DeltaTlabel = new JLabel("Delta T");
		centerpanel.add(DeltaTfield);
		centerpanel.add(DeltaTlabel);
		
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		southpanel.add(calculate);
		backtoADeltaVDeltaT = new JButton("Back To A = Delta V / Delta T");
		backtoADeltaVDeltaT.setActionCommand("Back To A = Delta V / Delta T");
		backtoADeltaVDeltaT.addActionListener(this);
		southpanel.add(backtoADeltaVDeltaT);
		backtoAcceleratingMotionEquationForm = new JButton("Back To Accelerating Motion Equation Form");
		backtoAcceleratingMotionEquationForm.setActionCommand("Back To Accelerating Motion Equation Form");
		backtoAcceleratingMotionEquationForm.addActionListener(this);
		southpanel.add(backtoAcceleratingMotionEquationForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel, BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel,BorderLayout.SOUTH);
		
		return c;
		
	}
	
	//makes the events of button and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		//go to main menu
		if(arg.equals("Back To Main Form2"))
		{
			MainForm l = new MainForm();
			l.setJMenuBar(l.createMenuBar());
			l.setContentPane(l.createContentPane());
			l.setSize(600,375);
			this.hide();
			l.show();
		}
		
		//go to main menu
		else if(arg.equals("Back To Main Form"))
		{
			MainForm l2 = new MainForm();
			l2.setJMenuBar(l2.createMenuBar());
			l2.setContentPane(l2.createContentPane());
			l2.setSize(600,375);
			this.hide();
			l2.show();
		}
		
		//go to acceleration equations page.
		else if(arg.equals("Back To Accelerating Motion Equations Form2"))
		{
			AcceleratingMotionEquationSelection accelerate = new AcceleratingMotionEquationSelection();
			accelerate.setJMenuBar(accelerate.createMenuBar());
			accelerate.setContentPane(accelerate.createContentPane());
			accelerate.setSize(600,375);
			accelerate.show();
			this.hide();
		}
		
		//go to acceleration equations page
		else if(arg.equals("Back To Accelerating Motion Equation Form"))
		{
			AcceleratingMotionEquationSelection accelerate2 = new AcceleratingMotionEquationSelection();
			accelerate2.setJMenuBar(accelerate2.createMenuBar());
			accelerate2.setContentPane(accelerate2.createContentPane());
			accelerate2.setSize(600,375);
			accelerate2.show();
			this.hide();
		}
		
		//go to A = Delta V / Delta T form
		else if(arg.equals("Back To A = Delta V / Delta T2"))
		{
			ADeltaVDeltaT A = new ADeltaVDeltaT();
			A.setJMenuBar(A.createMenuBar());
			A.setContentPane(A.createContentPane());
			A.setSize(600,375);
			this.hide();
			A.show();
		}
		
		//go to A = Delta V / Delta T form
		else if(arg.equals("Back To A = Delta V / Delta T"))
		{
			ADeltaVDeltaT A2 = new ADeltaVDeltaT();
			A2.setJMenuBar(A2.createMenuBar());
			A2.setContentPane(A2.createContentPane());
			A2.setSize(600,375);
			this.hide();
			A2.show();
		}
		
		//solve for A
		else if(arg.equals("Calculate2"))
		{
			//variables used for solving
			String deltavstring;
			String deltatstring;
			double deltav = 0;
			double deltat = 0;
			double a = 0;
			
			deltavstring = DeltaVfield.getText();
			deltatstring = DeltaTfield.getText();
			
			//used for erroring handling
			try
			{
				deltav = Double.parseDouble(deltavstring);
				deltat = Double.parseDouble(deltatstring);
				a = deltav / deltat;
				JOptionPane.showMessageDialog(null,"The Answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				DeltaVfield.setText("");
				DeltaTfield.setText("");
				if(deltavstring == null || deltatstring == null || deltat == 0)throw new Exception();
			}
			catch(Exception f)
			{
				JOptionPane.showMessageDialog(null,"Only Integers and Decimals allowed please","Error",JOptionPane.INFORMATION_MESSAGE);
				DeltaVfield.setText("");
				DeltaTfield.setText("");
			}
			
		}
		
		//solve for A
		else if(arg.equals("Calculate"))
		{
			//variables used for solving
			String deltavstring;
			String deltatstring;
			double deltav = 0;
			double deltat = 0;
			double a = 0;
			
			deltavstring = DeltaVfield.getText();
			deltatstring = DeltaTfield.getText();
			
			//used for erroring handling
			try
			{
				deltav = Double.parseDouble(deltavstring);
				deltat = Double.parseDouble(deltatstring);
				a = deltav / deltat;
				JOptionPane.showMessageDialog(null,"The Answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				DeltaVfield.setText("");
				DeltaTfield.setText("");
				if(deltavstring == null || deltatstring == null || deltat == 0)throw new Exception();
			}
			catch(Exception f)
			{
				JOptionPane.showMessageDialog(null,"Only Integers and Decimals allowed please","Error",JOptionPane.INFORMATION_MESSAGE);
				DeltaVfield.setText("");
				DeltaTfield.setText("");
			}
			
		}
		
		
		//instructions on how to use form
		else if (arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"enter in data to solve for A and the hit the calculate button or in the file menu to get the answer","Help",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	//creates and runs frame
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		AforADeltaVDeltaT A2 = new AforADeltaVDeltaT();
		A2.setJMenuBar(A2.createMenuBar());
		A2.setContentPane(A2.createContentPane());
		A2.setSize(900,149);
		A2.setVisible(true);
		A2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
}
