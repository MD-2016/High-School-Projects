/*
 * Program: Df = Di + ViTf + 1/2 ATf^2 Form
 * Programmer: Jay
 * Date: 4/26/010
 * Filename: DfDiViTfOneHalfATf2.java
 * Purpose: To choose a variable to solve for in Df = Di + ViTf + 1/2 ATf^2.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DfDiViTfOneHalfATf2 extends JFrame implements ActionListener{

	//items used in frame
	public JButton Df;
	public JButton Di;
	public JButton Vi;
	public JButton Tf;
	public JLabel startuplabel;
	public JButton backtoAcceleratingMotionForm;
	public JButton backtoMainForm;
	
	public DfDiViTfOneHalfATf2()
	{
		super("Df = Di + ViTf + 1/2 ATf^2 Form");
	}
	
	//used for menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToAcceleratingMotionForm = new JMenuItem("Back To Accelerating Motion Form");
		mnuFileBackBackToAcceleratingMotionForm.setMnemonic(KeyEvent.VK_A);
		mnuFileBackBackToAcceleratingMotionForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form2");
		mnuFileBackBackToAcceleratingMotionForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcceleratingMotionForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseDf = new JMenuItem("Df");
		mnuChooseDf.setMnemonic(KeyEvent.VK_D);
		mnuChooseDf.setDisplayedMnemonicIndex(0);
		mnuChooseDf.setActionCommand("Df2");
		mnuChooseDf.addActionListener(this);
		mnuChoose.add(mnuChooseDf);
		
		JMenuItem mnuChooseDi = new JMenuItem("Di");
		mnuChooseDi.setMnemonic(KeyEvent.VK_I);
		mnuChooseDi.setDisplayedMnemonicIndex(1);
		mnuChooseDi.setActionCommand("Di2");
		mnuChooseDi.addActionListener(this);
		mnuChoose.add(mnuChooseDi);
		
		JMenuItem mnuChooseVi = new JMenuItem("Vi");
		mnuChooseVi.setMnemonic(KeyEvent.VK_V);
		mnuChooseVi.setDisplayedMnemonicIndex(0);
		mnuChooseVi.setActionCommand("Vi2");
		mnuChooseVi.addActionListener(this);
		mnuChoose.add(mnuChooseVi);
		
		
		JMenuItem mnuChooseTf = new JMenuItem("Tf");
		mnuChooseTf.setMnemonic(KeyEvent.VK_T);
		mnuChooseTf.setDisplayedMnemonicIndex(0);
		mnuChooseTf.setActionCommand("Tf2");
		mnuChooseTf.addActionListener(this);
		mnuChoose.add(mnuChooseTf);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_U);
		mnuAbout.setDisplayedMnemonicIndex(4);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_N);
		mnuInstructions.setDisplayedMnemonicIndex(1);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//container to hold the items
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a variable below to solve for in Df = Di + ViTf + 1/2 ATf^2");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		Df = new JButton("Df");
		Df.setActionCommand("Df");
		Df.addActionListener(this);
		buttonpanel.add(Df);
		Di = new JButton("Di");
		Di.setActionCommand("Di");
		Di.addActionListener(this);
		buttonpanel.add(Di);
		Vi = new JButton("Vi");
		Vi.setActionCommand("Vi");
		Vi.addActionListener(this);
		buttonpanel.add(Vi);
		Tf = new JButton("Tf");
		Tf.setActionCommand("Tf");
		Tf.addActionListener(this);
		buttonpanel.add(Tf);
		backtoAcceleratingMotionForm = new JButton("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.addActionListener(this);
		buttonpanel.add(backtoAcceleratingMotionForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel, BorderLayout.NORTH);
		c.add(buttonpanel,BorderLayout.CENTER);
		
		return c;
	}
	
	//action commands for button clicks and menu item clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Accelerating Motion Form2"))
		{
			AcceleratingMotionEquationSelection k = new AcceleratingMotionEquationSelection();
			k.setJMenuBar(k.createMenuBar());
			k.setContentPane(k.createContentPane());
			k.setSize(600,375);
			this.hide();
			k.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form"))
		{
			AcceleratingMotionEquationSelection k2 = new AcceleratingMotionEquationSelection();
			k2.setJMenuBar(k2.createMenuBar());
			k2.setContentPane(k2.createContentPane());
			k2.setSize(600,375);
			this.hide();
			k2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Df2"))
		{
		  DfforDfDiViTfOneHalfATf2 df = new DfforDfDiViTfOneHalfATf2();
		  df.setJMenuBar(df.createMenuBar());
		  df.setContentPane(df.createContentPane());
		  df.setSize(600,375);
		  this.hide();
		  df.show();
		}
		
		else if(arg.equals("Df"))
		{
			  DfforDfDiViTfOneHalfATf2 df2 = new DfforDfDiViTfOneHalfATf2();
			  df2.setJMenuBar(df2.createMenuBar());
			  df2.setContentPane(df2.createContentPane());
			  df2.setSize(600,375);
			  this.hide();
			  df2.show();
		}
		
		else if(arg.equals("Di2"))
		{
			  DiforDfDiViTfOneHalfATf2 di = new DiforDfDiViTfOneHalfATf2();
			  di.setJMenuBar(di.createMenuBar());
			  di.setContentPane(di.createContentPane());
			  di.setSize(600,375);
			  this.hide();
			  di.show();
		}
		
		else if(arg.equals("Di"))
		{
			  DiforDfDiViTfOneHalfATf2 di2 = new DiforDfDiViTfOneHalfATf2();
			  di2.setJMenuBar(di2.createMenuBar());
			  di2.setContentPane(di2.createContentPane());
			  di2.setSize(600,375);
			  this.hide();
			  di2.show();
		}
		
		else if(arg.equals("Vi2"))
		{
			  ViforDfDiViTfOneHalfATf2 vi = new ViforDfDiViTfOneHalfATf2();
			  vi.setJMenuBar(vi.createMenuBar());
			  vi.setContentPane(vi.createContentPane());
			  vi.setSize(600,375);
			  this.hide();
			  vi.show();
		}
		
		else if(arg.equals("Vi"))
		{
			  ViforDfDiViTfOneHalfATf2 vi2 = new ViforDfDiViTfOneHalfATf2();
			  vi2.setJMenuBar(vi2.createMenuBar());
			  vi2.setContentPane(vi2.createContentPane());
			  vi2.setSize(600,375);
			  this.hide();
			  vi2.show();
		}
		
		
		else if(arg.equals("Tf2"))
		{
			  TfforDfDiViTfOneHalfATf2 tf = new TfforDfDiViTfOneHalfATf2();
			  tf.setJMenuBar(tf.createMenuBar());
			  tf.setContentPane(tf.createContentPane());
			  tf.setSize(600,375);
			  this.hide();
			  tf.show();
		}
		
		else if(arg.equals("Tf"))
		{
			  TfforDfDiViTfOneHalfATf2 tf2 = new TfforDfDiViTfOneHalfATf2();
			  tf2.setJMenuBar(tf2.createMenuBar());
			  tf2.setContentPane(tf2.createContentPane());
			  tf2.setSize(600,375);
			  this.hide();
			  tf2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please select and variable and you will then be taken to a form to solve for chosen variable","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		DfDiViTfOneHalfATf2 dfdivitfonehalfatf2 = new DfDiViTfOneHalfATf2();
		dfdivitfonehalfatf2.setJMenuBar(dfdivitfonehalfatf2.createMenuBar());
		dfdivitfonehalfatf2.setContentPane(dfdivitfonehalfatf2.createContentPane());
		dfdivitfonehalfatf2.setSize(600,375);
		dfdivitfonehalfatf2.setVisible(true);
	}
}
