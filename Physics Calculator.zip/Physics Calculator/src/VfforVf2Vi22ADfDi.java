/*
 * Program: Vf for Vf^2 = Vi^2 + 2A(Df - Di) Form
 * Programmer: Jay
 * Date: 4/26/010
 * Filename: VfforVf2Vi22ADfDi.java
 * Purpose: To choose a variable to solve for in Vf^2 = Vi^2 + 2A(Df -Di) Form.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class VfforVf2Vi22ADfDi extends JFrame implements ActionListener{

	//items used in frame
	public JButton calculate;
	public JTextField Vifield;
	public JTextField Afield;
	public JTextField Dffield;
	public JTextField Difield;
	public JLabel startupVflabel;
	public JLabel Vilabel;
	public JLabel Alabel;
	public JLabel Dflabel;
	public JLabel Dilabel;
	public JButton backtoVf2Vi22ADfDi;
	public JButton backtoAcceleratingMotionForm;
	public JButton backtoMainForm;
	
	public VfforVf2Vi22ADfDi()
	{
		super("Vf for Vf^2 = Vi^2 + 2A(Df - Di) Form");
	}
	
	//used for menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToVf2Vi22ADfDiForm = new JMenuItem("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form");
		mnuFileBackBackToVf2Vi22ADfDiForm.setMnemonic(KeyEvent.VK_V);
		mnuFileBackBackToVf2Vi22ADfDiForm.setDisplayedMnemonicIndex(0);
		mnuFileBackBackToVf2Vi22ADfDiForm.setActionCommand("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form2");
		mnuFileBackBackToVf2Vi22ADfDiForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToVf2Vi22ADfDiForm);
		
		JMenuItem mnuFileBackBackToAcceleratingMotionForm = new JMenuItem("Back To Accelerating Motion Form");
		mnuFileBackBackToAcceleratingMotionForm.setMnemonic(KeyEvent.VK_A);
		mnuFileBackBackToAcceleratingMotionForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form2");
		mnuFileBackBackToAcceleratingMotionForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcceleratingMotionForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_U);
		mnuAbout.setDisplayedMnemonicIndex(4);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_N);
		mnuInstructions.setDisplayedMnemonicIndex(1);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//container to hold the items
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupVflabel = new JLabel("enter information below to solve for Vf");
		northpanel.add(startupVflabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(5,5));
		Vifield = new JTextField(10);
		Afield = new JTextField(10);
		Dffield = new JTextField(10);
		Difield = new JTextField(10);
		Vilabel = new JLabel("Vi");
		Alabel = new JLabel("A");
		Dflabel = new JLabel("Df");
		Dilabel = new JLabel("Di");
		centerpanel.add(Vifield);
		centerpanel.add(Vilabel);
		centerpanel.add(Afield);
		centerpanel.add(Alabel);
		centerpanel.add(Dffield);
		centerpanel.add(Dflabel);
		centerpanel.add(Difield);
		centerpanel.add(Dilabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		southpanel.add(calculate);
		backtoVf2Vi22ADfDi = new JButton("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form");
		backtoVf2Vi22ADfDi.setActionCommand("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form");
		backtoVf2Vi22ADfDi.addActionListener(this);
		southpanel.add(backtoVf2Vi22ADfDi);
		backtoAcceleratingMotionForm = new JButton("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.addActionListener(this);
		southpanel.add(backtoAcceleratingMotionForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel,BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel,BorderLayout.SOUTH);
		
		return c;
		
		
	}
	
	//action commands for button clicks and menu item clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Accelerating Motion Form2"))
		{
			AcceleratingMotionEquationSelection k = new AcceleratingMotionEquationSelection();
			k.setJMenuBar(k.createMenuBar());
			k.setContentPane(k.createContentPane());
			k.setSize(600,375);
			this.hide();
			k.show();
		}
		
		else if(arg.equals("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form2"))
		{
			Vf2Vi22ADfDi vfviadfdi = new Vf2Vi22ADfDi();
			vfviadfdi.setJMenuBar(vfviadfdi.createMenuBar());
			vfviadfdi.setContentPane(vfviadfdi.createContentPane());
			vfviadfdi.setSize(600,375);
			this.hide();
			vfviadfdi.show();
		}
		
		else if(arg.equals("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form"))
		{
			Vf2Vi22ADfDi vfviadfdi2 = new Vf2Vi22ADfDi();
			vfviadfdi2.setJMenuBar(vfviadfdi2.createMenuBar());
			vfviadfdi2.setContentPane(vfviadfdi2.createContentPane());
			vfviadfdi2.setSize(600,375);
			this.hide();
			vfviadfdi2.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form"))
		{
			AcceleratingMotionEquationSelection k2 = new AcceleratingMotionEquationSelection();
			k2.setJMenuBar(k2.createMenuBar());
			k2.setContentPane(k2.createContentPane());
			k2.setSize(600,375);
			this.hide();
			k2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String vistring;
			String astring;
			String dfstring;
			String distring;
			
			double vf = 0;
			double vi = 0;
			double a = 0;
			double df = 0;
			double di = 0;
			double prevf = 0;
			double prevf2 = 0;
			double prevf3 = 0;
			
			vistring = Vifield.getText();
			astring = Afield.getText();
			dfstring = Dffield.getText();
			distring = Difield.getText();
			
			try
			{
				vi = Double.parseDouble(vistring);
				a = Double.parseDouble(astring);
				df = Double.parseDouble(dfstring);
				di = Double.parseDouble(distring);
				prevf = Math.pow(vi,2);
				prevf2 = 2 * a * (df - di);
				prevf3 = prevf + prevf2;
				vf = Math.sqrt(prevf3);
				JOptionPane.showMessageDialog(null,"The answer is " + vf,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Vifield.setText("");
				Afield.setText("");
				Dffield.setText("");
				Difield.setText("");
				if(vistring == null || astring == null || dfstring == null || distring == null)throw new Exception();
			}
			catch(Exception r)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals","Error",JOptionPane.INFORMATION_MESSAGE);
				Vifield.setText("");
				Afield.setText("");
				Dffield.setText("");
				Difield.setText("");
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String vistring;
			String astring;
			String dfstring;
			String distring;
			
			double vf = 0;
			double vi = 0;
			double a = 0;
			double df = 0;
			double di = 0;
			double prevf = 0;
			double prevf2 = 0;
			double prevf3 = 0;
			
			vistring = Vifield.getText();
			astring = Afield.getText();
			dfstring = Dffield.getText();
			distring = Difield.getText();
			
			try
			{
				vi = Double.parseDouble(vistring);
				a = Double.parseDouble(astring);
				df = Double.parseDouble(dfstring);
				di = Double.parseDouble(distring);
				prevf = Math.pow(vi,2);
				prevf2 = 2 * a * (df - di);
				prevf3 = prevf + prevf2;
				vf = Math.sqrt(prevf3);
				JOptionPane.showMessageDialog(null,"The answer is " + vf,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Vifield.setText("");
				Afield.setText("");
				Dffield.setText("");
				Difield.setText("");
				if(vistring == null || astring == null || dfstring == null || distring == null)throw new Exception();
			}
			catch(Exception r)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals","Error",JOptionPane.INFORMATION_MESSAGE);
				Vifield.setText("");
				Afield.setText("");
				Dffield.setText("");
				Difield.setText("");
			}
		}
		
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please enter information below and click calculate to solve for unknown variable.","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		VfforVf2Vi22ADfDi vf = new VfforVf2Vi22ADfDi ();
		vf.setJMenuBar(vf.createMenuBar());
		vf.setContentPane(vf.createContentPane());
		vf.setSize(600,375);
		vf.setVisible(true);
	}
}
