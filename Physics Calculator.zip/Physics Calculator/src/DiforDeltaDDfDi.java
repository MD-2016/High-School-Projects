/*
 * Program: Di for Delta D = Df - Di
 * Programmer: Jay
 * Filename: DiforDeltaDDfDi.java
 * Date: 4/19/010
 * Purpose: Solving Di variable in equation Delta D = Df - Di
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DiforDeltaDDfDi extends JFrame implements ActionListener{

	//items used for 
	public JLabel dilabel;
	public JLabel deltadlabel;
	public JLabel dflabel;
	public JTextField DfField;
	public JTextField DeltaDField;
	public JButton calculate;
	public JButton backtoMainForm;
	public JButton backtoRepresentingMotionEquationsForm;
	public JButton backtoDeltaDDfDi;
	
	public DiforDeltaDDfDi()
	{
		super("Di For Delta D = Df - Di Form");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuCalculate = new JMenuItem("Calculate");
		mnuCalculate.setMnemonic(KeyEvent.VK_C);
		mnuCalculate.setDisplayedMnemonicIndex(0);
		mnuCalculate.setActionCommand("Calculate2");
		mnuCalculate.addActionListener(this);
		mnuFile.add(mnuCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToRepresentingMotionEquationsForm = new JMenuItem("Back To Representing Motion Equations Form");
		mnuFileBackBackToRepresentingMotionEquationsForm.setMnemonic(KeyEvent.VK_R);
		mnuFileBackBackToRepresentingMotionEquationsForm.setDisplayedMnemonicIndex(1);
		mnuFileBackBackToRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form2");
		mnuFileBackBackToRepresentingMotionEquationsForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToRepresentingMotionEquationsForm);
		
		JMenuItem mnuFileBackBackToDeltaDDfDiForm = new JMenuItem("Back To Delta D = Df- Di");
		mnuFileBackBackToDeltaDDfDiForm.setMnemonic(KeyEvent.VK_D);
		mnuFileBackBackToDeltaDDfDiForm.setDisplayedMnemonicIndex(1);
		mnuFileBackBackToDeltaDDfDiForm.setActionCommand("Back To Delta D = Df - Di2");
		mnuFileBackBackToDeltaDDfDiForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToDeltaDDfDiForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(8);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(1);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
		
	}
	
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		dilabel = new JLabel("Please enter in information below to solve for Di");
		northpanel.add(dilabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(2,2));
		DeltaDField = new JTextField(10);
		centerpanel.add(DeltaDField);
		deltadlabel = new JLabel("Delta D");
		centerpanel.add(deltadlabel);
		DfField = new JTextField(10);
		centerpanel.add(DfField);
		dflabel = new JLabel("Df");
		centerpanel.add(dflabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.addActionListener(this);
		calculate.setActionCommand("Calculate");
		southpanel.add(calculate);
		backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.addActionListener(this);
		southpanel.add(backtoRepresentingMotionEquationsForm);
		backtoDeltaDDfDi = new JButton("Back To Delta D = Df - Di Form");
		backtoDeltaDDfDi.setActionCommand("Back To Delta D = Df - Di Form");
		backtoDeltaDDfDi.addActionListener(this);
		southpanel.add(backtoDeltaDDfDi);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(backtoMainForm);
		
		Container d = getContentPane();
		d.setLayout(new BorderLayout());
		d.add(northpanel, BorderLayout.NORTH);
		d.add(centerpanel, BorderLayout.CENTER);
		d.add(southpanel, BorderLayout.SOUTH);
		
		return d;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String args = e.getActionCommand();
		
		if(args.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(args.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(args.equals("Back To Representing Motion Equations Form2"))
		{
			RepresentingMotionEquationsSelection motion = new RepresentingMotionEquationsSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		else if(args.equals("Back To Representing Motion Equations Form"))
		{
			RepresentingMotionEquationsSelection motion2 = new RepresentingMotionEquationsSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		else if(args.equals("Back To Delta D = Df - Di2"))
		{
			DeltaDDfDi d = new DeltaDDfDi();
			d.setJMenuBar(d.createMenuBar());
			d.setContentPane(d.createContentPane())	;
			d.setSize(600,375);
			this.hide();
			d.show();
			
		}
		
		else if(args.equals("Back To Delta D = Df - Di Form"))
		{
			DeltaDDfDi d2 = new DeltaDDfDi();
			d2.setJMenuBar(d2.createMenuBar());
			d2.setContentPane(d2.createContentPane())	;
			d2.setSize(600,375);
			this.hide();
			d2.show();
		}
		
		else if(args.equals("Calculate2"))
		{
			String dfstring;
			String deltadstring;
			double df = 0;
			double deltad = 0;
			double di = 0;
			
			try
			{
				deltadstring = DeltaDField.getText();
				dfstring = DfField.getText();
				deltad = Double.parseDouble(deltadstring);
				df = Double.parseDouble(dfstring);
				di = -deltad + df;
				JOptionPane.showMessageDialog(null,"The answer is " + di,"Answer",JOptionPane.INFORMATION_MESSAGE);
				if(dfstring == null || deltadstring == null)throw new Exception();
			}
			catch(Exception f)
			{
				JOptionPane.showMessageDialog(null,"Please enter only integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				DeltaDField.setText("");
				DfField.setText("");
			}
		}
		
		else if(args.equals("Calculate"))
		{
			String dfstring;
			String deltadstring;
			double df = 0;
			double deltad = 0;
			double di = 0;
			
			try
			{
				deltadstring = DeltaDField.getText();
				dfstring = DfField.getText();
				deltad = Double.parseDouble(deltadstring);
				df = Double.parseDouble(dfstring);
				di = -deltad + df;
				JOptionPane.showMessageDialog(null,"The answer is " + di,"Answer",JOptionPane.INFORMATION_MESSAGE);
				if(dfstring == null || deltadstring == null)throw new Exception();
			}
			catch(Exception f)
			{
				JOptionPane.showMessageDialog(null,"Please enter only integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				DeltaDField.setText("");
				DfField.setText("");
			}
		}
		
		else if(args.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please enter in values for Delta D in the box provided and same for Df then press calculate by button or file menu option.","Help",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	public static void main(String[] args)
	{
		 try
		 {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		 }
		 catch(Exception c)
		 {
			 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
		 }
		 JFrame.setDefaultLookAndFeelDecorated(true);
		 DiforDeltaDDfDi f = new DiforDeltaDDfDi();
		 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 f.setJMenuBar(f.createMenuBar());
		 f.setContentPane(f.createContentPane());
		 f.setSize(600,375);
		 f.setVisible(true);
	}
	
}
