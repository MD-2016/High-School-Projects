import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class TiforDeltaTTfTi extends JFrame implements ActionListener {

	public JLabel startupTilabel;
	public JLabel Tflabel;
	public JLabel DeltaTlabel;
	public JTextField Tffield;
	public JTextField DeltaTfield;
	public JButton calculate;
	public JButton backtoMainForm;
	public JButton backtoDeltaTTfTiForm;
	public JButton backtoRepresentingMotionEquationsForm;
	
	public TiforDeltaTTfTi()
	{
		super("Ti for Delta T = Tf - Ti");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuCalculate = new JMenuItem("Calculate");
		mnuCalculate.setMnemonic(KeyEvent.VK_C);
		mnuCalculate.setDisplayedMnemonicIndex(1);
		mnuCalculate.setActionCommand("Calculate2");
		mnuCalculate.addActionListener(this);
		mnuFile.add(mnuCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToDeltaTTfTiForm = new JMenuItem("Back To Delta T = Tf - Ti Form");
		mnuFileBackBackToDeltaTTfTiForm.setMnemonic(KeyEvent.VK_D);
		mnuFileBackBackToDeltaTTfTiForm.setDisplayedMnemonicIndex(1);
		mnuFileBackBackToDeltaTTfTiForm.setActionCommand("Back To Delta T = Tf - Ti Form2");
		mnuFileBackBackToDeltaTTfTiForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToDeltaTTfTiForm);
		
		JMenuItem mnuFileBackBackToRepresentingMotionEquationsForm = new JMenuItem("Back To Representing Motion Equations Form");
		mnuFileBackBackToRepresentingMotionEquationsForm.setMnemonic(KeyEvent.VK_R);
		mnuFileBackBackToRepresentingMotionEquationsForm.setDisplayedMnemonicIndex(1);
		mnuFileBackBackToRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form2");
		mnuFileBackBackToRepresentingMotionEquationsForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToRepresentingMotionEquationsForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(1);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(1);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupTilabel = new JLabel("Please enter in information below to solve for Ti");
		northpanel.add(startupTilabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(2,2));
		Tffield = new JTextField(10);
		centerpanel.add(Tffield);
		Tflabel = new JLabel("Tf");
		centerpanel.add(Tflabel);
		DeltaTfield = new JTextField(10);
		centerpanel.add(DeltaTfield);
		DeltaTlabel = new JLabel("Delta T");
		centerpanel.add(DeltaTlabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		southpanel.add(calculate);
		backtoDeltaTTfTiForm = new JButton("Back To Delta T = Tf - Ti Form");
		backtoDeltaTTfTiForm.setActionCommand("Back To Delta T = Tf - Ti Form");
		backtoDeltaTTfTiForm.addActionListener(this);
		southpanel.add(backtoDeltaTTfTiForm);
		backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.addActionListener(this);
		southpanel.add(backtoRepresentingMotionEquationsForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(backtoMainForm);
		
		Container w = getContentPane();
		w.setLayout(new BorderLayout());
		w.add(northpanel,BorderLayout.NORTH);
		w.add(centerpanel,BorderLayout.CENTER);
		w.add(southpanel,BorderLayout.SOUTH);
		
		return w;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String args = e.getActionCommand();
		
		if(args.equals("Back To Delta T = Tf - Ti Form2"))
		{
			DeltaTTfTi deltaT = new DeltaTTfTi();
			deltaT.setJMenuBar(deltaT.createMenuBar());
			deltaT.setContentPane(deltaT.createContentPane());
			deltaT.setSize(600,375);
			this.hide();
			deltaT.show();
		}
		
		else if(args.equals("Back To Delta T = Tf - Ti Form"))
		{
			DeltaTTfTi deltaT2 = new DeltaTTfTi();
			deltaT2.setJMenuBar(deltaT2.createMenuBar());
			deltaT2.setContentPane(deltaT2.createContentPane());
			deltaT2.setSize(600,375);
			this.hide();
			deltaT2.show();
		}
		
		else if(args.equals("Back To Representing Motion Equations Form2"))
		{
			RepresentingMotionEquationsSelection motion = new RepresentingMotionEquationsSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		else if(args.equals("Back To Representing Motion Equations Form"))
		{
			RepresentingMotionEquationsSelection motion2 = new RepresentingMotionEquationsSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		else if(args.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(args.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(args.equals("Calculate2"))
		{
			String deltatstring;
			String tfstring;
			double tf = 0;
			double ti = 0;
			double deltat = 0;
			
			try
			{
				tfstring = Tffield.getText();
				deltatstring = DeltaTfield.getText();
				tf = Double.parseDouble(tfstring);
				deltat = Double.parseDouble(deltatstring);
				ti = -deltat + tf;
				JOptionPane.showMessageDialog(null,"Answer is " + ti);
				if(deltatstring == null || tfstring == null)throw new Exception();
			}
			catch(Exception s)
			{
				JOptionPane.showMessageDialog(null,"Integers and decimals only please","Error",JOptionPane.INFORMATION_MESSAGE);
				Tffield.setText("");
				DeltaTfield.setText("");
			}
		}
		
		else if(args.equals("Calculate"))
		{
			String deltatstring;
			String tfstring;
			double tf = 0;
			double ti = 0;
			double deltat = 0;
			
			try
			{
				tfstring = Tffield.getText();
				deltatstring = DeltaTfield.getText();
				tf = Double.parseDouble(tfstring);
				deltat = Double.parseDouble(deltatstring);
				ti = -deltat + tf;
				JOptionPane.showMessageDialog(null,"Answer is " + ti);
				if(deltatstring == null || tfstring == null)throw new Exception();
			}
			catch(Exception s)
			{
				JOptionPane.showMessageDialog(null,"Integers and decimals only please","Error",JOptionPane.INFORMATION_MESSAGE);
				Tffield.setText("");
				DeltaTfield.setText("");
			}
		}
		
		else if(args.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Enter in values into text fields below then hit calculate to get your answer. You can use button or menu item in File");
		}
	}
	
	public static void main(String[] args)
	{
		 try
		 {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		 }
		 catch(Exception c)
		 {
			 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
		 }
		 JFrame.setDefaultLookAndFeelDecorated(true);
		 TiforDeltaTTfTi f = new  TiforDeltaTTfTi();
		 f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 f.setJMenuBar(f.createMenuBar());
		 f.setContentPane(f.createContentPane());
		 f.setSize(900,149);
		 f.setVisible(true);
	}
}
