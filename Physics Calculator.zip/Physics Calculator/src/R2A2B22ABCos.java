/*
 * Program: R^2 = A^2 + B^2 - 2ABCos(Angle) Form
 * Programmer: Jay
 * Date: 4/29/010
 * Filename: R2A2B22AbCos.java
 * Purpose: To chose a variable to solve for in R^2 = A^2 + B^2-2ABCos(Angle)
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class R2A2B22ABCos extends JFrame implements ActionListener{

	//items used in frame
	public JLabel startuplabel;
	public JButton R2;
	public JButton backtoForcesInMultipleDimensionsEquations;
	public JButton backtoMainForm;
	
	//constructor method for calling class
	public R2A2B22ABCos()
	{
		super("R^2 = A^2 + B^2 - 2ABCos(Angle) Form");
	}
	
	//creates the menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToForcesInMultipleDimensionsEquations = new JMenuItem("Back To Forces In Multiple Dimensions");
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setMnemonic(KeyEvent.VK_T);
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setDisplayedMnemonicIndex(5);
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setActionCommand("Back To Forces In Multiple Dimensions2");
		mnuFileBackBackToForcesInMultipleDimensionsEquations.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToForcesInMultipleDimensionsEquations);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(8);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseR2 = new JMenuItem("R2");
		mnuChooseR2.setMnemonic(KeyEvent.VK_R);
		mnuChooseR2.setDisplayedMnemonicIndex(0);
		mnuChooseR2.setActionCommand("R22");
		mnuChooseR2.addActionListener(this);
		mnuChoose.add(mnuChooseR2);
		
		
		JMenu mnuAbout = new JMenu("About");
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//used to hold items in frame together.
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a variable below to solve for");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		R2 = new JButton("R2");
		R2.setActionCommand("R2");
		R2.addActionListener(this);
		backtoForcesInMultipleDimensionsEquations = new JButton("Back To Forces In Multiple Dimensions");
		backtoForcesInMultipleDimensionsEquations.setActionCommand("Back To Forces In Multiple Dimensions");
		backtoForcesInMultipleDimensionsEquations.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(R2);
		buttonpanel.add(backtoForcesInMultipleDimensionsEquations);
		buttonpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel,BorderLayout.NORTH);
		c.add(buttonpanel,BorderLayout.CENTER);
		
		return c;
	}
	
	//actions for button clicks and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Forces In Multiple Dimensions2"))
		{
			ForcesInMultipleDimensions force = new ForcesInMultipleDimensions();
			force.setJMenuBar(force.createMenuBar());
			force.setContentPane(force.createContentPane());
			force.setSize(600,375);
			this.hide();
			force.show();
		}
		
		else if(arg.equals("Back To Forces In Multiple Dimensions"))
		{
			ForcesInMultipleDimensions force2 = new ForcesInMultipleDimensions();
			force2.setJMenuBar(force2.createMenuBar());
			force2.setContentPane(force2.createContentPane());
			force2.setSize(600,375);
			this.hide();
			force2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("R22"))
		{
			RforR2A2B22ABCos r = new RforR2A2B22ABCos();
			r.setJMenuBar(r.createMenuBar());
			r.setContentPane(r.createContentPane());
			r.setSize(600,375);
			this.hide();
			r.show();
		}
		
		else if(arg.equals("R2"))
		{
			RforR2A2B22ABCos r2 = new RforR2A2B22ABCos();
			r2.setJMenuBar(r2.createMenuBar());
			r2.setContentPane(r2.createContentPane());
			r2.setSize(600,375);
			this.hide();
			r2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please a variable to be solved for","How To",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	//runs the frame
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		R2A2B22ABCos r2a2b22abcos = new R2A2B22ABCos();
		r2a2b22abcos.setJMenuBar(r2a2b22abcos.createMenuBar());
		r2a2b22abcos.setContentPane(r2a2b22abcos.createContentPane());
		r2a2b22abcos.setSize(600,375);
		r2a2b22abcos.setVisible(true);
	}
}