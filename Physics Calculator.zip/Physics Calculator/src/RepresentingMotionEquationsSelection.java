/*
 * Program: Physics Calculator class Representing Motion Equations Form
 * Programmer: Jay
 * Date: 4/19/010
 * Filename: RepresentingMotionEquationsSelection.java
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class RepresentingMotionEquationsSelection extends JFrame implements ActionListener{

	JLabel selectequation = new JLabel("Please select your equation below");
	JButton DeltaTTfTi = new JButton("Delta T = Tf - Ti");
	JButton DeltaDDfDi = new JButton("Delta D = Df - Di");
	JButton VDeltaDDeltaT = new JButton("V = Delta D / Delta T");
	JButton DVTDi = new JButton("D = VT  + Di");
	JButton BackToMainForm = new JButton("Back To Main Form");
	JPanel labelpanel = new JPanel();
	JPanel buttonpanel = new JPanel();
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileBack = new JMenuItem("Back To Main Form");
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(1);
		mnuFileBack.setActionCommand("Back To Main Form2");
		mnuFileBack.addActionListener(this);
		mnuFile.add(mnuFileBack);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseDeltaTTfTi = new JMenuItem("Delta T = Tf - Ti");
		mnuChooseDeltaTTfTi.setMnemonic(KeyEvent.VK_D);
		mnuChooseDeltaTTfTi.setDisplayedMnemonicIndex(1);
		mnuChooseDeltaTTfTi.setActionCommand("Delta T = Tf - Ti");
		mnuChooseDeltaTTfTi.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaTTfTi);
		
		JMenuItem mnuChooseDeltaDDfDi = new JMenuItem("Delta D = Df - Di");
		mnuChooseDeltaDDfDi.setMnemonic(KeyEvent.VK_I);
		mnuChooseDeltaDDfDi.setDisplayedMnemonicIndex(1);
		mnuChooseDeltaDDfDi.setActionCommand("Delta D = Df - Di");
		mnuChooseDeltaDDfDi.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaDDfDi);
		
		JMenuItem mnuChooseVDeltaDDeltaT = new JMenuItem("V = Delta D / Delta T");
		mnuChooseVDeltaDDeltaT.setMnemonic(KeyEvent.VK_V);
		mnuChooseVDeltaDDeltaT.setDisplayedMnemonicIndex(1);
		mnuChooseVDeltaDDeltaT.setActionCommand("V = Delta D / Delta T2");
		mnuChooseVDeltaDDeltaT.addActionListener(this);
		mnuChoose.add(mnuChooseVDeltaDDeltaT);
		
		JMenuItem mnuChooseDVfDi = new JMenuItem("D = VT + Di");
		mnuChooseDVfDi.setMnemonic(KeyEvent.VK_MINUS);
		mnuChooseDVfDi.setDisplayedMnemonicIndex(1);
		mnuChooseDVfDi.setActionCommand("D = VT + Di2");
		mnuChooseDVfDi.addActionListener(this);
		mnuChoose.add(mnuChooseDVfDi);
		
		JMenuItem mnuChooseBackToMainForm = new JMenuItem("Back To Main Form");
		mnuChooseBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuChooseBackToMainForm.setDisplayedMnemonicIndex(1);
		mnuChooseBackToMainForm.setActionCommand("Back To Main Form");
		mnuChooseBackToMainForm.addActionListener(this);
		mnuChoose.add(mnuChooseBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
		mnuAboutInstructions.setMnemonic(KeyEvent.VK_N);
		mnuAboutInstructions.setDisplayedMnemonicIndex(1);
		mnuAboutInstructions.setActionCommand("Instructions");
		mnuAboutInstructions.addActionListener(this);
		mnuAbout.add(mnuAboutInstructions);
		
		
		return mnuBar;
	}
	public RepresentingMotionEquationsSelection()
	{
		super("Representing Motion Equations Selection");
	}
	public Container createContentPane()
	{
		labelpanel.setLayout(new FlowLayout());
		labelpanel.add(selectequation);
		
		buttonpanel.setLayout(new GridLayout(0,1));
		buttonpanel.add(DeltaTTfTi);
		DeltaTTfTi.setActionCommand("Delta T");
		DeltaTTfTi.addActionListener(this);
		buttonpanel.add(DeltaDDfDi);
		DeltaDDfDi.addActionListener(this);
		DeltaDDfDi.setActionCommand("Delta D");
		buttonpanel.add(VDeltaDDeltaT);
		VDeltaDDeltaT.setActionCommand("V = Delta D / Delta T");
		VDeltaDDeltaT.addActionListener(this);
		buttonpanel.add(DVTDi);
		DVTDi.addActionListener(this);
		DVTDi.setActionCommand("D = VT + Di");
		buttonpanel.add(BackToMainForm);
		BackToMainForm.addActionListener(this);
		BackToMainForm.setActionCommand("Back To Main Form");
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel, BorderLayout.NORTH);
		c.add(buttonpanel,BorderLayout.CENTER);
		
		return c;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg == "Back To Main Form")
		{
			MainForm k = new MainForm();
			k.show();
			this.hide();
			k.setSize(600,375);
			k.setJMenuBar(k.createMenuBar());
			k.setContentPane(k.createContentPane());
			
		}
		
		else if(arg == "Back To Main Form2")
		{
			MainForm q = new MainForm();
			q.setSize(600,375);
			q.setJMenuBar(q.createMenuBar());
			q.setContentPane(q.createContentPane());
			this.hide();
			q.show();
		}
		
		else if(arg == "Delta D = Df - Di")
		{
			DeltaDDfDi j = new DeltaDDfDi();
			j.setJMenuBar(j.createMenuBar());
			j.setContentPane(j.createContentPane());
			j.setSize(600,375);
			this.hide();
			j.show();
		}
		
		else if(arg == "Delta D")
		{
			DeltaDDfDi j2 = new DeltaDDfDi();
			j2.setJMenuBar(j2.createMenuBar());
			j2.setContentPane(j2.createContentPane());
			j2.setSize(600,375);
			this.hide();
			j2.show();
		}
		
		else if(arg == "Delta T")
		{
			DeltaTTfTi deltaT = new DeltaTTfTi();
			deltaT.setJMenuBar(deltaT.createMenuBar());
			deltaT.setContentPane(deltaT.createContentPane());
			deltaT.setSize(600,375);
			this.hide();
			deltaT.show();
		}
		
		else if(arg == "Delta T = Tf - Ti")
		{
			DeltaTTfTi deltaT2 = new DeltaTTfTi();
			deltaT2.setJMenuBar(deltaT2.createMenuBar());
			deltaT2.setContentPane(deltaT2.createContentPane());
			deltaT2.setSize(600,375);
			this.hide();
			deltaT2.show();
		}
		
		else if(arg == "V = Delta D / Delta T2")
		{
			VDeltaDDeltaT v = new VDeltaDDeltaT();
			v.setJMenuBar(v.createMenuBar());
			v.setContentPane(v.createContentPane());
			v.setSize(600,375);
			this.hide();
			v.show();
		}
		
		else if(arg == "V = Delta D / Delta T")
		{
			VDeltaDDeltaT v2 = new VDeltaDDeltaT();
			v2.setJMenuBar(v2.createMenuBar());
			v2.setContentPane(v2.createContentPane());
			v2.setSize(600,375);
			this.hide();
			v2.show();
		}
		
		else if(arg == "D = VT + Di2")
		{
			DVTDi d = new DVTDi();
			d.setJMenuBar(d.createMenuBar());
			d.setContentPane(d.createContentPane());
			d.setSize(600,375);
			this.hide();
			d.show();
		}
		
		else if(arg == "D = VT + Di")
		{
			DVTDi d2 = new DVTDi();
			d2.setJMenuBar(d2.createMenuBar());
			d2.setContentPane(d2.createContentPane());
			d2.setSize(600,375);
			this.hide();
			d2.show();
		}
		
		else if(arg == "Instructions")
		{
			JOptionPane.showMessageDialog(null,"Select a equation to solve for","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
		
	}
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		JFrame.setDefaultLookAndFeelDecorated(true);
		RepresentingMotionEquationsSelection f = new RepresentingMotionEquationsSelection();
		f.setJMenuBar(f.createMenuBar());
		f.setContentPane(f.createContentPane());
		f.setSize(600,375);
		f.setResizable(false);
		f.setVisible(true);
		
	}
	
}