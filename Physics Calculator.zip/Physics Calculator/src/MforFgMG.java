/*
 * Program: M for Fg = MG Form
 * Programmer: Jay
 * Date: 4/29/010
 * Filename: MforFgMG.java
 * Purpose: To solve for M
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class MforFgMG extends JFrame implements ActionListener{

	//items used in frame
	public JLabel startupFglabel;
	public JTextField Fgfield;
	public JTextField Gfield;
	public JLabel Fglabel;
	public JLabel Glabel;
	public JButton calculate;
	public JButton backtoFgMG;
	public JButton backtoForcesInOneDimensionEquations;
	public JButton backtoMainForm;
	
	public MforFgMG()
	{
		super("M for Fg = MG Form");
	}
	
	//creates menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToFgMG = new JMenuItem("Back To Fg = MG");
		mnuFileBackBackToFgMG.setMnemonic(KeyEvent.VK_G);
		mnuFileBackBackToFgMG.setDisplayedMnemonicIndex(9);
		mnuFileBackBackToFgMG.setActionCommand("Back To Fg = MG2");
		mnuFileBackBackToFgMG.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToFgMG);
		
		JMenuItem mnuFileBackBackToForcesInOneDimension = new JMenuItem("Back To Forces In One Dimension");
		mnuFileBackBackToForcesInOneDimension.setMnemonic(KeyEvent.VK_O);
		mnuFileBackBackToForcesInOneDimension.setDisplayedMnemonicIndex(6);
		mnuFileBackBackToForcesInOneDimension.setActionCommand("Back To Forces In One Dimension2");
		mnuFileBackBackToForcesInOneDimension.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToForcesInOneDimension);
		
		JMenuItem mnuFileBackBacktoMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBacktoMainForm.setMnemonic(KeyEvent.VK_R);
		mnuFileBackBacktoMainForm.setDisplayedMnemonicIndex(15);
		mnuFileBackBacktoMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBacktoMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBacktoMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//item used to hold items in frames
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupFglabel = new JLabel("Please enter in information below to solve for Fg");
		northpanel.add(startupFglabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(2,2));
		Fgfield = new JTextField(10);
		Gfield = new JTextField(10);
		Fglabel = new JLabel("Fg");
		Glabel = new JLabel("G");
		centerpanel.add(Fgfield);
		centerpanel.add(Fglabel);
		centerpanel.add(Gfield);
		centerpanel.add(Glabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		backtoFgMG = new JButton("Back To Fg = MG");
		backtoFgMG.setActionCommand("Back To Fg = MG");
		backtoFgMG.addActionListener(this);
		backtoForcesInOneDimensionEquations = new JButton("Back To Forces In One Dimension");
		backtoForcesInOneDimensionEquations.setActionCommand("Back To Forces In One Dimension");
		backtoForcesInOneDimensionEquations.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(calculate);
		southpanel.add(backtoFgMG);
		southpanel.add(backtoForcesInOneDimensionEquations);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel, BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel,BorderLayout.SOUTH);
		
		return c;
	}
	
	//creates action commands
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Fg = MG2"))
		{
			FgMG fgmg = new FgMG();
			fgmg.setJMenuBar(fgmg.createMenuBar());
			fgmg.setContentPane(fgmg.createContentPane());
			fgmg.setSize(600,375);
			this.hide();
			fgmg.show();
		}
		
		else if(arg.equals("Back To Fg = MG"))
		{
			FgMG fgmg2 = new FgMG();
			fgmg2.setJMenuBar(fgmg2.createMenuBar());
			fgmg2.setContentPane(fgmg2.createContentPane());
			fgmg2.setSize(600,375);
			this.hide();
			fgmg2.show();
		}
		
		else if(arg.equals("Back To Forces In One Dimension2"))
		{
			ForcesInOneDimensionEquations force = new ForcesInOneDimensionEquations();
			force.setJMenuBar(force.createMenuBar());
			force.setContentPane(force.createContentPane());
			force.setSize(600,375);
			this.hide();
			force.show();
		}
		
		else if(arg.equals("Back To Forces In One Dimension"))
		{
			ForcesInOneDimensionEquations force2 = new ForcesInOneDimensionEquations();
			force2.setJMenuBar(force2.createMenuBar());
			force2.setContentPane(force2.createContentPane());
			force2.setSize(600,375);
			this.hide();
			force2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String fgstring;
			String gstring;
			double m = 0;
			double g = 0;
			double fg = 0;
			
			fgstring = Fgfield.getText();
			gstring = Gfield.getText();
			
			try
			{
				fg = Double.parseDouble(fgstring);
				g = Double.parseDouble(gstring);
				m = fg / g;
				JOptionPane.showMessageDialog(null,"The Answer is " + m,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Fgfield.setText("");
				Gfield.setText("");
				if(fgstring == null || gstring == null || g == 0)throw new Exception();
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals","Error",JOptionPane.INFORMATION_MESSAGE);
				Fgfield.setText("");
				Gfield.setText("");
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String fgstring;
			String gstring;
			double m = 0;
			double g = 0;
			double fg = 0;
			
			fgstring = Fgfield.getText();
			gstring = Gfield.getText();
			
			try
			{
				fg = Double.parseDouble(fgstring);
				g = Double.parseDouble(gstring);
				m = fg / g;
				JOptionPane.showMessageDialog(null,"The Answer is " + m,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Fgfield.setText("");
				Gfield.setText("");
				if(fgstring == null || gstring == null || g == 0)throw new Exception();
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals","Error",JOptionPane.INFORMATION_MESSAGE);
				Fgfield.setText("");
				Gfield.setText("");
			}
		}
		
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Enter in numbers into fields and then click calculate to getthe answer","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	//creates the frame and makes it run
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		MforFgMG m = new MforFgMG();
		m.setJMenuBar(m.createMenuBar());
		m.setContentPane(m.createContentPane());
		m.setSize(600,375);
		m.setVisible(true);
	}
}
