/*
 * Program: Vf^2 = Vi^2 + 2A(Df - Di) Form
 * Programmer: Jay
 * Date: 4/26/010
 * Filename: Vf2Vi22ADfDi.java
 * Purpose: To choose a variable to solve for in Vf^2 = Vi^2 + 2A(Df - Di).
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class Vf2Vi22ADfDi extends JFrame implements ActionListener{

	//items used in frame
	public JButton Vi;
	public JButton Vf;
	public JButton A;
	public JButton Df;
	public JButton Di;
	public JLabel startuplabel;
	public JButton backtoAcceleratingMotionForm;
	public JButton backtoMainForm;
	
	public Vf2Vi22ADfDi()
	{
		super("Vf^2 = Vi^2 + 2A(Df - Di) Form");
	}
	
	//used for menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToAcceleratingMotionForm = new JMenuItem("Back To Accelerating Motion Form");
		mnuFileBackBackToAcceleratingMotionForm.setMnemonic(KeyEvent.VK_A);
		mnuFileBackBackToAcceleratingMotionForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form2");
		mnuFileBackBackToAcceleratingMotionForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcceleratingMotionForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseDf = new JMenuItem("Df");
		mnuChooseDf.setMnemonic(KeyEvent.VK_D);
		mnuChooseDf.setDisplayedMnemonicIndex(0);
		mnuChooseDf.setActionCommand("Df2");
		mnuChooseDf.addActionListener(this);
		mnuChoose.add(mnuChooseDf);
		
		JMenuItem mnuChooseDi = new JMenuItem("Di");
		mnuChooseDi.setMnemonic(KeyEvent.VK_I);
		mnuChooseDi.setDisplayedMnemonicIndex(1);
		mnuChooseDi.setActionCommand("Di2");
		mnuChooseDi.addActionListener(this);
		mnuChoose.add(mnuChooseDi);
		
		JMenuItem mnuChooseVi = new JMenuItem("Vi");
		mnuChooseVi.setMnemonic(KeyEvent.VK_V);
		mnuChooseVi.setDisplayedMnemonicIndex(0);
		mnuChooseVi.setActionCommand("Vi2");
		mnuChooseVi.addActionListener(this);
		mnuChoose.add(mnuChooseVi);
		
		JMenuItem mnuChooseA = new JMenuItem("A");
		mnuChooseA.setMnemonic(KeyEvent.VK_A);
		mnuChooseA.setDisplayedMnemonicIndex(0);
		mnuChooseA.setActionCommand("A2");
		mnuChooseA.addActionListener(this);
		mnuChoose.add(mnuChooseA);
		
		JMenuItem mnuChooseVf = new JMenuItem("Vf");
		mnuChooseVf.setMnemonic(KeyEvent.VK_V);
		mnuChooseVf.setDisplayedMnemonicIndex(0);
		mnuChooseVf.setActionCommand("Vf2");
		mnuChooseVf.addActionListener(this);
		mnuChoose.add(mnuChooseVf);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_U);
		mnuAbout.setDisplayedMnemonicIndex(4);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_N);
		mnuInstructions.setDisplayedMnemonicIndex(1);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//container to hold the items
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a variable below to solve for in Vf^2 = Vi^2 + 2A(Df - Di)");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		Vi = new JButton("Vi");
		Vi.setActionCommand("Vi");
		Vi.addActionListener(this);
		buttonpanel.add(Vi);
		A = new JButton("A");
		A.setActionCommand("A");
		A.addActionListener(this);
		buttonpanel.add(A);
		Vf = new JButton("Vf");
		Vf.setActionCommand("Vf");
		Vf.addActionListener(this);
		buttonpanel.add(Vf);
		Df = new JButton("Df");
		Df.setActionCommand("Df");
		Df.addActionListener(this);
		buttonpanel.add(Df);
		Di = new JButton("Di");
		Di.setActionCommand("Di");
		Di.addActionListener(this);
		buttonpanel.add(Di);
		backtoAcceleratingMotionForm = new JButton("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.addActionListener(this);
		buttonpanel.add(backtoAcceleratingMotionForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel, BorderLayout.NORTH);
		c.add(buttonpanel,BorderLayout.CENTER);
		
		return c;
	}
	
	//action commands for button clicks and menu item clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Accelerating Motion Form2"))
		{
			AcceleratingMotionEquationSelection k = new AcceleratingMotionEquationSelection();
			k.setJMenuBar(k.createMenuBar());
			k.setContentPane(k.createContentPane());
			k.setSize(600,375);
			this.hide();
			k.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form"))
		{
			AcceleratingMotionEquationSelection k2 = new AcceleratingMotionEquationSelection();
			k2.setJMenuBar(k2.createMenuBar());
			k2.setContentPane(k2.createContentPane());
			k2.setSize(600,375);
			this.hide();
			k2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Vi2"))
		{
			ViforVf2Vi22ADfDi vi = new ViforVf2Vi22ADfDi();
			vi.setJMenuBar(vi.createMenuBar());
			vi.setContentPane(vi.createContentPane());
			vi.setSize(600,375);
			this.hide();
			vi.show();
		}
		
		else if(arg.equals("Vi"))
		{
			ViforVf2Vi22ADfDi vi2 = new ViforVf2Vi22ADfDi();
			vi2.setJMenuBar(vi2.createMenuBar());
			vi2.setContentPane(vi2.createContentPane());
			vi2.setSize(600,375);
			this.hide();
			vi2.show();
		}
		
		else if(arg.equals("A2"))
		{
			AforVf2Vi22ADfDi a = new AforVf2Vi22ADfDi();
			a.setJMenuBar(a.createMenuBar());
			a.setContentPane(a.createContentPane());
			a.setSize(600,375);
			this.hide();
			a.show();
		}
		
		else if(arg.equals("A"))
		{
			AforVf2Vi22ADfDi a2 = new AforVf2Vi22ADfDi();
			a2.setJMenuBar(a2.createMenuBar());
			a2.setContentPane(a2.createContentPane());
			a2.setSize(600,375);
			this.hide();
			a2.show();
		}
		
		else if(arg.equals("Vf2"))
		{
			VfforVf2Vi22ADfDi vf = new VfforVf2Vi22ADfDi();
			vf.setJMenuBar(vf.createMenuBar());
			vf.setContentPane(vf.createContentPane());
			vf.setSize(600,375);
			this.hide();
			vf.show();
		}
		
		else if(arg.equals("Vf"))
		{
			VfforVf2Vi22ADfDi vf2 = new VfforVf2Vi22ADfDi();
			vf2.setJMenuBar(vf2.createMenuBar());
			vf2.setContentPane(vf2.createContentPane());
			vf2.setSize(600,375);
			this.hide();
			vf2.show();
		}
		
		else if(arg.equals("Df2"))
		{
			DfforVf2Vi22ADfDi df = new DfforVf2Vi22ADfDi();
			df.setJMenuBar(df.createMenuBar());
			df.setContentPane(df.createContentPane());
			df.setSize(600,375);
			this.hide();
			df.show();
		}
		
		else if(arg.equals("Df"))
		{
			DfforVf2Vi22ADfDi df2 = new DfforVf2Vi22ADfDi();
			df2.setJMenuBar(df2.createMenuBar());
			df2.setContentPane(df2.createContentPane());
			df2.setSize(600,375);
			this.hide();
			df2.show();
		}
		
		else if(arg.equals("Di2"))
		{
			DiforVf2Vi22ADfDi di = new DiforVf2Vi22ADfDi();
			di.setJMenuBar(di.createMenuBar());
			di.setContentPane(di.createContentPane());
			di.setSize(600,375);
			this.hide();
			di.show();
		}
		
		else if(arg.equals("Di"))
		{
			DiforVf2Vi22ADfDi di2 = new DiforVf2Vi22ADfDi();
			di2.setJMenuBar(di2.createMenuBar());
			di2.setContentPane(di2.createContentPane());
			di2.setSize(600,375);
			this.hide();
			di2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please select and variable and you will then be taken to a form to solve for chosen variable","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		Vf2Vi22ADfDi vf2vi22adfdi = new Vf2Vi22ADfDi();
		vf2vi22adfdi.setJMenuBar(vf2vi22adfdi.createMenuBar());
		vf2vi22adfdi.setContentPane(vf2vi22adfdi.createContentPane());
		vf2vi22adfdi.setSize(600,375);
		vf2vi22adfdi.setVisible(true);
	}
}
