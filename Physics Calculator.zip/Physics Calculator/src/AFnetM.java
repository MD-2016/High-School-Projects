/*
 * Program: A = Fnet / M Form
 * Programmer: Jay
 * Date: 4/28/010
 * Filename. AFnetM.java
 * Purpose: to select a variable to be taken to solve for in A = Fnet / M
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AFnetM  extends JFrame implements ActionListener{

	//items used in frame
	public JLabel startuplabel;
	public JButton A;
	public JButton Fnet;
	public JButton M;
	public JButton backtoForcesInOneDimensionEquations;
	public JButton backtoMainForm;
	
	//constructor method
	public AFnetM()
	{
		super("A = Fnet / M Form");
	}
	
	//creates the menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToForcesInOneDimension = new JMenuItem("Back To Forces In One Dimension Equations");
		mnuFileBackBackToForcesInOneDimension.setMnemonic(KeyEvent.VK_O);
		mnuFileBackBackToForcesInOneDimension.setActionCommand("Back To Forces In One Dimension Equations2");
		mnuFileBackBackToForcesInOneDimension.addActionListener(this);
		mnuFileBackBackToForcesInOneDimension.setDisplayedMnemonicIndex(18);
		mnuFileBack.add(mnuFileBackBackToForcesInOneDimension);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_R);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(16);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseA = new JMenuItem("A");
		mnuChooseA.setMnemonic(KeyEvent.VK_A);
		mnuChooseA.setDisplayedMnemonicIndex(0);
		mnuChooseA.addActionListener(this);
		mnuChooseA.setActionCommand("A2");
		mnuChoose.add(mnuChooseA);
		
		JMenuItem mnuChooseFnet = new JMenuItem("Fnet");
		mnuChooseFnet.setMnemonic(KeyEvent.VK_N);
		mnuChooseFnet.setDisplayedMnemonicIndex(1);
		mnuChooseFnet.setActionCommand("Fnet2");
		mnuChooseFnet.addActionListener(this);
		mnuChoose.add(mnuChooseFnet);
		
		JMenuItem mnuChooseM = new JMenuItem("M");
		mnuChooseM.setMnemonic(KeyEvent.VK_M);
		mnuChooseM.setDisplayedMnemonicIndex(0);
		mnuChooseM.setActionCommand("M2");
		mnuChooseM.addActionListener(this);
		mnuChoose.add(mnuChooseM);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A); 
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//used to hold frame items
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		startuplabel = new JLabel("Please select a letter below to solve for");
		labelpanel.setLayout(new FlowLayout());
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		A = new JButton("A");
		A.setActionCommand("A");
		A.addActionListener(this);
		Fnet = new JButton("Fnet");
		Fnet.setActionCommand("Fnet");
		Fnet.addActionListener(this);
		M = new JButton("M");
		M.setActionCommand("M");
		M.addActionListener(this);
		backtoForcesInOneDimensionEquations = new JButton("Back To Forces In One Dimension Equations");
		backtoForcesInOneDimensionEquations.setActionCommand("Back To Forces In One Dimension Equations");
		backtoForcesInOneDimensionEquations.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(A);
		buttonpanel.add(Fnet);
		buttonpanel.add(M);
		buttonpanel.add(backtoForcesInOneDimensionEquations);
		buttonpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel,BorderLayout.NORTH);
		c.add(buttonpanel,BorderLayout.CENTER);
		
		return c;
	}
	
	//makes actions of button and menu clicks happen
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Forces In One Dimension Equations2"))
		{
			ForcesInOneDimensionEquations force = new ForcesInOneDimensionEquations();
			force.setJMenuBar(force.createMenuBar());
			force.setContentPane(force.createContentPane());
			force.setSize(600,375);
			this.hide();
			force.show();
		}
		
		else if(arg.equals("Back To Forces In One Dimension Equations"))
		{
			ForcesInOneDimensionEquations force2 = new ForcesInOneDimensionEquations();
			force2.setJMenuBar(force2.createMenuBar());
			force2.setContentPane(force2.createContentPane());
			force2.setSize(600,375);
			this.hide();
			force2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("A2"))
		{
			AforAFnetM a = new AforAFnetM();
			a.setJMenuBar(a.createMenuBar());
			a.setContentPane(a.createContentPane());
			a.setSize(600,375);
			this.hide();
			a.show();
		}
		
		else if(arg.equals("A"))
		{
			AforAFnetM a2 = new AforAFnetM();
			a2.setJMenuBar(a2.createMenuBar());
			a2.setContentPane(a2.createContentPane());
			a2.setSize(600,375);
			this.hide();
			a2.show();
		}
		
		else if(arg.equals("Fnet2"))
		{
			FnetforAFnetM fnet = new FnetforAFnetM();
			fnet.setJMenuBar(fnet.createMenuBar());
			fnet.setContentPane(fnet.createContentPane());
			fnet.setSize(600,375);
			this.hide();
			fnet.show();
		}
		
		else if(arg.equals("Fnet"))
		{
			FnetforAFnetM fnet2 = new FnetforAFnetM();
			fnet2.setJMenuBar(fnet2.createMenuBar());
			fnet2.setContentPane(fnet2.createContentPane());
			fnet2.setSize(600,375);
			this.hide();
			fnet2.show();
		}
		
		else if(arg.equals("M2"))
		{
			MforAFnetM m = new MforAFnetM();
			m.setJMenuBar(m.createMenuBar());
			m.setContentPane(m.createContentPane());
			m.setSize(600,375);
			this.hide();
			m.show();
		}
		
		else if(arg.equals("M"))
		{
			MforAFnetM m2 = new MforAFnetM();
			m2.setJMenuBar(m2.createMenuBar());
			m2.setContentPane(m2.createContentPane());
			m2.setSize(600,375);
			this.hide();
			m2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please select a variable below to be taken to solve for it.","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		AFnetM a = new AFnetM();
		a.setJMenuBar(a.createMenuBar());
		a.setContentPane(a.createContentPane());
		a.setSize(600,375);
		a.setVisible(true);
	}
}
