/*
 * Program: Physics Calculator Program
 * Programmer: Jay
 * Date: 4/22/2010
 * Filename: AcV2R.java
 * Purpose: choose a variable to solve for in Ac = V^2 / R.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AcV2R extends JFrame implements ActionListener{

	//JPanels used to hold items
	JPanel labelpanel = new JPanel();
	JPanel buttonpanel = new JPanel();
	
	//Buttons and Labels used for Ac = V^2 / R Frame
	JLabel selectvariableAcV2R = new JLabel("Please select a variable below to solve for Ac = V^2 / R. Then you will be taken to a form for variable chosen");
	JButton Ac = new JButton("Ac");
	JButton V = new JButton("V");
	JButton R = new JButton("R");
	JButton BackToForcesInMultipleDimensions = new JButton("Back To Forces In Multiple Dimensions");
	JButton BackToMainForm = new JButton("Back To Main Form");
	
	//Constructor method is called
	public AcV2R()
	{
		super("Ac = V^2 / R Form");
	}
	
	//method for making Menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuBack = new JMenu("Back",true);
		mnuBack.setMnemonic(KeyEvent.VK_B);
		mnuBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuBack);
		
		JMenuItem mnuFileBackToForcesInMultipleDimensions = new JMenuItem("Back To Forces In Multiple Dimensions");
		mnuFileBackToForcesInMultipleDimensions.setMnemonic(KeyEvent.VK_C);
		mnuFileBackToForcesInMultipleDimensions.setDisplayedMnemonicIndex(3);
		mnuFileBackToForcesInMultipleDimensions.setActionCommand("Back To Forces In Multiple Dimensions2");
		mnuFileBackToForcesInMultipleDimensions.addActionListener(this);
		mnuBack.add(mnuFileBackToForcesInMultipleDimensions);
		
		JMenuItem mnuFileBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackToMainForm.addActionListener(this);
		mnuFileBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackToMainForm.setDisplayedMnemonicIndex(1);
		mnuBack.add(mnuFileBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseAc = new JMenuItem("Ac");
		mnuChooseAc.setMnemonic(KeyEvent.VK_A);
		mnuChooseAc.setDisplayedMnemonicIndex(0);
		mnuChooseAc.setActionCommand("Ac2");
		mnuChooseAc.addActionListener(this);
		mnuChoose.add(mnuChooseAc);
		
		JMenuItem mnuChooseV = new JMenuItem("V");
		mnuChooseV.setMnemonic(KeyEvent.VK_V);
		mnuChooseV.setDisplayedMnemonicIndex(0);
		mnuChooseV.setActionCommand("V2");
		mnuChooseV.addActionListener(this);
		mnuChoose.add(mnuChooseV);
		
		JMenuItem mnuChooseR = new JMenuItem("R");
		mnuChooseR.setMnemonic(KeyEvent.VK_R);
		mnuChooseR.setDisplayedMnemonicIndex(0);
		mnuChooseR.setActionCommand("R2");
		mnuChooseR.addActionListener(this);
		mnuChoose.add(mnuChooseR);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
		mnuAboutInstructions.setMnemonic(KeyEvent.VK_R);
		mnuAboutInstructions.setDisplayedMnemonicIndex(1);
		mnuAboutInstructions.setActionCommand("Instructions");
		mnuAboutInstructions.addActionListener(this);
		mnuAbout.add(mnuAboutInstructions);
		
		return mnuBar;
	}
	
	//used for creating the Container
	public Container createContentPane()
	{
		labelpanel.setLayout(new FlowLayout());
		labelpanel.add(selectvariableAcV2R);
		
		buttonpanel.setLayout(new GridLayout(0,1));
		buttonpanel.add(Ac);
		Ac.addActionListener(this);
		Ac.setActionCommand("Ac");
		buttonpanel.add(V);
		V.addActionListener(this);
		V.setActionCommand("V");
		buttonpanel.add(R);
		R.addActionListener(this);
		R.setActionCommand("R");
		buttonpanel.add(BackToForcesInMultipleDimensions);
		BackToForcesInMultipleDimensions.setActionCommand("Back To Forces In Multiple Dimensions");
		BackToForcesInMultipleDimensions.addActionListener(this);
		buttonpanel.add(BackToMainForm);
		BackToMainForm.setActionCommand("Back To Main Form");
		BackToMainForm.addActionListener(this);
		Container g = getContentPane();
		g.setLayout(new BorderLayout());
		g.add(labelpanel, BorderLayout.NORTH);
		g.add(buttonpanel, BorderLayout.CENTER);
		
		return g;
	}
	
	//used to implement button and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		//go to main form
		if(arg == "Back To Main Form")
		{
			MainForm s = new MainForm();
			this.hide();
			s.show();
			s.setSize(600,375);
			s.setJMenuBar(s.createMenuBar());
			s.setContentPane(s.createContentPane());
		}
		
		//go to main form
		else if(arg == "Back To Main Form2")
		{
			MainForm s2 = new MainForm();
			this.hide();
			s2.show();
			s2.setSize(600,375);
			s2.setJMenuBar(s2.createMenuBar());
			s2.setContentPane(s2.createContentPane());
		}
		
		//go to solve for ac
		else if(arg == "Ac2")
		{
			AcforAcV2R ac = new AcforAcV2R();
			ac.setJMenuBar(ac.createMenuBar());
			ac.setContentPane(ac.createContentPane());
			ac.setSize(600,200);
			this.hide();
			ac.show();
		}
		
		//go to solve for ac
		else if(arg == "Ac")
		{
			AcforAcV2R ac2 = new AcforAcV2R();
			ac2.setJMenuBar(ac2.createMenuBar());
			ac2.setContentPane(ac2.createContentPane());
			ac2.setSize(600,200);
			this.hide();
			ac2.show();
		}
		
		//go to solve for v
		else if(arg == "V2")
		{
			VforAcV2R v = new VforAcV2R();
			v.setJMenuBar(v.createMenuBar());
			v.setContentPane(v.createContentPane());
			v.setSize(600,375);
			this.hide();
			v.show();
		}
		
		//go to solve for v
		else if(arg == "V")
		{
			VforAcV2R v2 = new VforAcV2R();
			v2.setJMenuBar(v2.createMenuBar());
			v2.setContentPane(v2.createContentPane());
			v2.setSize(600,375);
			this.hide();
			v2.show();
		}
		
		//go to solve for r
		else if(arg == "R2")
		{
			RforAcV2R r = new RforAcV2R();
			r.setJMenuBar(r.createMenuBar());
			r.setContentPane(r.createContentPane());
			r.setSize(600,375);
			this.hide();
			r.show();
		}
		
		//go to solve for delta t
		else if(arg == "R")
		{
			RforAcV2R r2 = new RforAcV2R();
			r2.setJMenuBar(r2.createMenuBar());
			r2.setContentPane(r2.createContentPane());
			r2.setSize(600,375);
			this.hide();
			r2.show();
		}
		
		//go to forces in multiple dimensions
		else if(arg == "Back To Forces In Multiple Dimensions2")
		{
			ForcesInMultipleDimensions forces = new ForcesInMultipleDimensions();
			forces.setJMenuBar(forces.createMenuBar());
			forces.setContentPane(forces.createContentPane());
			forces.setSize(600,375);
			this.hide();
			forces.show();
		}
		
		//go to forces in multiple dimensions
		else if(arg == "Back To Forces In Multiple Dimensions")
		{
			ForcesInMultipleDimensions forces2 = new ForcesInMultipleDimensions();
			forces2.setJMenuBar(forces2.createMenuBar());
			forces2.setContentPane(forces2.createContentPane());
			forces2.setSize(600,375);
			this.hide();
			forces2.show();
		}
		
		//how to use the form
		else if(arg == "Instructions")
		{
			JOptionPane.showMessageDialog(null,"Please select a variable below to be taken to solve for that variable for Ac = V^2 / R","Help",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	//creates and makes the jframe come alive
	public static void main(String[] args)
	{
		 try
		 {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		 }
		 catch(Exception c)
		 {
			 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
		 }
		AcV2R acv2r = new AcV2R();
		acv2r.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		acv2r.setJMenuBar(acv2r.createMenuBar());
		acv2r.setContentPane(acv2r.createContentPane());
		acv2r.setSize(600,375);
		acv2r.setVisible(true);
	}
	
}
