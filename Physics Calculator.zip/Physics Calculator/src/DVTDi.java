import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DVTDi extends JFrame implements ActionListener {

	public JLabel DVTDilabel;
	public JButton V;
	public JButton T;
	public JButton D;
	public JButton Di;
	public JButton backtoRepresentingMotionEquationsForm;
	public JButton backtoMainForm;
	
	public DVTDi()
	{
		super("D = VT + Di Form");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuBack = new JMenu("Back",true);
		mnuBack.setMnemonic(KeyEvent.VK_B);
		mnuBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuBack);
		
		JMenuItem mnuFileBackToRepresentingMotionEquationsForm = new JMenuItem("Back To Representing Motion Equations Form");
		mnuFileBackToRepresentingMotionEquationsForm.setMnemonic(KeyEvent.VK_R);
		mnuFileBackToRepresentingMotionEquationsForm.setDisplayedMnemonicIndex(1);
		mnuFileBackToRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form2");
		mnuFileBackToRepresentingMotionEquationsForm.addActionListener(this);
		mnuBack.add(mnuFileBackToRepresentingMotionEquationsForm);
		
		JMenuItem mnuFileBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackToMainForm.addActionListener(this);
		mnuFileBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackToMainForm.setDisplayedMnemonicIndex(1);
		mnuBack.add(mnuFileBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseD = new JMenuItem("D");
		mnuChooseD.setMnemonic(KeyEvent.VK_D);
		mnuChooseD.setDisplayedMnemonicIndex(0);
		mnuChooseD.setActionCommand("D2");
		mnuChooseD.addActionListener(this);
		mnuChoose.add(mnuChooseD);
		
		JMenuItem mnuChooseV = new JMenuItem("V");
		mnuChooseV.setMnemonic(KeyEvent.VK_V);
		mnuChooseV.setDisplayedMnemonicIndex(0);
		mnuChooseV.setActionCommand("V2");
		mnuChooseV.addActionListener(this);
		mnuChoose.add(mnuChooseV);
		
		JMenuItem mnuChooseT = new JMenuItem("T");
		mnuChooseT.setMnemonic(KeyEvent.VK_T);
		mnuChooseT.setDisplayedMnemonicIndex(0);
		mnuChooseT.setActionCommand("T2");
		mnuChooseT.addActionListener(this);
		mnuChoose.add(mnuChooseT);
		
		JMenuItem mnuChooseDi = new JMenuItem("Di");
		mnuChooseDi.setMnemonic(KeyEvent.VK_D + KeyEvent.VK_I);
		mnuChooseDi.setDisplayedMnemonicIndex(0);
		mnuChooseDi.setActionCommand("Di2");
		mnuChooseDi.addActionListener(this);
		mnuChoose.add(mnuChooseDi);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
		mnuAboutInstructions.setMnemonic(KeyEvent.VK_R);
		mnuAboutInstructions.setDisplayedMnemonicIndex(1);
		mnuAboutInstructions.setActionCommand("Instructions");
		mnuAboutInstructions.addActionListener(this);
		mnuAbout.add(mnuAboutInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		DVTDilabel = new JLabel("Please choose a variable below to solve for D = VT + Di");
		labelpanel.add(DVTDilabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		V = new JButton("V");
		V.setActionCommand("V");
		V.addActionListener(this);
		buttonpanel.add(V);
		D = new JButton("D");
		D.setActionCommand("D");
		D.addActionListener(this);
		buttonpanel.add(D);
		T = new JButton("T");
		T.setActionCommand("T");
		T.addActionListener(this);
		buttonpanel.add(T);
		Di = new JButton("Di");
		Di.setActionCommand("Di");
		Di.addActionListener(this);
		buttonpanel.add(Di);
		backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoRepresentingMotionEquationsForm);
		buttonpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel, BorderLayout.NORTH);
		c.add(buttonpanel, BorderLayout.CENTER);
		
		return c;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Main Form"))
		{
			MainForm s = new MainForm();
			this.hide();
			s.show();
			s.setSize(600,375);
			s.setJMenuBar(s.createMenuBar());
			s.setContentPane(s.createContentPane());
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm w = new MainForm();
			this.hide();
			w.show();
			w.setSize(600,375);
			w.setJMenuBar(w.createMenuBar());
			w.setContentPane(w.createContentPane());
		}
		
		else if(arg.equals("D2"))
		{
			DforDVTDi D = new DforDVTDi();
			D.setJMenuBar(D.createMenuBar());
			D.setContentPane(D.createContentPane());
			D.setSize(600,375);
			this.hide();
			D.show();
		}
		
		else if(arg.equals("D"))
		{
			DforDVTDi D2 = new DforDVTDi();
			D2.setJMenuBar(D2.createMenuBar());
			D2.setContentPane(D2.createContentPane());
			D2.setSize(600,375);
			this.hide();
			D2.show();
		}
		
		else if(arg.equals("V2"))
		{
			VforDVTDi v = new VforDVTDi();
			v.setJMenuBar(v.createMenuBar());
			v.setContentPane(v.createContentPane());
			v.setSize(600,375);
			this.hide();
			v.show();
		}
		
		else if(arg.equals("V"))
		{
			VforDVTDi v2 = new VforDVTDi();
			v2.setJMenuBar(v2.createMenuBar());
			v2.setContentPane(v2.createContentPane());
			v2.setSize(600,375);
			this.hide();
			v2.show();
		}
		
		else if(arg.equals("Di2"))
		{
			DiforDVTDi di = new DiforDVTDi();
			di.setJMenuBar(di.createMenuBar());
			di.setContentPane(di.createContentPane());
			di.setSize(600,375);
			this.hide();
			di.show();
		}
		
		else if(arg.equals("Di"))
		{
			DiforDVTDi di2 = new DiforDVTDi();
			di2.setJMenuBar(di2.createMenuBar());
			di2.setContentPane(di2.createContentPane());
			di2.setSize(600,375);
			this.hide();
			di2.show();
		}
		
		else if(arg.equals("T2"))
		{
			TforDVTDi t = new TforDVTDi();
			t.setJMenuBar(t.createMenuBar());
			t.setContentPane(t.createContentPane());
			t.setSize(600,375);
			this.hide();
			t.show();
		}
		

		else if(arg.equals("T"))
		{
			TforDVTDi t2 = new TforDVTDi();
			t2.setJMenuBar(t2.createMenuBar());
			t2.setContentPane(t2.createContentPane());
			t2.setSize(600,375);
			this.hide();
			t2.show();
		}
		
		else if(arg == "Back To Representing Motion Equations Form2")
		{
			RepresentingMotionEquationsSelection motion = new RepresentingMotionEquationsSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		else if(arg == "Back To Representing Motion Equations Form")
		{
			RepresentingMotionEquationsSelection motion2 = new RepresentingMotionEquationsSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		else if(arg == "Instructions")
		{
			JOptionPane.showMessageDialog(null,"Please select a variable below to be taken to solve for that variable for V = Delta D / Delta T","Help",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	public static void main(String[] args)
	{
		 try
		 {
			 UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		 }
		 catch(Exception c)
		 {
			 JOptionPane.showMessageDialog(null,"The UI could not be set","Error",JOptionPane.INFORMATION_MESSAGE);
		 }
		 DVTDi d = new DVTDi ();
		 d.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 d.setJMenuBar(d.createMenuBar());
		 d.setContentPane(d.createContentPane());
		 d.setSize(600,375);
		 d.setVisible(true);
	}
}

