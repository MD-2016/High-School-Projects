/*
 * Program: Fg = MG Form
 * Programmer: Jay
 * Date: 4/29/010
 * Filename: FgMG.java
 * Purpose: To chose a variable to slve for in Fg = MG
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class FgMG extends JFrame implements ActionListener{

	//items used in frame
	public JLabel startuplabel;
	public JButton Fg;
	public JButton M;
	public JButton G;
	public JButton backtoForcesInOneDimensionEquations;
	public JButton backtoMainForm;
	
	//constructor mehtod for calling class
	public FgMG()
	{
		super("Fg = MG Form");
	}
	
	//creates the menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToForcesInOneDimensionEquations = new JMenuItem("Back To Forces In One Dimension");
		mnuFileBackBackToForcesInOneDimensionEquations.setMnemonic(KeyEvent.VK_T);
		mnuFileBackBackToForcesInOneDimensionEquations.setDisplayedMnemonicIndex(5);
		mnuFileBackBackToForcesInOneDimensionEquations.setActionCommand("Back To Forces In One Dimension2");
		mnuFileBackBackToForcesInOneDimensionEquations.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToForcesInOneDimensionEquations);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_O);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(6);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseFg = new JMenuItem("Fg");
		mnuChooseFg.setMnemonic(KeyEvent.VK_F);
		mnuChooseFg.setDisplayedMnemonicIndex(0);
		mnuChooseFg.setActionCommand("Fg2");
		mnuChooseFg.addActionListener(this);
		mnuChoose.add(mnuChooseFg);
		
		JMenuItem mnuChooseG = new JMenuItem("G");
		mnuChooseG.setMnemonic(KeyEvent.VK_G);
		mnuChooseG.setDisplayedMnemonicIndex(0);
		mnuChooseG.setActionCommand("G2");
		mnuChooseG.addActionListener(this);
		mnuChoose.add(mnuChooseG);
		
		JMenuItem mnuChooseM = new JMenuItem("M");
		mnuChooseM.setMnemonic(KeyEvent.VK_G);
		mnuChooseM.setDisplayedMnemonicIndex(0);
		mnuChooseM.setActionCommand("M2");
		mnuChooseM.addActionListener(this);
		mnuChoose.add(mnuChooseM);
		
		JMenu mnuAbout = new JMenu("About");
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//used to hold items in frame together.
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a variable below to solve for");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		Fg = new JButton("Fg");
		Fg.setActionCommand("Fg");
		Fg.addActionListener(this);
		G = new JButton("G");
		G.setActionCommand("G");
		G.addActionListener(this);
		M = new JButton("M");
		M.setActionCommand("M");
		M.addActionListener(this);
		backtoForcesInOneDimensionEquations = new JButton("Back To Forces In One Dimension");
		backtoForcesInOneDimensionEquations.setActionCommand("Back To Forces In One Dimension");
		backtoForcesInOneDimensionEquations.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(Fg);
		buttonpanel.add(M);
		buttonpanel.add(G);
		buttonpanel.add(backtoForcesInOneDimensionEquations);
		buttonpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(labelpanel,BorderLayout.NORTH);
		c.add(buttonpanel,BorderLayout.CENTER);
		
		return c;
	}
	
	//actions for button clicks and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Forces In One Dimension2"))
		{
			ForcesInOneDimensionEquations force = new ForcesInOneDimensionEquations();
			force.setJMenuBar(force.createMenuBar());
			force.setContentPane(force.createContentPane());
			force.setSize(600,375);
			this.hide();
			force.show();
		}
		
		else if(arg.equals("Back To Forces In One Dimension"))
		{
			ForcesInOneDimensionEquations force2 = new ForcesInOneDimensionEquations();
			force2.setJMenuBar(force2.createMenuBar());
			force2.setContentPane(force2.createContentPane());
			force2.setSize(600,375);
			this.hide();
			force2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Fg2"))
		{
			FgforFgMG fg = new FgforFgMG();
			fg.setJMenuBar(fg.createMenuBar());
			fg.setContentPane(fg.createContentPane());
			fg.setSize(600,375);
			this.hide();
			fg.show();
		}
		
		else if(arg.equals("Fg"))
		{
			FgforFgMG fg2 = new FgforFgMG();
			fg2.setJMenuBar(fg2.createMenuBar());
			fg2.setContentPane(fg2.createContentPane());
			fg2.setSize(600,375);
			this.hide();
			fg2.show();
		}
		
		else if(arg.equals("M2"))
		{
			MforFgMG m = new MforFgMG();
			m.setJMenuBar(m.createMenuBar());
			m.setContentPane(m.createContentPane());
			m.setSize(600,375);
			this.hide();
			m.show();
		}
		
		else if(arg.equals("M"))
		{
			MforFgMG m2 = new MforFgMG();
			m2.setJMenuBar(m2.createMenuBar());
			m2.setContentPane(m2.createContentPane());
			m2.setSize(600,375);
			this.hide();
			m2.show();
		}
		
		else if(arg.equals("G2"))
		{
			GforFgMG g = new GforFgMG();
			g.setJMenuBar(g.createMenuBar());
			g.setContentPane(g.createContentPane());
			g.setSize(600,375);
			this.hide();
			g.show();
		}
		
		else if(arg.equals("G"))
		{
			GforFgMG g2 = new GforFgMG();
			g2.setJMenuBar(g2.createMenuBar());
			g2.setContentPane(g2.createContentPane());
			g2.setSize(600,375);
			this.hide();
			g2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please a variable to be solved for","How To",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	//runs the frame
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		FgMG fgmg = new FgMG();
		fgmg.setJMenuBar(fgmg.createMenuBar());
		fgmg.setContentPane(fgmg.createContentPane());
		fgmg.setSize(600,375);
		fgmg.setVisible(true);
	}
}
