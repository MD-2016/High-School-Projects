/*
 * Program: A^2 for R^2 = A^2 + B^2
 * Programmer: Jay
 * Date: 4/29/010
 * Filename: AforR2A2B2.java
 * Purpose: To solve for R2
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AforR2A2B2 extends JFrame implements ActionListener {

	//items used in frame
	public JLabel startupA2label;
	public JTextField Rfield;
	public JLabel Rlabel;
	public JLabel Blabel;
	public JTextField Bfield;
	public JButton calculate;
	public JButton backtoR2A2B2;
	public JButton backtoForcesInMultipleDimensionsEquations;
	public JButton backtoMainForm;
	
	public AforR2A2B2()
	{
		super("A for R^2 = A^2 + B^2");
	}
	
	//used to create menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToR2A2B2 = new JMenuItem("Back To R^2 = A^2 + B^2");
		mnuFileBackBackToR2A2B2.setMnemonic(KeyEvent.VK_R);
		mnuFileBackBackToR2A2B2.setDisplayedMnemonicIndex(8);
		mnuFileBackBackToR2A2B2.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToR2A2B2);
		
		JMenuItem mnuFileBackBackToForcesInMultipleDimensionsEquations = new JMenuItem("Back To Forces In Multiple Dimensions Equations");
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setDisplayedMnemonicIndex(18);
		mnuFileBackBackToForcesInMultipleDimensionsEquations.setActionCommand("Back To Forces In Multiple Dimensions2");
		mnuFileBackBackToForcesInMultipleDimensionsEquations.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToForcesInMultipleDimensionsEquations);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(8);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//used to hold items in frame
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupA2label = new JLabel("Please enter in information below to solve for A.");
		northpanel.add(startupA2label);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(2,2));
		Rfield = new JTextField(10);
		Rlabel = new JLabel("R");
		Bfield = new JTextField(10);
		Blabel = new JLabel("B");
		centerpanel.add(Rfield);
		centerpanel.add(Rlabel);
		centerpanel.add(Bfield);
		centerpanel.add(Blabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		backtoR2A2B2 = new JButton("Back To R^2 = A^2 + B^2");
		backtoR2A2B2.setActionCommand("Back To R^2 = A^2 + B^2");
		backtoR2A2B2.addActionListener(this);
		backtoForcesInMultipleDimensionsEquations = new JButton("Back To Forces In Multiple Dimensions");
		backtoForcesInMultipleDimensionsEquations.setActionCommand("Back To Forces In Multiple Dimensions2");
		backtoForcesInMultipleDimensionsEquations.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(calculate);
		southpanel.add(backtoR2A2B2);
		southpanel.add(backtoForcesInMultipleDimensionsEquations);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel,BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel,BorderLayout.SOUTH);
		
		return c;
	}
	
	//used to implement actions of button clicks and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To R^2 = A^2 + B^22"))
		{
			R2A2B2 rab = new R2A2B2();
			rab.setJMenuBar(rab.createMenuBar());
			rab.setContentPane(rab.createContentPane());
			rab.setSize(600,375);
			this.hide();
			rab.show();
		}
		
		if(arg.equals("Back To R^2 = A^2 + B^2"))
		{
			R2A2B2 rab2 = new R2A2B2();
			rab2.setJMenuBar(rab2.createMenuBar());
			rab2.setContentPane(rab2.createContentPane());
			rab2.setSize(600,375);
			this.hide();
			rab2.show();
		}
		
		else if(arg.equals("Back To Forces In Multiple Dimensions2"))
		{
			ForcesInMultipleDimensions forces = new ForcesInMultipleDimensions();
			forces.setJMenuBar(forces.createMenuBar());
			forces.setContentPane(forces.createContentPane());
			forces.setSize(600,375);
			this.hide();
			forces.show();
		}
		
		else if(arg.equals("Back To Forces In Multiple Dimensions"))
		{
			ForcesInMultipleDimensions forces2 = new ForcesInMultipleDimensions();
			forces2.setJMenuBar(forces2.createMenuBar());
			forces2.setContentPane(forces2.createContentPane());
			forces2.setSize(600,375);
			this.hide();
			forces2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String rstring;
			String bstring;
			double a = 0;
			double b = 0;
			double r = 0;
			
			rstring = Rfield.getText();
			bstring = Bfield.getText();
			
			try
			{
				r = Double.parseDouble(rstring);
				b = Double.parseDouble(bstring);
				a = Math.sqrt(Math.pow(r,2) - Math.pow(b, 2));
				JOptionPane.showMessageDialog(null,"The Answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Rfield.setText("");
				Bfield.setText("");
				if(rstring == null || bstring == null)throw new Exception();
			}
			catch(Exception s)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String rstring;
			String bstring;
			double a = 0;
			double b = 0;
			double r = 0;
			
			rstring = Rfield.getText();
			bstring = Bfield.getText();
			
			try
			{
				r = Double.parseDouble(rstring);
				b = Double.parseDouble(bstring);
				a = Math.sqrt(Math.pow(r,2) - Math.pow(b, 2));
				JOptionPane.showMessageDialog(null,"The Answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Rfield.setText("");
				Bfield.setText("");
				if(rstring == null || bstring == null)throw new Exception();
			}
			catch(Exception s)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
			}
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please enter in information in the text fields then click calculate to solve for it","How To",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	//used to run frame
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		AforR2A2B2 a = new AforR2A2B2();
		a.setJMenuBar(a.createMenuBar());
		a.setContentPane(a.createContentPane());
		a.setSize(600,375);
		a.setVisible(true);
	}
		
	}

