/*
 * Program: A for Vf^2 = Vi^2 + 2A(Df - Di) Form
 * Programmer: Jay
 * Date: 4/26/010
 * Filename: ViforVf2Vi22ADfDi.java
 * Purpose: solve for Vi
 */
import java.awt.*;
import java.awt.event.*;

import javax.swing.*;
public class AforVf2Vi22ADfDi extends JFrame implements ActionListener{

	//items used in frame
	public JButton calculate;
	public JTextField Vffield;
	public JTextField Vifield;
	public JTextField Dffield;
	public JTextField Difield;
	public JLabel startupAlabel;
	public JLabel Vflabel;
	public JLabel Vilabel;
	public JLabel Dflabel;
	public JLabel Dilabel;
	public JButton backtoVf2Vi22ADfDi;
	public JButton backtoAcceleratingMotionForm;
	public JButton backtoMainForm;
	
	public AforVf2Vi22ADfDi()
	{
		super("A for Vf^2 = Vi^2 + 2A(Df - Di) Form");
	}
	
	//used for menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToAcceleratingMotionForm = new JMenuItem("Back To Accelerating Motion Form");
		mnuFileBackBackToAcceleratingMotionForm.setMnemonic(KeyEvent.VK_A);
		mnuFileBackBackToAcceleratingMotionForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form2");
		mnuFileBackBackToAcceleratingMotionForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcceleratingMotionForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenuItem mnuFileBackBackToVf2Vi22ADfDiForm = new JMenuItem("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form");
		mnuFileBackBackToVf2Vi22ADfDiForm.setMnemonic(KeyEvent.VK_V);
		mnuFileBackBackToVf2Vi22ADfDiForm.setDisplayedMnemonicIndex(0);
		mnuFileBackBackToVf2Vi22ADfDiForm.setActionCommand("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form2");
		mnuFileBackBackToVf2Vi22ADfDiForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToVf2Vi22ADfDiForm);
		
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_U);
		mnuAbout.setDisplayedMnemonicIndex(4);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_N);
		mnuInstructions.setDisplayedMnemonicIndex(1);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//container to hold the items
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupAlabel = new JLabel("enter information below to solve for A");
		northpanel.add(startupAlabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(5,5));
		Vffield = new JTextField(10);
		Vifield = new JTextField(10);
		Dffield = new JTextField(10);
		Difield = new JTextField(10);
		Vflabel = new JLabel("Vf");
		Vilabel = new JLabel("Vi");
		Dflabel = new JLabel("Df");
		Dilabel = new JLabel("Di");
		centerpanel.add(Vffield);
		centerpanel.add(Vflabel);
		centerpanel.add(Vifield);
		centerpanel.add(Vilabel);
		centerpanel.add(Dffield);
		centerpanel.add(Dflabel);
		centerpanel.add(Difield);
		centerpanel.add(Dilabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		southpanel.add(calculate);
		backtoVf2Vi22ADfDi = new JButton("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form");
		backtoVf2Vi22ADfDi.setActionCommand("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form");
		backtoVf2Vi22ADfDi.addActionListener(this);
		southpanel.add(backtoVf2Vi22ADfDi);
		backtoAcceleratingMotionForm = new JButton("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.addActionListener(this);
		southpanel.add(backtoAcceleratingMotionForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel,BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel,BorderLayout.SOUTH);
		
		return c;
		
		
	}
	
	//action commands for button clicks and menu item clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Accelerating Motion Form2"))
		{
			AcceleratingMotionEquationSelection k = new AcceleratingMotionEquationSelection();
			k.setJMenuBar(k.createMenuBar());
			k.setContentPane(k.createContentPane());
			k.setSize(600,375);
			this.hide();
			k.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form"))
		{
			AcceleratingMotionEquationSelection k2 = new AcceleratingMotionEquationSelection();
			k2.setJMenuBar(k2.createMenuBar());
			k2.setContentPane(k2.createContentPane());
			k2.setSize(600,375);
			this.hide();
			k2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form2"))
		{
			Vf2Vi22ADfDi vfviadfdi = new Vf2Vi22ADfDi();
			vfviadfdi.setJMenuBar(vfviadfdi.createMenuBar());
			vfviadfdi.setContentPane(vfviadfdi.createContentPane());
			vfviadfdi.setSize(600,375);
			this.hide();
			vfviadfdi.show();
		}
		
		else if(arg.equals("Back To Vf^2 = Vi^2 + 2A(Df - Di) Form"))
		{
			Vf2Vi22ADfDi vfviadfdi2 = new Vf2Vi22ADfDi();
			vfviadfdi2.setJMenuBar(vfviadfdi2.createMenuBar());
			vfviadfdi2.setContentPane(vfviadfdi2.createContentPane());
			vfviadfdi2.setSize(600,375);
			this.hide();
			vfviadfdi2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String vfstring;
			String vistring;
			String dfstring;
			String distring;
			
			double vf = 0;
			double vi = 0;
			double a = 0;
			double df = 0;
			double di = 0;
			double prea = 0;
			double prea2 = 0;
			
			vfstring = Vffield.getText();
			vistring = Vifield.getText();
			dfstring = Dffield.getText();
			distring = Difield.getText();
			
			try
			{
				vf = Double.parseDouble(vfstring);
				vi = Double.parseDouble(vistring);
				df = Double.parseDouble(dfstring);
				di = Double.parseDouble(distring);
				prea = Math.pow(vf,2) - Math.pow(vi,2);
				prea2 = 2 * (df - di);
			    a = prea / prea2;
				JOptionPane.showMessageDialog(null,"The answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Vffield.setText("");
				Vifield.setText("");
				Dffield.setText("");
				Difield.setText("");
				if(vfstring == null || vistring == null || dfstring == null || distring == null)throw new Exception();
			}
			catch(Exception r)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals","Error",JOptionPane.INFORMATION_MESSAGE);
				Vffield.setText("");
				Vifield.setText("");
				Dffield.setText("");
				Difield.setText("");
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String vfstring;
			String vistring;
			String dfstring;
			String distring;
			
			double vf = 0;
			double vi = 0;
			double a = 0;
			double df = 0;
			double di = 0;
			double prea = 0;
			double prea2 = 0;
			
			vfstring = Vffield.getText();
			vistring = Vifield.getText();
			dfstring = Dffield.getText();
			distring = Difield.getText();
			
			try
			{
				vf = Double.parseDouble(vfstring);
				vi = Double.parseDouble(vistring);
				df = Double.parseDouble(dfstring);
				di = Double.parseDouble(distring);
				prea = Math.pow(vf,2) - Math.pow(vi,2);
				prea2 = 2 * (df - di);
			    a = prea / prea2;
				JOptionPane.showMessageDialog(null,"The answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Vffield.setText("");
				Vifield.setText("");
				Dffield.setText("");
				Difield.setText("");
				if(vfstring == null || vistring == null || dfstring == null || distring == null)throw new Exception();
			}
			catch(Exception r)
			{
				JOptionPane.showMessageDialog(null,"You can only enter integers or decimals","Error",JOptionPane.INFORMATION_MESSAGE);
				Vffield.setText("");
				Vifield.setText("");
				Dffield.setText("");
				Difield.setText("");
			}
		}
		
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please enter information below and click calculate to solve for unknown variable.","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		AforVf2Vi22ADfDi a = new AforVf2Vi22ADfDi ();
		a.setJMenuBar(a.createMenuBar());
		a.setContentPane(a.createContentPane());
		a.setSize(600,375);
		a.setVisible(true);
	}
}
