/*
 * Program: A for Vf = Vi + A * Delta T Form
 * Programmer: Jay
 * Date: 4/23/010
 * Filename: AforVfViA.java
 * Purpose: to solve for A
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AforVfViADeltaT extends JFrame implements ActionListener{

	//comptents used in frame.
	public JLabel startupAlabel;
	public JLabel Vilabel;
	public JLabel Vflabel;
	public JTextField Vifield;
	public JTextField Vffield;
	public JTextField DeltaTfield;
	public JLabel DeltaTlabel;
	public JButton calculate;
	public JButton backtoVfViAForm;
	public JButton backtoAcceleratingMotionForm;
	public JButton backtoMainForm;
	
	public AforVfViADeltaT()
	{
		super("A for Vf = Vi + A * Delta T");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToVfViAForm = new JMenuItem("Back To Vf = Vi + A * Delta T Form");
		mnuFileBackBackToVfViAForm.setMnemonic(KeyEvent.VK_V);
		mnuFileBackBackToVfViAForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToVfViAForm.addActionListener(this);
		mnuFileBackBackToVfViAForm.setActionCommand("Back To Vf = Vi + A * Delta T Form2");
		mnuFileBack.add(mnuFileBackBackToVfViAForm);
		
		JMenuItem mnuFileBackBackToAcceleratingMotionForm = new JMenuItem("Back To Accelerating Motion Form");
		mnuFileBackBackToAcceleratingMotionForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToAcceleratingMotionForm.setDisplayedMnemonicIndex(23);
		mnuFileBackBackToAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form2");
		mnuFileBackBackToAcceleratingMotionForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcceleratingMotionForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_K);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(5);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.addActionListener(this);
		mnuInstructions.setActionCommand("Instructions");
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupAlabel = new JLabel("Enter in information to solve for A");
		northpanel.add(startupAlabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(3,3));
		Vifield = new JTextField(10);
		Vilabel = new JLabel("Vi");
		Vffield = new JTextField(10);
		Vflabel = new JLabel("Vf");
		DeltaTfield = new JTextField(10);
		DeltaTlabel = new JLabel("Delta T");
		centerpanel.add(Vifield);
		centerpanel.add(Vilabel);
		centerpanel.add(Vffield);
		centerpanel.add(Vflabel);
		centerpanel.add(DeltaTfield);
		centerpanel.add(DeltaTlabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		backtoVfViAForm = new JButton("Back To Vf = Vi + A * Delta T Form");
		backtoVfViAForm.setActionCommand("Back To Vf = Vi + A * Delta T Form");
		backtoVfViAForm.addActionListener(this);
		backtoAcceleratingMotionForm = new JButton("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(calculate);
		southpanel.add(backtoVfViAForm);
		southpanel.add(backtoAcceleratingMotionForm);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel, BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel, BorderLayout.SOUTH);
		
		return c;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Vf = Vi + A * Delta T Form2"))
		{
			VfViADeltaT vf = new VfViADeltaT();
			vf.setJMenuBar(vf.createMenuBar());
			vf.setContentPane(vf.createContentPane());
			vf.setSize(600,375);
			this.hide();
			vf.show();
		}
		
		else if(arg.equals("Back To Vf = Vi + A * Delta T Form"))
		{
			VfViADeltaT vf2 = new VfViADeltaT();
			vf2.setJMenuBar(vf2.createMenuBar());
			vf2.setContentPane(vf2.createContentPane());
			vf2.setSize(600,375);
			this.hide();
			vf2.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form2"))
		{
			AcceleratingMotionEquationSelection motion = new AcceleratingMotionEquationSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form"))
		{
			AcceleratingMotionEquationSelection motion2 = new AcceleratingMotionEquationSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String vistring;
			String vfstring;
			String deltatstring;
			double a = 0;
			double vf = 0;
			double vi = 0;
			double deltat = 0;
			
			vfstring = Vffield.getText();
			vistring = Vifield.getText();
			deltatstring = DeltaTfield.getText();
			
			try
			{
				vf = Double.parseDouble(vfstring);
				vi = Double.parseDouble(vistring);
				deltat = Double.parseDouble(deltatstring);
				a = (vf - vi) / deltat;
				JOptionPane.showMessageDialog(null,"Answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Vffield.setText("");
				DeltaTfield.setText("");
				Vifield.setText("");
				if(vfstring == null || vistring == null || deltatstring == null || deltat == 0)throw new Exception();
			}
			catch(Exception t)
			{
				JOptionPane.showMessageDialog(null,"Please enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				Vffield.setText("");
				Vifield.setText("");
				DeltaTfield.setText("");
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String vistring;
			String vfstring;
			String deltatstring;
			double a = 0;
			double vf = 0;
			double vi = 0;
			double deltat = 0;
			
			vfstring = Vffield.getText();
			vistring = Vifield.getText();
			deltatstring = DeltaTfield.getText();
			
			try
			{
				vf = Double.parseDouble(vfstring);
				vi = Double.parseDouble(vistring);
				deltat = Double.parseDouble(deltatstring);
				a = (vf - vi) / deltat;
				JOptionPane.showMessageDialog(null,"Answer is " + a,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Vffield.setText("");
				DeltaTfield.setText("");
				Vifield.setText("");
				if(vfstring == null || vistring == null || deltatstring == null || deltat == 0)throw new Exception();
			}
			catch(Exception t)
			{
				JOptionPane.showMessageDialog(null,"Please enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				Vffield.setText("");
				Vifield.setText("");
				DeltaTfield.setText("");
			}
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Enter in numbers into the textboxes and then click the calculate button to get the answer./nYou can leave at any time to other forms","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		AforVfViADeltaT A = new AforVfViADeltaT();
		A.setJMenuBar(A.createMenuBar());
		A.setContentPane(A.createContentPane());
		A.setSize(999,300);
		A.setVisible(true);
	}
	
	
}
