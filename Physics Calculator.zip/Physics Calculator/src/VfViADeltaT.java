/*
 * Program: Vf = Vi + A Form
 * Programmer: Jay
 * Date: 4/23/2010
 * Filename: VfViA.java
 * Purpose: To choose a variable to solve for in this equation
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;	
public class VfViADeltaT extends JFrame implements ActionListener{

	//items used in program
	public JLabel startuplabel;
	public JButton Vf;
	public JButton Vi;
	public JButton A;
	public JButton DeltaT;
	public JButton backtoAcceleratingMotionEquationsForm;
	public JButton backtoMainForm;
	
	//constructor method 
	public VfViADeltaT()
	{
		super("Vf = Vi + A * Delta T Form");
	}
	
	//creates a menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToAcceleratingMotionEquationsForm = new JMenuItem("Back To Accelerating Motion Form");
		mnuFileBackBackToAcceleratingMotionEquationsForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToAcceleratingMotionEquationsForm.setDisplayedMnemonicIndex(22);
		mnuFileBackBackToAcceleratingMotionEquationsForm.setActionCommand("Back To Accelerating Motion Form2");
		mnuFileBackBackToAcceleratingMotionEquationsForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcceleratingMotionEquationsForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_T);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(6);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseVf = new JMenuItem("Vf");
		mnuChooseVf.setMnemonic(KeyEvent.VK_V);
		mnuChooseVf.setDisplayedMnemonicIndex(0);
		mnuChooseVf.setActionCommand("Vf2");
		mnuChooseVf.addActionListener(this);
		mnuChoose.add(mnuChooseVf);
		
		JMenuItem mnuChooseVi = new JMenuItem("Vi");
		mnuChooseVi.setMnemonic(KeyEvent.VK_I);
		mnuChooseVi.setDisplayedMnemonicIndex(1);
		mnuChooseVi.setActionCommand("Vi2");
		mnuChooseVi.addActionListener(this);
		mnuChoose.add(mnuChooseVi);
		
		JMenuItem mnuChooseA = new JMenuItem("A");
		mnuChooseA.setMnemonic(KeyEvent.VK_A);
		mnuChooseA.setDisplayedMnemonicIndex(0);
		mnuChooseA.setActionCommand("A2");
		mnuChooseA.addActionListener(this);
		mnuChoose.add(mnuChooseA);
		
		JMenuItem mnuChooseDeltaT = new JMenuItem("Delta T");
		mnuChooseDeltaT.setMnemonic(KeyEvent.VK_D);
		mnuChooseDeltaT.setDisplayedMnemonicIndex(0);
		mnuChooseDeltaT.setActionCommand("DeltaT2");
		mnuChooseDeltaT.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaT);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_O);
		mnuAbout.setDisplayedMnemonicIndex(2);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_N);
		mnuInstructions.setDisplayedMnemonicIndex(1);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	//add compentents to frame
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a variable to solve for in Vf = Vi + A");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		Vf = new JButton("Vf");
		Vf.setActionCommand("Vf");
		Vf.addActionListener(this);
		buttonpanel.add(Vf);
		Vi = new JButton("Vi");
		Vi.setActionCommand("Vi");
		Vi.addActionListener(this);
		buttonpanel.add(Vi);
		A = new JButton("A");
		A.setActionCommand("A");
		A.addActionListener(this);
		buttonpanel.add(A);
		DeltaT = new JButton("Delta T");
		DeltaT.setActionCommand("Delta T");
		DeltaT.addActionListener(this);
		buttonpanel.add(DeltaT);
		backtoAcceleratingMotionEquationsForm = new JButton("Back To Accelerating Motion Form");
		backtoAcceleratingMotionEquationsForm.setActionCommand("Back To Accelerating Motion Form");
		backtoAcceleratingMotionEquationsForm.addActionListener(this);
		buttonpanel.add(backtoAcceleratingMotionEquationsForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoMainForm);
		
		
		Container d = getContentPane();
		d.setLayout(new BorderLayout());
		d.add(labelpanel,BorderLayout.NORTH);
		d.add(buttonpanel,BorderLayout.CENTER);
		
		return d;
	}
	
	//method for button and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Main Form2"))
		{
			MainForm q = new MainForm();
			q.setJMenuBar(q.createMenuBar());
			q.setContentPane(q.createContentPane());
			q.setSize(600,375);
			this.hide();
			q.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm q2 = new MainForm();
			q2.setJMenuBar(q2.createMenuBar());
			q2.setContentPane(q2.createContentPane());
			q2.setSize(600,375);
			this.hide();
			q2.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form2"))
		{
			AcceleratingMotionEquationSelection motion = new AcceleratingMotionEquationSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form"))
		{
			AcceleratingMotionEquationSelection motion2 = new AcceleratingMotionEquationSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		else if(arg.equals("Vf2"))
		{
			VfforVfViADeltaT vf = new VfforVfViADeltaT();
			vf.setJMenuBar(vf.createMenuBar());
			vf.setContentPane(vf.createContentPane());
			vf.setSize(600,375);
			this.hide();
			vf.show();
		}
		
		else if(arg.equals("Vf"))
		{
			VfforVfViADeltaT vf2 = new VfforVfViADeltaT();
			vf2.setJMenuBar(vf2.createMenuBar());
			vf2.setContentPane(vf2.createContentPane());
			vf2.setSize(600,375);
			this.hide();
			vf2.show();
		}
		
		else if(arg.equals("Vi2"))
		{
			ViforVfViADeltaT vi = new ViforVfViADeltaT();
			vi.setJMenuBar(vi.createMenuBar());
			vi.setContentPane(vi.createContentPane());
			vi.setSize(600,375);
			this.hide();
			vi.show();
		}
		
		else if(arg.equals("Vi"))
		{
			ViforVfViADeltaT vi2 = new ViforVfViADeltaT();
			vi2.setJMenuBar(vi2.createMenuBar());
			vi2.setContentPane(vi2.createContentPane());
			vi2.setSize(600,375);
			this.hide();
			vi2.show();
		}
		
		else if(arg.equals("A2"))
		{
			AforVfViADeltaT A = new AforVfViADeltaT();
			A.setJMenuBar(A.createMenuBar());
			A.setContentPane(A.createContentPane());
			A.setSize(600,375);
			this.hide();
			A.show();
		}
		
		else if(arg.equals("A"))
		{
			AforVfViADeltaT A2 = new AforVfViADeltaT();
			A2.setJMenuBar(A2.createMenuBar());
			A2.setContentPane(A2.createContentPane());
			A2.setSize(600,375);
			this.hide();
			A2.show();
		}
		
		else if(arg.equals("DeltaT2"))
		{
			DeltaTforVfViADeltaT deltat = new DeltaTforVfViADeltaT();
			deltat.setJMenuBar(deltat.createMenuBar());
			deltat.setContentPane(deltat.createContentPane());
			deltat.setSize(600,375);
			this.hide();
			deltat.show();
		}
		
		else if(arg.equals("Delta T"))
		{
			DeltaTforVfViADeltaT deltat2 = new DeltaTforVfViADeltaT();
			deltat2.setJMenuBar(deltat2.createMenuBar());
			deltat2.setContentPane(deltat2.createContentPane());
			deltat2.setSize(600,375);
			this.hide();
			deltat2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please select a variable below you want to solve for.\nYou will then be taken to a form for solving for that variable","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		VfViADeltaT vfviadeltat = new VfViADeltaT();
		vfviadeltat.setJMenuBar(vfviadeltat.createMenuBar());
		vfviadeltat.setContentPane(vfviadeltat.createContentPane());
		vfviadeltat.setSize(600,375);
		vfviadeltat.setVisible(true);
	}
}
