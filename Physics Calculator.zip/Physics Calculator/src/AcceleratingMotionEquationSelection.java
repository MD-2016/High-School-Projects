/*
 * Program: Accelerating Motion Equations Form
 * Programmer: Jay
 * Date: 4/22/2010
 * Filename: AcceleratingMotionEquationSelection.java
 * Purpose: to select equations to solve for
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class AcceleratingMotionEquationSelection extends JFrame implements ActionListener{

	//items used to select equation
	public JLabel startuplabel;
	public JButton ADeltaVDeltaT;
	public JButton VfViADeltaT;
	public JButton DfDiViTfonehalfATf2;
	public JButton Vf2Vi2ADfDi;
	public JButton backtoMainForm;
	
	
	public AcceleratingMotionEquationSelection()
	{
		super("Accelerating Motion Equations Form");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileBack = new JMenuItem("Back To Main Form");
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFileBack.setActionCommand("Back To Main Form2");
		mnuFileBack.addActionListener(this);
		mnuFile.add(mnuFileBack);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseADeltaVDeltaT = new JMenuItem("A = Delta V / Delta T");
		mnuChooseADeltaVDeltaT.setMnemonic(KeyEvent.VK_A);
		mnuChooseADeltaVDeltaT.setDisplayedMnemonicIndex(0);
		mnuChooseADeltaVDeltaT.setActionCommand("A = Delta V / Delta T2");
		mnuChooseADeltaVDeltaT.addActionListener(this);
		mnuChoose.add(mnuChooseADeltaVDeltaT);
		
		JMenuItem mnuChooseVfViADeltaT = new JMenuItem("Vf = Vi + A * Delta T");
		mnuChooseVfViADeltaT.setMnemonic(KeyEvent.VK_V);
		mnuChooseVfViADeltaT.setDisplayedMnemonicIndex(0);
		mnuChooseVfViADeltaT.setActionCommand("Vf = Vi + A * Delta T2");
		mnuChooseVfViADeltaT.addActionListener(this);
		mnuChoose.add(mnuChooseVfViADeltaT);
		
		JMenuItem mnuChooseDfDiViTfonehalfATf2 = new JMenuItem("Df = Di + ViTf + 1/2ATf^2");
		mnuChooseDfDiViTfonehalfATf2.setMnemonic(KeyEvent.VK_D);
		mnuChooseDfDiViTfonehalfATf2.setDisplayedMnemonicIndex(0);
		mnuChooseDfDiViTfonehalfATf2.setActionCommand("Df = Di + ViTf + 1/2ATf^22");
		mnuChooseDfDiViTfonehalfATf2.addActionListener(this);
		mnuChoose.add(mnuChooseDfDiViTfonehalfATf2);
		
		JMenuItem mnuChooseVf2Vi2ADfDi = new JMenuItem("Vf^2 = Vi^2 + 2A(Df - Di)");
		mnuChooseVf2Vi2ADfDi.setMnemonic(KeyEvent.VK_V);
		mnuChooseVf2Vi2ADfDi.setDisplayedMnemonicIndex(4);
		mnuChooseVf2Vi2ADfDi.setActionCommand("Vf^2 = Vi^2 + 2A(Df - Di)2");
		mnuChooseVf2Vi2ADfDi.addActionListener(this);
		mnuChoose.add(mnuChooseVf2Vi2ADfDi);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuChoose.setMnemonic(KeyEvent.VK_O);
		mnuChoose.setDisplayedMnemonicIndex(3);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuInstructions.addActionListener(this);
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel labelpanel = new JPanel();
		labelpanel.setLayout(new FlowLayout());
		startuplabel = new JLabel("Please select a equation below to solve for it");
		labelpanel.add(startuplabel);
		
		JPanel buttonpanel = new JPanel();
		buttonpanel.setLayout(new GridLayout(0,1));
		ADeltaVDeltaT = new JButton("A = Delta V / Delta T");
		ADeltaVDeltaT.setActionCommand("A = Delta V / Delta T");
		ADeltaVDeltaT.addActionListener(this);
		buttonpanel.add(ADeltaVDeltaT);
		VfViADeltaT = new JButton("Vf = Vi + A * Delta T");
		VfViADeltaT.setActionCommand("Vf = Vi + A * Delta T");
		VfViADeltaT.addActionListener(this);
		buttonpanel.add(VfViADeltaT);
		DfDiViTfonehalfATf2 = new JButton("Df = Di + ViTf + 1/2ATf^2");
		DfDiViTfonehalfATf2.setActionCommand("DfDiViTfonehalfATf2");
		DfDiViTfonehalfATf2.addActionListener(this);
		buttonpanel.add(DfDiViTfonehalfATf2);
		Vf2Vi2ADfDi = new JButton("Vf^2 = Vi^2 + 2A(Df - Di)");
		Vf2Vi2ADfDi.setActionCommand("Vf^2 = Vi^2 + 2A(Df - Di)");
		Vf2Vi2ADfDi.addActionListener(this);
		buttonpanel.add(Vf2Vi2ADfDi);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		buttonpanel.add(backtoMainForm);
		
		Container q = getContentPane();
		q.setLayout(new BorderLayout());
		q.add(labelpanel,BorderLayout.NORTH);
		q.add(buttonpanel,BorderLayout.CENTER);
		
		return q;
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("A = Delta V / Delta T2"))
		{
			ADeltaVDeltaT A = new ADeltaVDeltaT();
			A.setJMenuBar(A.createMenuBar());
			A.setContentPane(A.createContentPane());
			A.setSize(600,375);
			this.hide();
			A.show();
		}
		
		if(arg.equals("A = Delta V / Delta T"))
		{
			ADeltaVDeltaT A2 = new ADeltaVDeltaT();
			A2.setJMenuBar(A2.createMenuBar());
			A2.setContentPane(A2.createContentPane());
			A2.setSize(600,375);
			this.hide();
			A2.show();
		}
		
		else if(arg.equals("Vf = Vi + A * Delta T2"))
		{
			VfViADeltaT vf = new VfViADeltaT();
			vf.setJMenuBar(vf.createMenuBar());
			vf.setContentPane(vf.createContentPane());
			vf.setSize(600,375);
			this.hide();
			vf.show();
		}
		
		else if(arg.equals("Vf = Vi + A * Delta T"))
		{
			VfViADeltaT vf2 = new VfViADeltaT();
			vf2.setJMenuBar(vf2.createMenuBar());
			vf2.setContentPane(vf2.createContentPane());
			vf2.setSize(600,375);
			this.hide();
			vf2.show();
		}
		
		else if(arg.equals("Df = Di + ViTf + 1/2ATf^22"))
		{
			DfDiViTfOneHalfATf2 df = new DfDiViTfOneHalfATf2();
			df.setJMenuBar(df.createMenuBar());
			df.setContentPane(df.createContentPane());
			df.setSize(600,375);
			this.hide();
			df.show();
		}
		
		else if(arg.equals("DfDiViTfonehalfATf2"))
		{
			DfDiViTfOneHalfATf2 df2 = new DfDiViTfOneHalfATf2();
			df2.setJMenuBar(df2.createMenuBar());
			df2.setContentPane(df2.createContentPane());
			df2.setSize(600,375);
			this.hide();
			df2.show();
		}
		
		else if(arg.equals("Vf^2 = Vi^2 + 2A(Df - Di)2"))
		{
			Vf2Vi22ADfDi vf = new Vf2Vi22ADfDi();
			vf.setJMenuBar(vf.createMenuBar());
			vf.setContentPane(vf.createContentPane());
			vf.setSize(600,375);
			this.hide();
			vf.show();
		}
		
		else if(arg.equals("Vf^2 = Vi^2 + 2A(Df - Di)"))
		{
			Vf2Vi22ADfDi vf2 = new Vf2Vi22ADfDi();
			vf2.setJMenuBar(vf2.createMenuBar());
			vf2.setContentPane(vf2.createContentPane());
			vf2.setSize(600,375);
			this.hide();
			vf2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Please select a button of a equation. You will then be taken to that equations form to choose a variable to solve for and then to a form to solve for that variable. This can be done by menu or button.","Help",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		AcceleratingMotionEquationSelection accelerate = new AcceleratingMotionEquationSelection();
		accelerate.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		accelerate.setJMenuBar(accelerate.createMenuBar());
		accelerate.setContentPane(accelerate.createContentPane());
		accelerate.setSize(600,375);
		accelerate.setVisible(true);
	}
	
}
