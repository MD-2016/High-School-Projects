/*
 * Program: Physics Calculator Program
 * Programmer: Jay
 * Date: 4/22/2010
 * Filename: DeltaDDfDi.java
 * Purpose: To select a variable to solve for in Delta D = Df - Di.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DeltaDDfDi extends JFrame implements ActionListener{
	
	//items used.
	JLabel selectDeltaD = new JLabel("Please select a variable below to be taken to that form to solve for it");
	JButton DeltaD = new JButton("Delta D");
	JButton Df = new JButton("Df");
	JButton Di = new JButton("Di");
	JButton backtoMainForm = new JButton("Back To Main Form");
	JButton backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
	
	//Constructor Method
	public DeltaDDfDi()
	{
		super("Delta D = Df - Di Equation Form");
	}
	
	//method used for making menu structure.
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenu back = new JMenu("Back");
		back.setMnemonic(KeyEvent.VK_B);
		back.setDisplayedMnemonicIndex(0);
		mnuFile.add(back);
		
		JMenuItem backtoMainForm = new JMenuItem("Back To Main Form");
		backtoMainForm.setMnemonic(KeyEvent.VK_M);
		backtoMainForm.setDisplayedMnemonicIndex(1);
		backtoMainForm.setActionCommand("Back To Main Form2");
		backtoMainForm.addActionListener(this);
		back.add(backtoMainForm);
		
		JMenuItem backtoRepresentingMotionEquationsSelection = new JMenuItem("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsSelection.setMnemonic(KeyEvent.VK_R);
		backtoRepresentingMotionEquationsSelection.setDisplayedMnemonicIndex(1);
		backtoRepresentingMotionEquationsSelection.setActionCommand("Back To Representing Motion Equations Form2");
		backtoRepresentingMotionEquationsSelection.addActionListener(this);
		back.add(backtoRepresentingMotionEquationsSelection);
		
		JMenu mnuChoose = new JMenu("Choose",true);
		mnuChoose.setMnemonic(KeyEvent.VK_C);
		mnuChoose.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuChoose);
		
		JMenuItem mnuChooseDeltaD = new JMenuItem("Delta D");
		mnuChooseDeltaD.setMnemonic(KeyEvent.VK_D);
		mnuChooseDeltaD.setDisplayedMnemonicIndex(1);
		mnuChooseDeltaD.setActionCommand("Delta D2");
		mnuChooseDeltaD.addActionListener(this);
		mnuChoose.add(mnuChooseDeltaD);
		
		JMenuItem mnuChooseDf = new JMenuItem("Df");
		mnuChooseDf.setMnemonic(KeyEvent.VK_D + KeyEvent.VK_F);
		mnuChooseDf.setDisplayedMnemonicIndex(1);
		mnuChooseDf.setActionCommand("Df2");
		mnuChooseDf.addActionListener(this);
		mnuChoose.add(mnuChooseDf);
		
		JMenuItem mnuChooseDi = new JMenuItem("Di");
		mnuChooseDi.setMnemonic(KeyEvent.VK_D + KeyEvent.VK_I);
		mnuChooseDi.setDisplayedMnemonicIndex(1);
		mnuChooseDi.setActionCommand("Di2");
		mnuChooseDi.addActionListener(this);
		mnuChoose.add(mnuChooseDi);
		
		JMenu mnuAbout = new JMenu("About");
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
		mnuAboutInstructions.setMnemonic(KeyEvent.VK_I);
		mnuAboutInstructions.setDisplayedMnemonicIndex(1);
		mnuAboutInstructions.setActionCommand("Instructions");
		mnuAboutInstructions.addActionListener(this);
		mnuAbout.add(mnuAboutInstructions);
		
		return mnuBar;
	}
	
	//items added to frame with container method
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		northpanel.add(selectDeltaD);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(0,1));
		centerpanel.add(DeltaD);
		DeltaD.addActionListener(this);
		DeltaD.setActionCommand("Delta D");
		centerpanel.add(Df);
		Df.addActionListener(this);
		Df.setActionCommand("Df");
		centerpanel.add(Di);
		Di.addActionListener(this);
		Di.setActionCommand("Di");
		centerpanel.add(backtoRepresentingMotionEquationsForm);
		backtoRepresentingMotionEquationsForm.addActionListener(this);
		backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
		centerpanel.add(backtoMainForm);
		backtoMainForm.addActionListener(this);
		backtoMainForm.setActionCommand("Back To Main Form");
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel, BorderLayout.NORTH);
		c.add(centerpanel, BorderLayout.CENTER);
		
		return c;
	}
	
	//used to implement menu clicks and button presses
	public void actionPerformed(ActionEvent e)
	{
		String args = e.getActionCommand();
		
		//calls the main form 
		if(args == "Back To Main Form2")
		{
			MainForm w = new MainForm();
			w.setMenuBar(w.getMenuBar());
			w.setContentPane(w.createContentPane());
			w.show();
			this.hide();
			w.setSize(600,375);
		}
		
		//cals the main form
		else if(args == "Back To Main Form")
		{
			MainForm s = new MainForm();
			s.setMenuBar(s.getMenuBar());
			s.setContentPane(s.createContentPane());
			s.show();
			this.hide();
			s.setSize(600,375);
		}
		
		//calls the Representing Motion Equation Form
		else if(args == "Back To Representing Motion Equations Form2")
		{
			RepresentingMotionEquationsSelection m = new RepresentingMotionEquationsSelection();
			m.setJMenuBar(m.createMenuBar());
			m.setContentPane(m.createContentPane());
			m.show();
			this.hide();
			m.setSize(600,375);
			
		}
		
		//calls the Representing Motion Equation Form
		else if(args == "Back To Representing Motion Equations Form")
		{
			RepresentingMotionEquationsSelection f = new RepresentingMotionEquationsSelection();
			f.setJMenuBar(f.createMenuBar());
			f.setContentPane(f.createContentPane());
			f.setSize(600,375);
			this.hide();
			f.show();
		}
		
		
		//calls Delta D for Delta D = Df - Di Form
		else if(args == "Delta D2")
		{
			DeltaDforDeltaDDfDi w = new DeltaDforDeltaDDfDi();
			w.setJMenuBar(w.createMenuBar());
			w.setContentPane(w.createContentPane());
			w.setSize(600,375);
			this.hide();
			w.show();
		}
		
		//calls Delta D for Delta D = Df - Di Form
		else if(args == "Delta D")
		{
			DeltaDforDeltaDDfDi a = new DeltaDforDeltaDDfDi();
			a.setJMenuBar(a.createMenuBar());
			a.setContentPane(a.createContentPane());
			a.setSize(600,375);
			this.hide();
			a.show();
		}
		
		//calls Df for Delta D = Df - Di Form
		else if(args == "Df2")
		{
			DfforDeltaDDfDi g = new DfforDeltaDDfDi();
			g.setJMenuBar(g.createMenuBar());
			g.setContentPane(g.createContentPane());
			g.setSize(600,375);
			this.hide();
			g.show();
		}
		
		//calls Df for Delta D = Df - Di Form
		else if(args == "Df")
		{
			DfforDeltaDDfDi r = new DfforDeltaDDfDi();
			r.setJMenuBar(r.createMenuBar());
			r.setContentPane(r.createContentPane());
			r.setSize(600,375);
			this.hide();
			r.show();
		}
		
		//calls Di for Delta D = Df - Di Form
		else if(args.equals("Di2"))
		{
			DiforDeltaDDfDi Di = new DiforDeltaDDfDi();
			Di.setJMenuBar(Di.createMenuBar());
			Di.setContentPane(Di.createContentPane());
			Di.setSize(600,375);
			this.hide();
			Di.show();
		}
		
		//calls Di for Delta D = Df - Di Form
		else if(args.equals("Di"))
		{
			DiforDeltaDDfDi Di2 = new DiforDeltaDDfDi();
			Di2.setJMenuBar(Di2.createMenuBar());
			Di2.setContentPane(Di2.createContentPane());
			Di2.setSize(600,375);
			this.hide();
			Di2.show();
		}
		
		//how to use this form
		else if(args == "Instructions")
		{
			JOptionPane.showMessageDialog(null,"To operate this form involves 2 easy steps. The first step is to select your variable for this equation and either click button. You will then be taken to a form to help solve for chosen variable. The second step is you can choose by using the Choose menu and selecting a variable from there as well to go to the form to solve for chosen variable. You can also just go back to previous form or to main form by the same ways","Instructions",JOptionPane.INFORMATION_MESSAGE);
		}
	}
	
	//main method to create JFrame
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		DeltaDDfDi t = new DeltaDDfDi();
		t.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		 t.setJMenuBar(t.createMenuBar());
		 t.setContentPane(t.createContentPane());
		 t.setSize(600,375);
		 t.setVisible(true);
		 t.setResizable(false);
		 t.setVisible(true);
	}
		
	}
	
	
	

