/*
 * Program: Df for Delta D = Df - Di
 * Programmer: Jay
 * Filename: DfforDeltaDDfDi.java
 * Date: 4/19/010
 * Purpose: Solving Df variable in equation Delta D = Df - Di
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DfforDeltaDDfDi extends JFrame implements ActionListener{
	
	//items used for solving
	public JButton calculate;
	public JButton backtoMainForm;
	public JButton backtoRepresentingMotionEquationsForm;
	public JButton backtoDeltaDDfDiForm;
	public JLabel DeltaDlabel;
	public JTextField DeltaDField;
	public JTextField DiField;
	public JLabel Dilabel;
	public JLabel Dflabel;
	
	//constructor method is called
	public DfforDeltaDDfDi()
	{
		super("Df for Delta D = Df - Di");
	}
	
	//used to create menu structure
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(1);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(1);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(9);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenuItem mnuFileBackBackToRepresentingMotionEquationsForm = new JMenuItem("Back To Representing Motion Equations Form");
		mnuFileBackBackToRepresentingMotionEquationsForm.setMnemonic(KeyEvent.VK_R);
		mnuFileBackBackToRepresentingMotionEquationsForm.setDisplayedMnemonicIndex(9);
		mnuFileBackBackToRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form2");
		mnuFileBackBackToRepresentingMotionEquationsForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToRepresentingMotionEquationsForm);
		
		JMenuItem mnuFileBackBackToDeltaDDfDiForm = new JMenuItem("Back To Delta D = Df - Di Form");
		mnuFileBackBackToDeltaDDfDiForm.setMnemonic(KeyEvent.VK_D);
		mnuFileBackBackToDeltaDDfDiForm.setDisplayedMnemonicIndex(9);
		mnuFileBackBackToDeltaDDfDiForm.setActionCommand("Back To Delta D = Df - Di Form2");
		mnuFileBackBackToDeltaDDfDiForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToDeltaDDfDiForm);
		
		JMenu mnuAbout = new JMenu("About");
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
		mnuAboutInstructions.setMnemonic(KeyEvent.VK_I);
		mnuAboutInstructions.setDisplayedMnemonicIndex(1);
		mnuAboutInstructions.setActionCommand("Instructions");
		mnuAboutInstructions.addActionListener(this);
		mnuAbout.add(mnuAboutInstructions);
		
		return mnuBar;
	}
	
	//creates a container to hold items
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		Dflabel = new JLabel("Please enter in information below to solve for Df");
		northpanel.add(Dflabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(2,2));
		DeltaDField = new JTextField(10);
		DeltaDlabel = new JLabel("Delta D");
		DiField = new JTextField(10);
		Dilabel = new JLabel("Di");
		centerpanel.add(DeltaDField);
		centerpanel.add(DeltaDlabel);
		centerpanel.add(DiField);
		centerpanel.add(Dilabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.addActionListener(this);
		calculate.setActionCommand("Calculate");
		southpanel.add(calculate);
		backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
		backtoRepresentingMotionEquationsForm.addActionListener(this);
		southpanel.add(backtoRepresentingMotionEquationsForm);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.addActionListener(this);
		backtoMainForm.setActionCommand("Back To Main Form");
		southpanel.add(backtoMainForm);
		backtoDeltaDDfDiForm = new JButton("Back To Delta D = Df - Di Form");
		backtoDeltaDDfDiForm.setActionCommand("Back To Delta D = Df - Di Form");
		backtoDeltaDDfDiForm.addActionListener(this);
		southpanel.add(backtoDeltaDDfDiForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel, BorderLayout.NORTH);
		c.add(centerpanel, BorderLayout.CENTER);
		c.add(southpanel, BorderLayout.SOUTH);
		
		return c;
	}
	
	//used to implement button and menu clicks
	public void actionPerformed(ActionEvent e)
	{
		String args = e.getActionCommand();
		
		//go to main form
		if(args.equals("Back To Main Form2"))
		{
			MainForm y = new MainForm();
			y.setJMenuBar(y.createMenuBar());
			y.setContentPane(y.createContentPane());
			y.setSize(600,375);
			this.hide();
			y.show();
		}
		
		//go to main form
		else if(args.equals("Back To Main Form"))
		{
			MainForm w = new MainForm();
			w.setJMenuBar(w.createMenuBar());
			w.setContentPane(w.createContentPane());
			w.setSize(600,375);
			this.hide();
			w.show();
		}
		
		//go to representing motion equations form
		else if(args.equals("Back To Representing Motion Equations Form2"))
		{
			RepresentingMotionEquationsSelection q = new RepresentingMotionEquationsSelection();
			q.setJMenuBar(q.createMenuBar());
			q.setContentPane(q.createContentPane());
			q.setSize(600,375);
			this.hide();
			q.show();
		}
		
		//go to representing motion equation form
		else if(args.equals("Back To Representing Motion Equations Form"))
		{
			RepresentingMotionEquationsSelection a = new RepresentingMotionEquationsSelection();
			a.setJMenuBar(a.createMenuBar());
			a.setContentPane(a.createContentPane());
			a.setSize(600,375);
			this.hide();
			a.show();
		}
		
		//go to delta d = df - di
		else if(args.equals("Back To Delta D = Df - Di Form2"))
		{
			DeltaDDfDi d = new DeltaDDfDi();
			d.setJMenuBar(d.createMenuBar());
			d.setContentPane(d.createContentPane());
			d.setSize(600,375);
			this.hide();
			d.show();
		}
		
		//go to delta d = df - di
		else if(args.equals("Back To Delta D = Df - Di Form"))
		{
			DeltaDDfDi z = new DeltaDDfDi();
			z.setJMenuBar(z.createMenuBar());
			z.setContentPane(z.createContentPane());
			z.setSize(600,375);
			this.hide();
			z.show();
		}
		
		//solve for Df
		else if(args.equals("Calculate2"))
		{
			//variables used for solving
			String deltadstring;
			String distring;
			double deltad = 0;
			double di = 0;
			double df = 0;
			
			//method used to catch for errors
			try
			{
				deltadstring = DeltaDField.getText();
				distring = DiField.getText();
				deltad = Double.parseDouble(deltadstring);
				di = Double.parseDouble(distring);
				if(deltadstring == null || distring == null)throw new Exception();
				df = deltad + di;
				JOptionPane.showMessageDialog(null,"Df = " + df);
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null,"You must enter the numbers in decimal or integer format only","Error",JOptionPane.INFORMATION_MESSAGE);
				DeltaDField.setText("");
				DiField.setText("");
			}
			
		}
		
		//solve for df
		else if(args.equals("Calculate"))
		{
			//variables used for solving
			String deltadstring;
			String distring;
			double deltad = 0;
			double di = 0;
			double df = 0;
			
			//method used for error catching
			try
			{
				deltadstring = DeltaDField.getText();
				distring = DiField.getText();
				deltad = Double.parseDouble(deltadstring);
				di = Double.parseDouble(distring);
				if(deltadstring == null || distring == null)throw new Exception();
				df = deltad + di;
				JOptionPane.showMessageDialog(null,"Df = " + df);
			}
			catch(Exception d)
			{
				JOptionPane.showMessageDialog(null,"You must enter the numbers in decimal or integer format only","Error",JOptionPane.INFORMATION_MESSAGE);
				DeltaDField.setText("");
				DiField.setText("");
			}
		}
	}
	
	//creates a runs jframe
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		DfforDeltaDDfDi d = new DfforDeltaDDfDi();
		d.setSize(900,149);
		d.setJMenuBar(d.createMenuBar());
		d.setContentPane(d.createContentPane());
		d.setVisible(true);
	}
}
