/*
 * Program: Vi for Vf = Vi + A * Delta T Form
 * Programmer: Jay
 * Date: 4/23/010
 * Filename: ViforVfViA.java
 * Purpose: to solve for Vi 
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class ViforVfViADeltaT extends JFrame implements ActionListener{

	//comptents used in frame.
	public JLabel startupVilabel;
	public JLabel Vflabel;
	public JLabel Alabel;
	public JTextField Vffield;
	public JTextField Afield;
	public JTextField DeltaTfield;
	public JLabel DeltaTlabel;
	public JButton calculate;
	public JButton backtoVfViAForm;
	public JButton backtoAcceleratingMotionForm;
	public JButton backtoMainForm;
	
	public ViforVfViADeltaT()
	{
		super("Vi for Vf = Vi + A * Delta T");
	}
	
	public JMenuBar createMenuBar()
	{
		JMenuBar mnuBar = new JMenuBar();
		setJMenuBar(mnuBar);
		
		JMenu mnuFile = new JMenu("File",true);
		mnuFile.setMnemonic(KeyEvent.VK_F);
		mnuFile.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuFile);
		
		JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
		mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
		mnuFileCalculate.setDisplayedMnemonicIndex(0);
		mnuFileCalculate.setActionCommand("Calculate2");
		mnuFileCalculate.addActionListener(this);
		mnuFile.add(mnuFileCalculate);
		
		JMenu mnuFileBack = new JMenu("Back",true);
		mnuFileBack.setMnemonic(KeyEvent.VK_B);
		mnuFileBack.setDisplayedMnemonicIndex(0);
		mnuFile.add(mnuFileBack);
		
		JMenuItem mnuFileBackBackToVfViAForm = new JMenuItem("Back To Vf = Vi + A * Delta T Form");
		mnuFileBackBackToVfViAForm.setMnemonic(KeyEvent.VK_V);
		mnuFileBackBackToVfViAForm.setDisplayedMnemonicIndex(10);
		mnuFileBackBackToVfViAForm.setActionCommand("Back To Vf = Vi + A * Delta T Form2");
		mnuFileBack.add(mnuFileBackBackToVfViAForm);
		
		JMenuItem mnuFileBackBackToAcceleratingMotionForm = new JMenuItem("Back To Accelerating Motion Form");
		mnuFileBackBackToAcceleratingMotionForm.setMnemonic(KeyEvent.VK_M);
		mnuFileBackBackToAcceleratingMotionForm.setDisplayedMnemonicIndex(23);
		mnuFileBackBackToAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form2");
		mnuFileBackBackToAcceleratingMotionForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToAcceleratingMotionForm);
		
		JMenuItem mnuFileBackBackToMainForm = new JMenuItem("Back To Main Form");
		mnuFileBackBackToMainForm.setMnemonic(KeyEvent.VK_K);
		mnuFileBackBackToMainForm.setDisplayedMnemonicIndex(5);
		mnuFileBackBackToMainForm.setActionCommand("Back To Main Form2");
		mnuFileBackBackToMainForm.addActionListener(this);
		mnuFileBack.add(mnuFileBackBackToMainForm);
		
		JMenu mnuAbout = new JMenu("About",true);
		mnuAbout.setMnemonic(KeyEvent.VK_A);
		mnuAbout.setDisplayedMnemonicIndex(0);
		mnuBar.add(mnuAbout);
		
		JMenuItem mnuInstructions = new JMenuItem("Instructions");
		mnuInstructions.setMnemonic(KeyEvent.VK_I);
		mnuInstructions.setDisplayedMnemonicIndex(0);
		mnuInstructions.setActionCommand("Instructions");
		mnuAbout.add(mnuInstructions);
		
		return mnuBar;
	}
	
	public Container createContentPane()
	{
		JPanel northpanel = new JPanel();
		northpanel.setLayout(new FlowLayout());
		startupVilabel = new JLabel("Enter in information to solve for Vi");
		northpanel.add(startupVilabel);
		
		JPanel centerpanel = new JPanel();
		centerpanel.setLayout(new GridLayout(3,3));
		Vffield = new JTextField(10);
		Vflabel = new JLabel("Vf");
		Afield = new JTextField(10);
		Alabel = new JLabel("A");
		DeltaTfield = new JTextField(10);
		DeltaTlabel = new JLabel("Delta T");
		centerpanel.add(Vffield);
		centerpanel.add(Vflabel);
		centerpanel.add(Afield);
		centerpanel.add(Alabel);
		centerpanel.add(DeltaTfield);
		centerpanel.add(DeltaTlabel);
		
		JPanel southpanel = new JPanel();
		southpanel.setLayout(new FlowLayout());
		calculate = new JButton("Calculate");
		calculate.setActionCommand("Calculate");
		calculate.addActionListener(this);
		backtoVfViAForm = new JButton("Back To Vf = Vi + A * Delta T Form");
		backtoVfViAForm.setActionCommand("Back To Vf = Vi + A * Delta T Form");
		backtoVfViAForm.addActionListener(this);
		backtoAcceleratingMotionForm = new JButton("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.setActionCommand("Back To Accelerating Motion Form");
		backtoAcceleratingMotionForm.addActionListener(this);
		backtoMainForm = new JButton("Back To Main Form");
		backtoMainForm.setActionCommand("Back To Main Form");
		backtoMainForm.addActionListener(this);
		southpanel.add(calculate);
		southpanel.add(backtoVfViAForm);
		southpanel.add(backtoAcceleratingMotionForm);
		southpanel.add(backtoMainForm);
		
		Container c = getContentPane();
		c.setLayout(new BorderLayout());
		c.add(northpanel, BorderLayout.NORTH);
		c.add(centerpanel,BorderLayout.CENTER);
		c.add(southpanel, BorderLayout.SOUTH);
		
		return c;
	}
	
	public void actionPerformed(ActionEvent e)
	{
		String arg = e.getActionCommand();
		
		if(arg.equals("Back To Vf = Vi + A * Delta T Form2"))
		{
			VfViADeltaT vf = new VfViADeltaT();
			vf.setJMenuBar(vf.createMenuBar());
			vf.setContentPane(vf.createContentPane());
			vf.setSize(600,375);
			this.hide();
			vf.show();
		}
		
		else if(arg.equals("Back To Vf = Vi + A * Delta T Form"))
		{
			VfViADeltaT vf2 = new VfViADeltaT();
			vf2.setJMenuBar(vf2.createMenuBar());
			vf2.setContentPane(vf2.createContentPane());
			vf2.setSize(600,375);
			this.hide();
			vf2.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form2"))
		{
			AcceleratingMotionEquationSelection motion = new AcceleratingMotionEquationSelection();
			motion.setJMenuBar(motion.createMenuBar());
			motion.setContentPane(motion.createContentPane());
			motion.setSize(600,375);
			this.hide();
			motion.show();
		}
		
		else if(arg.equals("Back To Accelerating Motion Form"))
		{
			AcceleratingMotionEquationSelection motion2 = new AcceleratingMotionEquationSelection();
			motion2.setJMenuBar(motion2.createMenuBar());
			motion2.setContentPane(motion2.createContentPane());
			motion2.setSize(600,375);
			this.hide();
			motion2.show();
		}
		
		else if(arg.equals("Back To Main Form2"))
		{
			MainForm main = new MainForm();
			main.setJMenuBar(main.createMenuBar());
			main.setContentPane(main.createContentPane());
			main.setSize(600,375);
			this.hide();
			main.show();
		}
		
		else if(arg.equals("Back To Main Form"))
		{
			MainForm main2 = new MainForm();
			main2.setJMenuBar(main2.createMenuBar());
			main2.setContentPane(main2.createContentPane());
			main2.setSize(600,375);
			this.hide();
			main2.show();
		}
		
		else if(arg.equals("Calculate2"))
		{
			String vfstring;
			String astring;
			String deltatstring;
			double a = 0;
			double vf = 0;
			double vi = 0;
			double deltat = 0;
			
			astring = Afield.getText();
			vfstring = Vffield.getText();
			deltatstring = DeltaTfield.getText();
			
			try
			{
				a = Double.parseDouble(astring);
				vf = Double.parseDouble(vfstring);
				deltat = Double.parseDouble(deltatstring);
				vi = vf-(a * deltat);
				JOptionPane.showMessageDialog(null,"Answer is " + vi,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				DeltaTfield.setText("");
				Vffield.setText("");
				if(astring == null || vfstring == null || deltatstring == null)throw new Exception();
			}
			catch(Exception t)
			{
				JOptionPane.showMessageDialog(null,"Please enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Vffield.setText("");
				DeltaTfield.setText("");
			}
		}
		
		else if(arg.equals("Calculate"))
		{
			String vfstring;
			String astring;
			String deltatstring;
			double a = 0;
			double vf = 0;
			double vi = 0;
			double deltat = 0;
			
			astring = Afield.getText();
			vfstring = Vffield.getText();
			deltatstring = DeltaTfield.getText();
			
			try
			{
				a = Double.parseDouble(astring);
				vf = Double.parseDouble(vfstring);
				deltat = Double.parseDouble(deltatstring);
				vi = vf-(a * deltat);
				JOptionPane.showMessageDialog(null,"Answer is " + vi,"Answer",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				DeltaTfield.setText("");
				Vffield.setText("");
				if(astring == null || vfstring == null || deltatstring == null)throw new Exception();
			}
			catch(Exception t)
			{
				JOptionPane.showMessageDialog(null,"Please enter integers or decimals only","Error",JOptionPane.INFORMATION_MESSAGE);
				Afield.setText("");
				Vffield.setText("");
				DeltaTfield.setText("");
			}
		}
		
		else if(arg.equals("Instructions"))
		{
			JOptionPane.showMessageDialog(null,"Enter in numbers into the textboxes and then click the calculate button to get the answer./nYou can leave at any time to other forms","How To",JOptionPane.INFORMATION_MESSAGE);
		}
		
	}
	
	public static void main(String[] args)
	{
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
		}
		catch(Exception d)
		{
			JOptionPane.showMessageDialog(null,"could not set UIManger");
		}
		VfforVfViADeltaT vf = new VfforVfViADeltaT();
		vf.setJMenuBar(vf.createMenuBar());
		vf.setContentPane(vf.createContentPane());
		vf.setSize(999,300);
		vf.setVisible(true);
	}
	
	
}
