/*
 * Program: Physics Calculator Program
 * Programmer: Jay
 * Date: 4/22/2010
 * Filename: DeltaDforDeltaDDfDi.java
 * Purpose: Solve for Delta D in  Delta D = Df - Di.
 */
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class DeltaDforDeltaDDfDi extends JFrame implements ActionListener {
 
 //items used for calculations
 JLabel DeltaDlabel = new JLabel("Please enter in information below to solve for Delta D");
 JLabel Dflabel = new JLabel("Df");
 JTextField DfField = new JTextField(10);
 JLabel Dilabel = new JLabel("Di");
 JTextField DiField = new JTextField(10);
 JButton calculate = new JButton("Calculate");
 JButton backtoMainForm = new JButton("Back To Main Form");
 JButton backtoDeltaDDfDiForm = new JButton("Back To Delta D = Df - Di Form");
 JButton backtoRepresentingMotionEquationsForm = new JButton("Back To Representing Motion Equations Form");
 
 //Constructor Method
 public DeltaDforDeltaDDfDi()
 {
  super("Delta D for Delta D = Df - Di");
 }
 
 //creates the menu structure
 public JMenuBar createMenuBar()
 {
  JMenuBar mnuBar = new JMenuBar();
  setJMenuBar(mnuBar);
  
  JMenu mnuFile = new JMenu("File",true);
  mnuFile.setMnemonic(KeyEvent.VK_F);
  mnuFile.setDisplayedMnemonicIndex(0);
  mnuBar.add(mnuFile);
  
  JMenuItem mnuFileCalculate = new JMenuItem("Calculate");
  mnuFileCalculate.setMnemonic(KeyEvent.VK_C);
  mnuFileCalculate.setDisplayedMnemonicIndex(1);
  mnuFileCalculate.setActionCommand("Calculate2");
  mnuFileCalculate.addActionListener(this);
  mnuFile.add(mnuFileCalculate);
  
  JMenu mnuFileBack = new JMenu("Back",true);
  mnuFileBack.setMnemonic(KeyEvent.VK_B);
  mnuFileBack.setDisplayedMnemonicIndex(0);
  mnuFile.add(mnuFileBack);
  
  JMenuItem mnuBackToMainForm = new JMenuItem("Back To Main Form");
  mnuBackToMainForm.setMnemonic(KeyEvent.VK_M);
  mnuBackToMainForm.setDisplayedMnemonicIndex(1);
  mnuBackToMainForm.setActionCommand("Back To Main Form2");
  mnuBackToMainForm.addActionListener(this);
  mnuFileBack.add(mnuBackToMainForm);
  
  JMenuItem mnuBackToDeltaDDfDiForm = new JMenuItem("Back To Delta D = Df - Di Form");
  mnuBackToDeltaDDfDiForm.setMnemonic(KeyEvent.VK_D);
  mnuBackToDeltaDDfDiForm.setDisplayedMnemonicIndex(1);
  mnuBackToDeltaDDfDiForm.setActionCommand("Back To Delta D = Df - Di Form2");
  mnuBackToDeltaDDfDiForm.addActionListener(this);
  mnuFileBack.add(mnuBackToDeltaDDfDiForm);
  
  JMenuItem mnuBackToRepresentingMotionEquationsSelection = new JMenuItem("Back To Representing Motion Equations Form");
  mnuBackToRepresentingMotionEquationsSelection.setMnemonic(KeyEvent.VK_E);
  mnuBackToRepresentingMotionEquationsSelection.setDisplayedMnemonicIndex(1);
  mnuBackToRepresentingMotionEquationsSelection.setActionCommand("Back To Representing Motion Equation Form2");
  mnuBackToRepresentingMotionEquationsSelection.addActionListener(this);
  mnuFileBack.add(mnuBackToRepresentingMotionEquationsSelection);
  
  JMenu mnuAbout = new JMenu("About");
  mnuAbout.setMnemonic(KeyEvent.VK_A);
  mnuAbout.setDisplayedMnemonicIndex(0);
  mnuBar.add(mnuAbout);
  
  JMenuItem mnuAboutInstructions = new JMenuItem("Instructions");
  mnuAboutInstructions.setMnemonic(KeyEvent.VK_I);
  mnuAboutInstructions.setDisplayedMnemonicIndex(1);
  mnuAboutInstructions.setActionCommand("Instructions");
  mnuAboutInstructions.addActionListener(this);
  mnuAbout.add(mnuAboutInstructions);
  
  return mnuBar;
  
 }
 
 
 //creates the container to hold items 
 public Container createContentPane()
 {
  JPanel northpanel = new JPanel();
  northpanel.setLayout(new FlowLayout());
  northpanel.add(DeltaDlabel);
  
  JPanel centerpanel = new JPanel();
  centerpanel.setLayout(new GridLayout(2,2));
  centerpanel.add(DfField);
  centerpanel.add(Dflabel);
  centerpanel.add(DiField);
  centerpanel.add(Dilabel);
  
  JPanel southpanel = new JPanel();
  southpanel.setLayout(new FlowLayout());
  southpanel.add(calculate);
  calculate.addActionListener(this);
  calculate.setActionCommand("Calculate");
  backtoDeltaDDfDiForm.setActionCommand("Back To Delta D = Df - Di Form");
  backtoDeltaDDfDiForm.addActionListener(this);
  southpanel.add( backtoDeltaDDfDiForm);
  southpanel.add(backtoRepresentingMotionEquationsForm);
  backtoRepresentingMotionEquationsForm.addActionListener(this);
  backtoRepresentingMotionEquationsForm.setActionCommand("Back To Representing Motion Equations Form");
  southpanel.add(backtoMainForm);
  backtoMainForm.addActionListener(this);
  backtoMainForm.setActionCommand("Back To Main Form");
  
  Container f = getContentPane();
  f.setLayout(new BorderLayout());
  f.add(northpanel, BorderLayout.NORTH);
  f.add(centerpanel, BorderLayout.CENTER);
  f.add(southpanel, BorderLayout.SOUTH);
  
  return f;
 }
 
 //used to implement button and menu clicks
 public void actionPerformed(ActionEvent e)
 {
  String args = e.getActionCommand();
  
  //go main menu
  if(args == "Back To Main Form2")
  {
   MainForm m = new MainForm();
   m.setMenuBar(m.getMenuBar());
   m.setContentPane(m.createContentPane());
   m.show();
   this.hide();
   m.setSize(600,375);
  }
  
  //go to main menu
  if(args == "Back To Main Form")
  {
   MainForm m2 = new MainForm();
   m2.setMenuBar(m2.getMenuBar());
   m2.setContentPane(m2.createContentPane());
   m2.show();
   this.hide();
   m2.setSize(600,375);
  }
  
  //go to Representing Motion Equations Form 
  if(args == "Back To Representing Motion Equation Form2")
  {
   RepresentingMotionEquationsSelection w = new RepresentingMotionEquationsSelection();
   w.setJMenuBar(w.createMenuBar());
   w.setContentPane(w.createContentPane());
   w.setSize(600,375);
   w.show();
   this.hide();
  }
  
  //go to Delta D = Df - Di Form
  if(args == "Back To Delta D = Df - Di Form2")
  {
   DeltaDDfDi t = new DeltaDDfDi();
   t.setJMenuBar(t.createMenuBar());
   t.setContentPane(t.createContentPane());
   t.setSize(600,375);
   t.show();
   this.hide();
  }
  
  //go to Delta D = Df - Di Form
  if(args == "Back To Delta D = Df - Di Form")
  {
   DeltaDDfDi t2 = new DeltaDDfDi();
   t2.setJMenuBar(t2.createMenuBar());
   t2.setContentPane(t2.createContentPane());
   t2.setSize(600,375);
   t2.show();
   this.hide();
  }
  
  //go to Representing Motion Equations Form
  if(args == "Back To Representing Motion Equations Form")
  {
   RepresentingMotionEquationsSelection q = new RepresentingMotionEquationsSelection();
   q.setMenuBar(q.getMenuBar());
   q.setContentPane(q.createContentPane());
   q.setSize(600,375);
   q.show();
   this.hide();
  }
  
  //solve for Delta D
  if(args == "Calculate2")
  {
   double df = 0;
   double di = 0;
   double deltad = 0;
   String dfstring;
   String distring;
   
   dfstring = DfField.getText();
   distring = DiField.getText();
   try
   {
   df = Double.parseDouble(dfstring);
   di = Double.parseDouble(distring);
   deltad = df - di;
   JOptionPane.showMessageDialog(null,"The answer for Delta D is " + deltad);
   if(dfstring == null || distring == null)throw new Exception();
   }
   catch(Exception t)
   {
    JOptionPane.showMessageDialog(null,"You must enter integers and decimals only into the fields.","Input Error",JOptionPane.INFORMATION_MESSAGE);
    DfField.setText("");
    DiField.setText("");
   }
   
  }
  
  //solve for Delta D
  if(args == "Calculate")
  {
   double df = 0;
   double di = 0;
   double deltad = 0;
   String dfstring;
   String distring;
   
   dfstring = DfField.getText();
   distring = DiField.getText();
   try
   {
   df = Double.parseDouble(dfstring);
   di = Double.parseDouble(distring);
   deltad = df - di;
   JOptionPane.showMessageDialog(null,"The answer for Delta D is " + deltad);
   DfField.setText("");
   DiField.setText("");
   if(dfstring == null || distring == null)throw new Exception();
   }
   catch(Exception t)
   {
    JOptionPane.showMessageDialog(null,"You must enter integers and decimals only into the fields.","Input Error",JOptionPane.INFORMATION_MESSAGE);
    DfField.setText("");
    DiField.setText("");
   }
  }
  
  else if(args == "Instructions")
  {
   JOptionPane.showMessageDialog(null,"Please enter in information below to solve for delta d","Help",JOptionPane.INFORMATION_MESSAGE);
  }
   
 }
 
 //creates the jframe
 public static void main(String[] args)
 {
  try
  {
   UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
  }
  catch(Exception d)
  {
   JOptionPane.showMessageDialog(null,"could not set UIManger");
  }
  DeltaDforDeltaDDfDi g = new DeltaDforDeltaDDfDi();
  g.setJMenuBar(g.createMenuBar());
  g.setContentPane(g.createContentPane());
  g.setSize(900,149);
  g.setVisible(true);
 }
}
